/* Native font/style preservation, safe refusal and PDF geometry regressions. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PDFDocument,StandardFonts,rgb,degrees,cmyk,grayscale,PDFName} from 'pdf-lib';
import * as E from './engine.js';
import {directTextTargets,replaceDirectText,saveDirectEdit,directFontData} from './direct-text.js';
let count=0;const ok=(v,m)=>{count++;assert.ok(v,m)},eq=(a,b,m)=>{count++;assert.deepEqual(a,b,m)};
const save=saveDirectEdit;
const families=[StandardFonts.Helvetica,StandardFonts.HelveticaBold,StandardFonts.HelveticaOblique,StandardFonts.HelveticaBoldOblique,StandardFonts.TimesRoman,StandardFonts.TimesRomanBold,StandardFonts.TimesRomanItalic,StandardFonts.TimesRomanBoldItalic,StandardFonts.Courier,StandardFonts.CourierBold,StandardFonts.CourierOblique,StandardFonts.CourierBoldOblique];
for(const name of families)for(const rotation of [0,90,180,270]){
 const source=await PDFDocument.create(),p=source.addPage([595,842]);p.setCropBox(15,20,565,802);p.setRotation(degrees(rotation));
 p.drawText('Original text',{x:65,y:700,size:21,font:await source.embedFont(name),color:rgb(.5,0,.125)});p.drawText('Keep nearby',{x:65,y:650,size:14});p.drawRectangle({x:40,y:500,width:120,height:45,color:rgb(0,.1,.25)});
 const sourceBytes=await source.save(),doc=E.openPDF(sourceBytes);try{
  const original=directTextTargets(doc,0).find(t=>t.text==='Original text'),before=E.renderPagePixels(sourceBytes,0,{scale:.7}),neighbour=directTextTargets(doc,0).find(t=>t.text==='Keep nearby').rect;
  replaceDirectText(doc,0,original,'Edited PDF');const bytes=save(doc),updated=directTextTargets(doc,0).find(t=>t.text==='Edited PDF');
  ok(updated,name+' '+rotation+' replacement is real text');eq(updated.size,original.size,'original point size');eq(updated.color,original.color,'original colour');eq(updated.bold,original.bold,'original weight');eq(updated.italic,original.italic,'original italic');
  ok(updated.matrix.every((v,i)=>Math.abs(v-original.matrix[i])<.02),'original baseline and transform');
  ok(E.extractTextPDF(bytes)[0].text.includes('Edited PDF')&&!E.extractTextPDF(bytes)[0].text.includes('Original text'),'searchable replacement and original removal');
  eq(directTextTargets(doc,0).find(t=>t.text==='Keep nearby').rect,neighbour,'neighbour text stays in place');
  // Outside the changed text rectangle every rendered byte must remain identical.
  const after=E.renderPagePixels(bytes,0,{scale:.7}),r=[Math.min(original.rect[0],updated.rect[0])*.7-3,Math.min(original.rect[1],updated.rect[1])*.7-3,Math.max(original.rect[2],updated.rect[2])*.7+3,Math.max(original.rect[3],updated.rect[3])*.7+3];let differences=0;
  for(let y=0;y<before.height;y++)for(let x=0;x<before.width;x++)if(x<r[0]||x>r[2]||y<r[1]||y>r[3])for(let c=0;c<before.components;c++){const i=y*before.stride+x*before.components+c;if(before.pixels[i]!==after.pixels[i])differences++}
  eq(differences,0,'graphics and other content stay pixel-identical');
  if(rotation===0){
    const expectedDoc=await PDFDocument.create(),expectedPage=expectedDoc.addPage([595,842]);expectedPage.setCropBox(15,20,565,802);
    expectedPage.drawText('Edited PDF',{x:65,y:700,size:21,font:await expectedDoc.embedFont(name),color:rgb(.5,0,.125)});expectedPage.drawText('Keep nearby',{x:65,y:650,size:14});expectedPage.drawRectangle({x:40,y:500,width:120,height:45,color:rgb(0,.1,.25)});
    const expected=E.renderPagePixels(await expectedDoc.save(),0,{scale:.7});let changed=0;for(let i=0;i<expected.pixels.length;i++)if(Math.abs(expected.pixels[i]-after.pixels[i])>3)changed++;
    ok(changed<25,'saved glyph appearance matches an independent original-font PDF for '+name);
  }
  const again=E.openPDF(bytes);try{replaceDirectText(again,0,directTextTargets(again,0).find(t=>t.text==='Edited PDF'),'Second edit');const output=E.extractTextPDF(save(again))[0].text;ok(output.includes('Second edit')&&output.includes('Keep nearby'),'repeat edit retains replacement and neighbour')}finally{again.destroy()}
 }finally{doc.destroy()}
}
// An embedded TrueType font retains its program, Unicode and colour.
const fontPath=[process.env.PDFPRO_TEST_TTF,(process.env.WINDIR||'C:/Windows')+'/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'].find(p=>p&&fs.existsSync(p)),font=fontPath?new E.mupdf.Font('EmbeddedFixture',fs.readFileSync(fontPath)):new E.mupdf.Font('Helvetica'),text=new E.mupdf.Text(),buffer=new E.mupdf.Buffer(),writer=new E.mupdf.DocumentWriter(buffer,'pdf','compress');
try{
 text.showString(font,[19,0,0,-19,45,100],'Embedded café');const device=writer.beginPage([0,0,500,700]);try{device.fillText(text,E.mupdf.Matrix.identity,E.mupdf.ColorSpace.DeviceRGB,[.1,.2,.3],1)}finally{device.destroy()}writer.endPage();writer.close();
 const doc=E.openPDF(buffer.asUint8Array());try{const target=directTextTargets(doc,0)[0];ok(directFontData(doc,0,target)?.length>1000,'embedded font programme is available for an offline typing preview');replaceDirectText(doc,0,target,'Edited résumé');const after=directTextTargets(doc,0)[0];ok(after.text.replace(/\u00a0/g,' ')==='Edited résumé','embedded Unicode text');const embeddedOutput=save(doc);ok(E.extractTextPDF(embeddedOutput)[0].text.trim()==='Edited résumé','Unicode extraction does not duplicate words');eq(after.fontName,target.fontName,'embedded font identity');eq(after.color,target.color,'embedded font colour');eq(after.size,target.size,'embedded font size');fs.writeFileSync('direct-edit-proof.png',E.renderPagePNG(embeddedOutput,0,{scale:1.4}).bytes)}finally{doc.destroy()}
}finally{writer.destroy();buffer.destroy();text.destroy();font.destroy()}
const source=await PDFDocument.create(),page=source.addPage([350,400]);page.drawText('Short',{x:40,y:300,size:20});page.drawText('Neighbour',{x:130,y:300,size:20});
const bytes=await source.save();
for(const [value,message] of [['A very long replacement text','overlap|beyond'],['Unsupported 😀','does not contain'],['line\nline','one text line']]){
 const doc=E.openPDF(bytes);try{count++;assert.throws(()=>replaceDirectText(doc,0,directTextTargets(doc,0)[0],value),new RegExp(message));eq(E.extractTextPDF(save(doc))[0].text,E.extractTextPDF(bytes)[0].text,'validation failure preserves content')}finally{doc.destroy()}
}
const doc=E.openPDF(bytes);try{const target=directTextTargets(doc,0)[0];count++;assert.throws(()=>replaceDirectText(doc,0,{...target,text:'stale'},'New'),/changed/);replaceDirectText(doc,0,target,'');const extracted=E.extractTextPDF(save(doc))[0].text;ok(!extracted.includes('Short')&&extracted.includes('Neighbour'),'empty input deletes only chosen text')}finally{doc.destroy()}
for(const colour of [grayscale(.35),cmyk(.2,.8,.5,.1),rgb(.2,.4,.7)]){
 const source=await PDFDocument.create(),page=source.addPage([350,400]);page.node.set(PDFName.of('UserUnit'),source.context.obj(2));page.drawText('Colour sample',{x:40,y:300,size:20,color:colour,opacity:.6});const doc=E.openPDF(await source.save());
 try{const original=directTextTargets(doc,0)[0];replaceDirectText(doc,0,original,'Colour edit');const output=save(doc),reopened=E.openPDF(output);try{const updated=directTextTargets(reopened,0)[0];eq(updated.color,original.color,'gray/CMYK/RGB colour retained');eq(updated.alpha,original.alpha,'opacity retained');eq(updated.size,original.size,'UserUnit-scaled size retained');eq(updated.matrix,original.matrix,'UserUnit baseline retained')}finally{reopened.destroy()}}finally{doc.destroy()}
}
console.log('pdfpro Direct edit native: '+count+' assertions passed with font/style, Unicode, rotations, crop origins, repeated edits and PDF pixels.');
