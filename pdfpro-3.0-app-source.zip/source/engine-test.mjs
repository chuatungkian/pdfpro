/* Synthetic integration and confidentiality regression checks.
 * Run: node engine-test.mjs
 * These checks do not establish standards compliance or Acrobat equivalence.
 */
import assert from 'node:assert/strict';
import { PDFDocument, PDFName, PDFRawStream, decodePDFRawStream } from 'pdf-lib';
import * as Engine from './engine.js';

const { mupdf } = Engine;
let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
function throws(fn, matcher, message) { assertions++; assert.throws(fn, matcher, message); }
function snapshot(doc) {
  const buffer = doc.saveToBuffer('');
  try { return new Uint8Array(buffer.asUint8Array()); } finally { buffer.destroy(); }
}
function makeFixture({ rotation = 0, origin = [0, 0], pageCount = 2, annotation = false } = {}) {
  const doc = new mupdf.PDFDocument(), font = new mupdf.Font('Helvetica');
  try {
    const ref = doc.addSimpleFont(font, 'Latin');
    for (let i = 0; i < pageCount; i++) {
      doc.insertPage(-1, doc.addPage([origin[0], origin[1], origin[0] + 300, origin[1] + 200], rotation,
        { Font: { F1: ref } }, `BT /F1 14 Tf ${origin[0] + 20} ${origin[1] + 150} Td (SECRET public text) Tj ET`));
    }
    doc.setMetaData('info:Title', 'SECRET metadata');
    const attachment = doc.addEmbeddedFile('secret.txt', 'text/plain', 'SECRET attachment', new Date(0), new Date(0));
    doc.insertEmbeddedFile('secret.txt', attachment);
    doc.getTrailer().get('Root').put('Metadata', doc.addStream('<xmp>SECRET xmp</xmp>', { Type: 'Metadata', Subtype: 'XML' }));
    if (annotation) {
      const page = doc.loadPage(0), annot = page.createAnnotation('FreeText');
      annot.setRect([20, 20, 180, 50]); annot.setContents('SECRET ANNOTATION');
      annot.setDefaultAppearance('Helv', 14, [1, 0, 0]); annot.update();
      page.destroy();
    }
    return snapshot(doc);
  } finally { font.destroy(); doc.destroy(); }
}

const original = makeFixture();
const sourceInfo = Engine.inspectPDF(original);
check(sourceInfo.pageCount === 2 && sourceInfo.metadata.Title === 'SECRET metadata', 'Fixture opens and metadata is extracted.');
check(sourceInfo.attachments.includes('secret.txt'), 'Fixture attachment is detected.');
const firstPage = Engine.readPagePDF(original);
check(firstPage.lines.some(line => line.text === 'SECRET public text'), 'Structured text has searchable lines.');
check(Engine.searchPDF(original, 'SECRET').length === 2, 'Search finds text across pages.');
const png = Engine.renderPagePNG(original);
check(png.width === 300 && png.height === 200 && png.bytes[0] === 137 && png.bytes[1] === 80, 'Rendering produces a correctly sized PNG.');

const nativeRedacted = Engine.redactPDF(original, [{ page: 0, rect: [15, 30, 80, 60] }], { rasterize: false });
const nativeText = Engine.extractTextPDF(nativeRedacted);
check(!nativeText[0].text.includes('SECRET') && nativeText[0].text.includes('public text'), 'Native redaction removes selected text and preserves text outside its region.');
check(Engine.inspectPDF(nativeRedacted).attachments.length === 0, 'Native redaction sanitation drops embedded attachments.');

const imageRedacted = Engine.redactPDF(makeFixture({ annotation: true }), [{ page: 0, rect: [10, 10, 200, 70] }], { dpi: 72 });
const rebuiltInfo = Engine.inspectPDF(imageRedacted), pixels = Engine.renderPagePixels(imageRedacted);
check(rebuiltInfo.pageCount === 2 && rebuiltInfo.annotations === 0 && rebuiltInfo.forms === 0, 'Raster reconstruction preserves page count and removes interactive objects.');
check(rebuiltInfo.metadata.Title === '' && rebuiltInfo.attachments.length === 0, 'Raster reconstruction removes title and attachments.');
check(Engine.extractTextPDF(imageRedacted).every(page => page.text === ''), 'Raster reconstruction has no searchable text layer on any page.');
let exposedPixelCount = 0;
for (let y = 10; y < 70; y++) for (let x = 10; x < 200; x++) {
  const offset = y * pixels.stride + x * pixels.components;
  if (pixels.pixels[offset] || pixels.pixels[offset + 1] || pixels.pixels[offset + 2]) exposedPixelCount++;
}
check(exposedPixelCount === 0, 'Every final redaction pixel is black, including overlaid FreeText annotations.');

const independent = await PDFDocument.load(imageRedacted);
let imageCount = 0, rawTextLeak = false;
for (const [, object] of independent.context.enumerateIndirectObjects()) {
  if (object instanceof PDFRawStream) {
    const data = decodePDFRawStream(object).decode();
    if (new TextDecoder().decode(data).includes('SECRET')) rawTextLeak = true;
    if (object.dict.get(PDFName.of('Subtype'))?.toString() === '/Image') imageCount++;
  }
}
check(independent.getPageCount() === 2 && imageCount === 2, 'Independent reader reopens two page-image objects.');
check(!rawTextLeak && independent.getTitle() === undefined, 'Independent decoded-object inspection finds no original text, metadata, XMP, or attachment strings.');

const restricted = -4 & ~(4 | 2048 | 16);
const encrypted = Engine.protectPDF(original, { password: 'open-test', ownerPassword: 'owner-test', permissions: restricted });
throws(() => Engine.openPDF(encrypted), error => error.code === 'PASSWORD_REQUIRED', 'Missing open password is rejected.');
throws(() => Engine.openPDF(encrypted, 'incorrect'), error => error.code === 'PASSWORD_REQUIRED', 'Incorrect open password is rejected.');
const restrictedInfo = Engine.inspectPDF(encrypted, 'open-test');
check(restrictedInfo.encryption.includes('256-bit AES'), 'Protected output uses AES-256.');
check(!restrictedInfo.permissions.print && !restrictedInfo.permissions.copy && !restrictedInfo.permissions['print-hq'], 'Integer permission mask disables both print modes and copy.');
check(Engine.inspectPDF(encrypted, 'owner-test').pageCount === 2, 'Owner password authenticates.');
check(Engine.inspectPDF(Engine.decryptPDF(encrypted, 'open-test')).encryption === 'None', 'Decryption exports an unencrypted PDF.');
throws(() => Engine.protectPDF(original, { password: 'comma,password' }), /cannot contain commas/, 'Unrepresentable password option is rejected.');

for (const rotation of [0, 90, 180, 270]) {
  const fixture = makeFixture({ rotation, origin: [10, 20], pageCount: 1 });
  const replaced = Engine.replaceTextPDF(fixture, [{ page: 0, rect: [10, 20, 150, 60], text: 'REPLACED', size: 12 }]);
  const line = Engine.readPagePDF(replaced).lines.find(line => line.text === 'REPLACED');
  check(line && line.rect[0] >= 10 && line.rect[1] >= 20 && line.rect[2] <= 150 && line.rect[3] <= 60, `Replacement remains bounded with origin offsets and ${rotation} degree rotation.`);
}
throws(() => Engine.replaceTextPDF(original, [{ page: 0, rect: [10, 10, 20, 20], text: 'DOES NOT FIT', size: 14 }]), /too wide|does not fit/, 'Overflow is rejected before destructive editing.');
throws(() => Engine.replaceTextPDF(original, [{ page: 0, rect: [10, 10, 200, 60], text: '\u4e2d\u6587', size: 12 }]), /basic Latin/, 'Unsupported replacement script is clearly rejected.');

const sanitized = Engine.sanitizePDF(original, { rasterize: true, dpi: 72 });
check(Engine.inspectPDF(sanitized).pageCount === 2 && Engine.extractTextPDF(sanitized).every(page => !page.text), 'Sanitize raster rebuild works without redaction regions.');
check(Engine.inspectPDF(Engine.optimizePDF(original)).pageCount === 2, 'Lossless optimization remains a readable PDF.');
check(Engine.inspectPDF(Engine.updateMetadataPDF(original, { Title: 'New title' })).metadata.Title === 'New title', 'Metadata editing writes the requested title.');

console.log(`pdfpro engine: ${assertions} assertions passed.`);
