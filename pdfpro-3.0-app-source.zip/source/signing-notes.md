# Certificate signatures in pdfpro

`signing.js` is a browser IIFE. Load after setting `window.PDFLib` to pdf-lib and `window.forge` to node-forge. It performs no network requests and needs neither WebCrypto nor an origin server.

## Interface

```js
const credential = await PdfProSigning.importP12(new Uint8Array(p12File), password);
// credential.summary: subject, issuer, validity dates, fingerprintSHA256, keyBits.
const signedBytes = await PdfProSigning.signPdf(pdfBytes, credential, {
  name: 'Optional display name', reason: 'Approval', location: 'Optional location'
});
const report = await PdfProSigning.verifyPdf(signedBytes);
const fields = await PdfProSigning.inspectSignatures(pdfBytes);
```

`signPdf` returns a Uint8Array. Save it directly; rewriting with another PDF engine after signing invalidates the signature. Signing appends an incremental revision, preserving the input bytes exactly. Its signature widget is invisible (zero rectangle); a visible signature image is a separate product feature.

`inspectSignatures` is async and returns form-associated signature records, including field name, signer display name, reason, location, subfilter, ByteRange and signedRevisionLength. Use it before offering document mutations. If inspection cannot parse a document, do not interpret the failure as proof that it is unsigned.

`verifyPdf` returns `{signatureCount, signatures, allCryptographicallyValid, currentFileCovered, trustNotice}`. Each entry has:

- `integrity`: `valid`, `invalid`, or `unsupported`.
- `coversCurrentFile`, `laterBytes`: distinguish an intact older signature from one covering the present file.
- `message`: suitable for a status description, inserted with `textContent`.
- `signers`: certificate identity text, certificate fingerprint, validity, digest algorithm, and untrusted claimed signing time.

Never render signer text, reasons, certificate subject values, or errors as HTML. These are untrusted document contents.

## Supported scope

- Password-protected PKCS#12/P12/PFX import containing an RSA private key and its matching X.509 certificate. RSA signing keys must be 2048 bits or larger, within their certificate dates, with a compatible keyUsage if present.
- Detached CMS/PKCS#7 RSA PKCS#1 v1.5 SHA-256 approval signatures. Existing ordinary approval signatures are retained when signing a second time.
- Verification of form-associated detached CMS (`adbe.pkcs7.detached`, `ETSI.CAdES.detached`) RSA PKCS#1 v1.5 signatures with SHA-1, SHA-256, SHA-384 or SHA-512; SHA-1 is explicitly flagged as weak.
- Both traditional xrefs and original object/xref streams; object allocation accounts for stream objects omitted by the pdf-lib object context.
- Signed-byte hashing, signed-attribute messageDigest verification, issuer/serial certificate matching and RSA signature verification. Excluded bytes must match exactly the one PDF hexadecimal signature container.

Unsupported: ECDSA, RSA-PSS, hardware tokens, encrypted PDFs, XFA, certification/DocMDP or other explicit transformation policies, signing trusted timestamps, online certificate trust/revocation, CA-store trust, PDF signature permission analysis, PAdES/LTV conformance. These are reported or blocked. Document signing limit is 150 MB, PKCS#12 import limit 10 MB; large operations use main-thread JavaScript and memory.

An intact cryptographic signature is **not** proof of a trusted identity. The module does not establish CA trust, verify certificate chains, check revocation or validate timestamp authorities. A self-signed certificate will show valid byte integrity but unestablished trust. The declared local signing time is never a trusted timestamp.

The private key is held only in the returned credential object. The calling UI should clear the password input immediately after import and release credential references when the document is closed or the user selects Forget certificate. JavaScript cannot guarantee physical zeroization of discarded memory.

## Validation

Run `node signing-test.mjs` from this folder. The test generates a temporary in-memory self-signed test key/certificate, never using personal credentials. It checks import password rejection, two approval revisions, original-byte preservation, existing form preservation, independent MuPDF parsing of object-stream and classic-xref output, tamper detection, unsigned trailing-byte reporting, and certification policy rejection. It writes disposable PDF/CMS fixtures under `signing-fixtures`.

Independent CMS validation used:

```text
openssl cms -verify -binary -inform DER -in signing-fixtures/signature.der -content signing-fixtures/signed-content.bin -noverify -out signing-fixtures/openssl-content.bin
```

Result: `Verification successful`. `-noverify` deliberately skips trust validation while independently verifying the CMS signature. This test does not claim Acrobat UI validation or broad production certificate interoperability.

## Primary references

- Forge documentation: https://github.com/digitalbazaar/forge (PKCS#12, PKCS#7 detached signing, RSA verification).
- RFC 5652: https://www.rfc-editor.org/rfc/rfc5652 (CMS SignedData and signed attributes).
- PDF-LIB API: https://pdf-lib.js.org/docs/api/classes/pdfdocument (low-level object context and parsing).
