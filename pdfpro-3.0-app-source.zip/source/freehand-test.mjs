/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {inkPoint,appendInkSamples,savedInkPoints} from './freehand.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;
 const fixture=await app.PDFLib.PDFDocument.create();
 for(const rotation of [0,90,180,270]){const page=fixture.addPage([595,842]);page.setMediaBox(10,20,595,842);page.setRotation(app.PDFLib.degrees(rotation));page.drawText('Freehand drawing check '+rotation,{x:40,y:760,size:18})}
 await app.openFiles([file('Freehand.pdf',await fixture.save({useObjectStreams:false}))]);app.state.fit=false;app.state.zoom=1;await app.render();
 await window.document.querySelector('[data-group=Annotate]').onclick();await app.activate('ink');app.state.size=28;app.state.color='#800020';
 const overlay=$('overlay'),origin={left:73,top:119};let captured=[],released=[];
 overlay.setPointerCapture=id=>captured.push(id);overlay.releasePointerCapture=id=>released.push(id);
 function bounds(){const page=app.state.doc.loadPage(app.state.page);try{return page.getBounds()}finally{page.destroy()}}
 overlay.getBoundingClientRect=()=>{const b=bounds();return{...origin,width:(b[2]-b[0])*app.state.zoom,height:(b[3]-b[1])*app.state.zoom}};
 function sample(point,id=1){const b=bounds();return{clientX:origin.left+(point[0]-b[0])*app.state.zoom,clientY:origin.top+(point[1]-b[1])*app.state.zoom,pointerId:id}}
 function pointer(type,point,{id=1,button=0,primary=true,coalesced}={}){
  const data=sample(point,id),event=new window.MouseEvent(type,{bubbles:true,clientX:data.clientX,clientY:data.clientY,button});
  Object.defineProperties(event,{pointerId:{value:id},isPrimary:{value:primary}});
  if(coalesced)Object.defineProperty(event,'getCoalescedEvents',{value:()=>coalesced.map(p=>sample(p,id))});
  overlay.dispatchEvent(event);
 }
 function inks(){const page=app.state.doc.loadPage(app.state.page),all=page.getAnnotations();try{return all.filter(a=>a.getType()==='Ink').map(a=>({points:a.getInkList(),width:a.getBorderWidth(),color:a.getColor(),rect:a.getBounds()}))}finally{all.forEach(a=>a.destroy());page.destroy()}}
 async function committed(previous){await until(()=>app.state.bytes!==previous&&!app.state.abort,'ink saved');await app.local.flush()}
 function nearPoints(actual,expected,label){check(actual.length===expected.length&&actual.every((point,i)=>point.length===2&&point.every((value,j)=>Math.abs(value-expected[i][j])<.001)),label)}
 function previewPoints(){return $('inkPreview').querySelector('polyline').getAttribute('points').split(' ').map(p=>p.split(',').map(Number))}
 function hasInkNear(point,bytes=app.state.bytes,pageIndex=app.state.page){const result=app.Engine.renderPagePixels(bytes,pageIndex,{scale:1}),b=result.bounds;for(let y=Math.max(0,Math.floor(point[1]-b[1])-3);y<Math.min(result.height,Math.floor(point[1]-b[1])+4);y++)for(let x=Math.max(0,Math.floor(point[0]-b[0])-3);x<Math.min(result.width,Math.floor(point[0]-b[0])+4);x++){const i=y*result.stride+x*result.components;if(result.pixels[i+1]<100&&result.pixels[i+2]<130)return true}return false}

 // A loop whose middle extends far beyond its endpoints must remain a loop.
 const path=[[60,120],[145,150],[90,230],[200,175],[75,145],[65,125]],before=app.state.bytes;
 pointer('pointerdown',path[0]);check(!!$('inkPreview')&&!$('dragrect'),'Draw starts a stroke preview without an area selector');
 check($('inkPreview').getAttribute('aria-hidden')==='true','stroke preview is decorative');
 for(const point of path.slice(1,-1))pointer('pointermove',point);
 nearPoints(previewPoints(),path.slice(0,-1),'live preview follows every sampled bend in order');
 check(app.state.bytes===before,'moving the pen does not repeatedly rewrite the PDF');
 pointer('pointerup',path.at(-1));await committed(before);
 nearPoints(inks()[0].points[0],path,'saved native Ink preserves the loop and final release point');
 equal(inks().length,1,'one continuous gesture creates one Ink annotation');equal(inks()[0].width,4,'stroke uses chosen PDF width');check(inks()[0].color.every((value,index)=>Math.abs(value-[128/255,0,32/255][index])<.000001),'stroke uses chosen colour');
 check(!inks()[0].rect.some(value=>!Number.isFinite(value)),'saved stroke bounds are finite');
 for(const point of path)check(hasInkNear(point),'native PDF render contains the stroke at '+point.join(','));
 check(!hasInkNear([270,270]),'no scribble appears in an unused nearby area');
 check(!$('inkPreview')&&!$('dragrect'),'temporary preview is removed after commit');equal(app.state.tool,'ink','Draw remains active for another stroke');
 check(captured.includes(1)&&released.includes(1),'gesture captures and releases its own pointer');

 // Coalesced pen samples and the main release event retain their exact order.
 const second=[[260,270],[270,250],[285,275],[300,245],[320,280],[330,260]],beforeSecond=app.state.bytes;
 pointer('pointerdown',second[0]);pointer('pointermove',second[4],{coalesced:second.slice(1,4)});
 nearPoints(previewPoints(),second.slice(0,5),'coalesced pen samples appear in the live preview');
 const preview=previewPoints();pointer('pointermove',[500,600],{id:8});pointer('pointerup',[500,600],{id:8});
 nearPoints(previewPoints(),preview,'other pointers cannot inject coordinates or end a stroke');
 pointer('pointerup',second.at(-1));await committed(beforeSecond);equal(inks().length,2,'a second gesture creates an independent stroke');nearPoints(inks()[1].points[0],second,'strokes do not acquire a connecting segment');

 const beforeCancel=app.state.bytes,count=inks().length;
 pointer('pointerdown',[390,170]);pointer('pointermove',[420,210]);pointer('pointercancel',[420,210]);
 check(!$('inkPreview')&&app.state.bytes===beforeCancel,'pointer cancellation discards the unfinished preview');
 pointer('pointerup',[450,240]);await pause();equal(inks().length,count,'cancelled stroke cannot later be committed');
 pointer('pointerdown',[390,170],{button:2});check(!$('inkPreview'),'right mouse button does not start drawing');
 pointer('pointerdown',[390,170],{primary:false});check(!$('inkPreview'),'secondary touch contact does not start drawing');
 pointer('pointerdown',[390,170]);pointer('lostpointercapture',[400,180]);check(!$('inkPreview')&&app.state.bytes===beforeCancel,'lost pointer capture cancels safely');
 pointer('pointerdown',[390,170]);overlay.dispatchEvent(new window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
 check(!$('inkPreview')&&app.state.tool==='select','Escape cancels drawing and deselects Draw');pointer('pointerup',[400,180]);await pause();equal(inks().length,count,'Escape does not save the cancelled stroke');
 await app.activate('ink');pointer('pointerdown',[390,170]);await app.activate('rectangle');check(!$('inkPreview')&&app.state.tool==='rectangle','choosing another tool cancels the unfinished pen path');
 pointer('pointerup',[400,180]);await pause();equal(inks().length,count,'tool switch cannot commit a stale stroke');

 await app.activate('ink');const beforeTap=app.state.bytes;pointer('pointerdown',[400,300]);pointer('pointerup',[400,300]);await committed(beforeTap);
 check(inks().at(-1).points[0].length===2,'a pen tap creates a tiny native segment');check(hasInkNear([400,300]),'a tap is visible as a dot');check(inks().at(-1).rect[2]-inks().at(-1).rect[0]<30,'tap only has native stroke padding rather than an area-tool rectangle');
 const beforeUndo=app.state.bytes;await $('undo').onclick();equal(inks().length,count,'undo removes only the latest stroke');await $('redo').onclick();equal(inks().length,count+1,'redo restores the latest stroke');equal(app.state.tool,'ink','undo/redo keep Draw selected');
 check(hasInkNear([400,300]),'redone stroke retains its appearance');
 const curve=Array.from({length:161},(_,i)=>{const t=i*Math.PI/80;return[180+80*Math.sin(t),410+40*Math.sin(2*t)]}),beforeCurve=app.state.bytes;
 pointer('pointerdown',curve[0]);for(let i=1;i<curve.length;i+=4){const batch=curve.slice(i,i+4);pointer('pointermove',batch.at(-1),{coalesced:batch.slice(0,-1)})}
 nearPoints(previewPoints(),curve,'live freeform curve retains dense pen samples');pointer('pointerup',curve.at(-1));await committed(beforeCurve);
 nearPoints(inks().at(-1).points[0],curve,'dense freeform curve exports without changing sample order');
 for(const index of [20,60,100,140])check(hasInkNear(curve[index]),'rendered freeform curve follows sample '+index);
 fs.writeFileSync('freehand-proof.png',app.Engine.renderPagePNG(app.state.bytes,0,{scale:1}).bytes);

 // Rotation, zoom and nonzero media origins must preserve screen-to-PDF points.
 for(const[index,zoom]of [[1,.75],[2,1.4],[3,.6]]){
  app.state.page=index;app.state.zoom=zoom;await app.render();const b=bounds(),points=[[b[0]+60,b[1]+100],[b[0]+180,b[1]+130],[b[0]+90,b[1]+180]],previous=app.state.bytes;
  pointer('pointerdown',points[0]);pointer('pointermove',points[1]);pointer('pointerup',points[2]);await committed(previous);
  nearPoints(inks()[0].points[0],points,'correct native points at rotation '+index*90+' and zoom '+zoom);
  check(hasInkNear(points[1]),'native render matches displayed stroke at rotation '+index*90);
 }
 const currentPage=app.state.page,previous=app.state.bytes;pointer('pointerdown',[100,240]);app.state.zoom=1;await app.render();
 check(!$('inkPreview')&&app.state.bytes===previous,'page rerender cancels an unfinished gesture');
 pointer('pointerup',[200,260]);await pause();check(app.state.bytes===previous,'stale release after zoom cannot save incorrect coordinates');
 pointer('pointerdown',[100,240]);$('main').dispatchEvent(new window.Event('scroll'));pointer('pointerup',[140,280]);await pause();check(!$('inkPreview')&&app.state.bytes===previous,'scrolling the document cannot shift and save an unfinished stroke');

 // Capture appearance at stroke start even if a setting changes mid-gesture.
 app.state.color='#800020';app.state.size=14;const beforeStyle=app.state.bytes;
 pointer('pointerdown',[250,250]);pointer('pointermove',[280,290]);app.state.color='#101d3a';app.state.size=70;pointer('pointerup',[300,260]);await committed(beforeStyle);
 equal(inks().at(-1).width,2,'saved width matches the live stroke rather than a later setting');check(inks().at(-1).color.every((value,index)=>Math.abs(value-[128/255,0,32/255][index])<.000001),'saved colour matches the live stroke');
 await app.local.flush();const id=app.activeTabId,last=app.state.bytes;check((await app.local.store.getDocument(id)).snapshot.bytes.length===last.length,'freehand edit reaches local recovery');
 await context.close();context=await boot();({app,$,window}=context);
 equal(app.state.bytes,last,'freehand PDF bytes survive a fresh app instance');equal(app.state.tool,'ink','active Draw tool is recovered');equal(app.state.page,currentPage,'drawing page is recovered');
 const page=app.state.doc.loadPage(currentPage),all=page.getAnnotations();try{equal(all.filter(a=>a.getType()==='Ink').length,2,'all completed strokes survive reopening')}finally{all.forEach(a=>a.destroy());page.destroy()}

 const geometry={origin:{left:10,top:20},zoom:2,bounds:[0,0,100,200],pointer:1,points:[]};
 equal(inkPoint({clientX:-10,clientY:500},geometry),[0,200],'captured coordinates stay within the PDF page');
 equal(inkPoint({clientX:NaN,clientY:30},geometry),null,'invalid pointer coordinates are ignored');
 appendInkSamples(geometry,{clientX:30,clientY:60,pointerId:1,getCoalescedEvents(){throw Error('Unavailable')}});appendInkSamples(geometry,{clientX:30,clientY:60,pointerId:1});
 equal(geometry.points,[[10,20]],'older pointer APIs work and duplicate samples are removed');
 const tap=savedInkPoints({...geometry,points:[[100,200]]});check(tap[1][0]<100&&tap[1][0]>99.9,'edge taps remain within page bounds');
 console.log('pdfpro freehand drawing: '+assertions+' assertions passed with native Ink coordinates and rendered PDF pixels in a controlled DOM.');
}finally{if(context)await context.close()}
