/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {readTestZip} from './source-zip-test-utils.mjs';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
const urls=new Map(),revoked=[];
const createURL=URL.createObjectURL,revokeURL=URL.revokeObjectURL;
URL.createObjectURL=blob=>{const url=createURL(blob);urls.set(url,blob);return url};
URL.revokeObjectURL=url=>{revoked.push(url);urls.delete(url);revokeURL(url)};
async function many(app,label,count){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<count;i++)doc.addPage([300,420]).drawText(label+' PAGE '+(i+1),{x:20,y:350,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
try{
 context=await boot();let {app,$,window}=context;
 await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','Home ready');
 const alpha=await many(app,'ALPHA',6),beta=await many(app,'BETA',4);
 await app.openFiles([file('Alpha.pdf',alpha),file('<img src=x onerror=bad()> Beta.pdf',beta)]);
 const aid=app.tabs[0].id,bid=app.activeTabId;
 await app.editPDF('Latest source edit',doc=>doc.getPage(0).drawText('LATEST BETA EDIT',{x:20,y:320,size:12}));const editedBeta=app.state.bytes;
 await app.switchTab(aid);app.state.fit=false;app.state.zoom=.8;await app.render();$('main').scrollTop=281;$('main').scrollLeft=17;
 await window.document.querySelector('[data-group="Organize"]').onclick();
 check([...window.document.querySelectorAll('[data-tool]')].some(node=>node.dataset.tool==='split'&&node.textContent.includes('Merge & split')),'Organise offers workspace');
 window.document.querySelector('[data-tool="split"]').click();await until(()=>app.mergeSplit.model&&!app.mergeSplit.busy,'workspace from real feature click');let ms=app.mergeSplit;
 check(ms.isOpen&&!$('mergeSplitView').hidden,'workspace opens');check(window.document.body.classList.contains('split-workspace-open'),'workspace hides PDF preview dock/toolbar via state');
 check($('viewer').classList.contains('hidden'),'single PDF view hidden');equal(app.state.bytes,alpha,'opening does not change active PDF');equal(app.state.scrollTop,281,'PDF scroll saved');
 equal(ms.model.pages.length,6,'active PDF is first source');equal($('msGrid').children.length,6,'page grid contains source pages');check($('msGrid').lastElementChild.querySelector('button').disabled,'final page cannot become an extra split');
 check(!$('msPoints').closest('details'),'split-point field stays outside collapsible settings');check(!$('msPoints').closest('[hidden]'),'split-point field is visible');equal($('msGrid').querySelector('[data-ms-cut="0"]').textContent,'Split after page 1','explicit split control exists for first preview');check($('msGrid').querySelector('[data-ms-cut="5"]').disabled,'explicit final-page control is disabled');
 await until(()=>$('msGrid').querySelectorAll('img').length===6,'native previews');
 const previewBlob=urls.get($('msGrid').querySelector('img').src),png=Buffer.from(await previewBlob.arrayBuffer());equal([...png.subarray(0,8)],[137,80,78,71,13,10,26,10],'native preview PNG');const image=await canvas.loadImage(png);check(image.width<=170&&image.height<=210,'bounded native preview');
 check([...$('msSourcePicker').options].some(option=>option.value===bid&&option.textContent.includes('Open tab')),'other open PDFs listed');
 $('msSourcePicker').value=bid;await $('msAddSource').onclick();equal(ms.model.pages.length,10,'added PDF contributes pages');equal(app.activeTabId,aid,'adding source retains active owner');
 check($('msSourceList').textContent.includes('<img src=x onerror=bad()>'),'source filename displayed literally');equal($('mergeSplitView').querySelectorAll('img[onerror]').length,0,'filenames do not inject markup');
 equal(ms.model.sources.get(bid).bytes,editedBeta,'source uses latest edits');
 $('msPoints').value='3, 7';$('msPoints').dispatchEvent(new window.Event('input'));check($('msZip').disabled,'unapplied points block export');$('msApplyPoints').click();equal(ms.model.rangeText(),'1-3, 4-7, 8-10','split points create three output groups');equal($('msRanges').value,'1-3, 4-7, 8-10','ranges synchronise with points');equal($('msPointsSummary').textContent,'Split after pages 3, 7 · 3 output PDFs','selected points have visible summary');check($('msGrid').querySelector('[data-ms-cut="2"]').getAttribute('aria-pressed')==='true','explicit split control reflects point');
 const beforeInvalidPoints=ms.model.serialise();$('msPoints').value='3, 10';$('msPoints').dispatchEvent(new window.Event('input'));$('msApplyPoints').click();equal(ms.model.serialise(),beforeInvalidPoints,'invalid final split preserves plan');check($('msZip').disabled&&$('msMessage').classList.contains('error'),'invalid split points show error');$('msPrefix').dispatchEvent(new window.Event('input'));equal($('msPoints').value,'3, 10','unapplied points retained across filename input');
 $('msPoints').value='7,3,3';$('msPoints').dispatchEvent(new window.Event('input'));$('msPoints').dispatchEvent(new window.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));equal($('msPoints').value,'3, 7','Enter applies normalised points');
 $('msGrid').querySelector('[data-ms-cut="2"]').click();equal($('msPoints').value,'7','explicit control removes point');equal($('msGrid').querySelector('[data-ms-cut="2"]').textContent,'Split after page 3','removed point shows add action');$('msReset').click();equal($('msPoints').value,'','reset clears points');
 $('msGrid').querySelector('[data-ms-page="2"]').click();equal($('msRanges').value,'1-3, 4-10','click creates split');check($('msGrid').querySelector('[data-ms-page="2"]').getAttribute('aria-pressed')==='true','marker accessible state');
 equal($('msGrid').querySelector('[data-ms-cut="2"]').textContent,'Remove split after page 3','preview click and explicit control remain synchronised');
 $('msRanges').value='1-3,4-7,8-10';$('msRanges').dispatchEvent(new window.Event('input'));check($('msZip').disabled,'unapplied ranges prevent export');$('msApply').click();
 equal(ms.model.ranges(),[{start:1,end:3},{start:4,end:7},{start:8,end:10}],'three groups applied');equal($('msResults').children.length,3,'three output previews');
 const planBefore=ms.model.serialise();$('msRanges').value='1-3,5-10';$('msRanges').dispatchEvent(new window.Event('input'));$('msApply').click();equal(ms.model.serialise(),planBefore,'invalid ranges preserve prior plan');check($('msZip').disabled&&$('msMessage').classList.contains('error'),'invalid ranges clearly block output');
 $('msPrefix').value='My Report';$('msPrefix').dispatchEvent(new window.Event('input'));equal($('msRanges').value,'1-3,5-10','filename edit does not erase invalid range');
 $('msRanges').value='1-3,4-7,8-10';$('msApply').click();equal($('msResults').firstElementChild.querySelector('strong').textContent,'My-Report-01-pages-1-3.pdf','safe output names preview');
 // Accessible ordering and native drag ordering preserve source-page markers.
 $('msSourceList').querySelector('[data-ms-up="'+bid+'"]').click();equal(ms.model.value.sourceIds,[bid,aid],'move source earlier');check(ms.model.value.breaks.includes(aid+':2')&&ms.model.value.breaks.includes(bid+':0'),'cuts follow source pages');
 const first=$('msSourceList').querySelector('[data-ms-source="'+bid+'"]'),second=$('msSourceList').querySelector('[data-ms-source="'+aid+'"]');first.ondragstart({dataTransfer:{setData(){}},preventDefault(){}});second.ondrop({preventDefault(){}});equal(ms.model.value.sourceIds,[aid,bid],'drag source order');
 equal(ms.model.rangeText(),'1-3, 4-7, 8-10','ranges recover after order restored');
 $('msEvery').click();equal(ms.model.ranges().length,10,'every-page shortcut');$('msReset').click();equal(ms.model.ranges().length,1,'reset shortcut');$('msRanges').value='1-3,4-7,8-10';$('msApply').click();
 const commit=app.local.store.commit.bind(app.local.store),writes=[];app.local.store.commit=async value=>{writes.push(value);return commit(value)};await app.local.flush();check(writes.every(value=>value.documents.length===0),'plan-only saves avoid PDF binary rewrites');
 equal((await app.local.store.getDocument(aid)).snapshot.splitPlan,ms.model.serialise(),'plan committed locally');app.local.store.commit=commit;
 await $('msZip').onclick();check(!$('msSaveZip').hidden,'persistent generated ZIP link');equal(context.downloads.at(-1).name,'My-Report-split.zip','download filename');
 const zipURL=$('msSaveZip').href,zip=readTestZip(await urls.get(zipURL).arrayBuffer());equal(zip.size,4,'three PDFs and README in ZIP');check(zip.get('README.txt').bytes.toString().includes('Output ranges: 1-3, 4-7, 8-10'),'manifest describes output groups');
 const groupTwo=zip.get('My-Report-02-pages-4-7.pdf').bytes;equal(app.Engine.extractTextPDF(groupTwo).length,4,'cross-source group has four pages');check(app.Engine.extractTextPDF(groupTwo)[3].text.includes('LATEST BETA EDIT'),'ZIP includes current edited source');
 equal(app.state.bytes,alpha,'ZIP leaves owner unchanged');equal(app.tabs.find(tab=>tab.id===bid).snapshot.bytes,editedBeta,'ZIP leaves other source unchanged');
 $('msGrid').querySelector('[data-ms-page="0"]').click();check($('msSaveZip').hidden&&revoked.includes(zipURL),'changing plan invalidates old download');$('msRanges').value='1-3,4-7,8-10';$('msApply').click();
 Object.defineProperty(window,'isSecureContext',{configurable:true,value:true});let inHandler=false,pickerCalls=0,written;
 window.showSaveFilePicker=()=>{check(inHandler,'Save As opens in original click handler');pickerCalls++;return Promise.resolve({createWritable:async()=>({write:async blob=>written=blob,close:async()=>{}})})};
 inHandler=true;const exportPromise=$('msZip').onclick();inHandler=false;await exportPromise;equal(pickerCalls,1,'native picker invoked once');check(written instanceof Blob,'ZIP written through native picker');check(!$('msSaveZip').hidden,'saved ZIP retains download link');
 window.showSaveFilePicker=()=>Promise.reject(new DOMException('Cancelled','AbortError'));const previousZip=$('msSaveZip').href;await $('msZip').onclick();equal($('msSaveZip').href,previousZip,'cancelled Save As retains previous export');check(!ms.busy,'cancel unlocks controls');
 window.showSaveFilePicker=()=>Promise.resolve({createWritable:async()=>{throw Error('Denied')}});await $('msZip').onclick();check(!$('msSaveZip').hidden&&$('msMessage').textContent.includes('Use Save generated ZIP'),'failed native write has manual download fallback');delete window.showSaveFilePicker;
 // Pending redactions and edited sources cannot silently export stale plans.
 app.state.marks=[{page:0,rect:[20,20,60,60]}];await $('msZip').onclick();check($('msMessage').textContent.includes('pending redactions'),'pending redactions block export');app.state.marks=[];
 let release;const inspect=ms.api.ensureSafe;ms.api.ensureSafe=()=>new Promise(resolve=>release=resolve);const deferred=$('msZip').onclick();await until(()=>release,'signature inspection');check(!await app.switchTab(bid),'in-flight split export blocks tab switch');ms.api.ensureSafe=inspect;release();await deferred;
 // New merged copy opens in its own tab; source tabs/history remain independent.
 const oldTabCount=app.tabs.length;await $('msMerged').onclick();equal(app.tabs.length,oldTabCount+1,'merged working copy creates one new tab');check(app.activeTabId!==aid&&!ms.isOpen,'merged tab becomes active');equal(app.state.doc.countPages(),10,'merged copy contains all pages');check(app.state.dirty,'merged copy is a new edited document');check(text(app).includes('LATEST BETA EDIT'),'merged tab includes latest edits');
 equal(app.tabs.find(tab=>tab.id===aid).snapshot.bytes,alpha,'merged output leaves alpha original');equal(app.tabs.find(tab=>tab.id===bid).snapshot.bytes,editedBeta,'merged output leaves beta original');
 await app.switchTab(aid);await app.activate('split');equal(ms.model.rangeText(),'1-3, 4-7, 8-10','reopening retains plan');await app.switchTab(aid);check(!ms.isOpen,'clicking owner tab returns to PDF');equal($('main').scrollTop,281,'PDF scroll restored');equal($('main').scrollLeft,17,'horizontal PDF scroll restored');
 await app.closeTab(bid);await app.activate('split');check(ms.available.some(row=>row.id===bid&&!row.open),'closed source remains in local library');equal(ms.model.pages.length,10,'saved source reads closed local copy');
 const savedPlan=ms.model.serialise();await app.local.flush();await context.close();context=await boot();({app,$,window}=context);await until(()=>app.tabs.length===2,'tabs recovered');await app.switchTab(aid);equal(app.state.splitPlan,savedPlan,'fresh instance restores split plan');await app.activate('split');ms=app.mergeSplit;check(ms.model.ready,'restored closed library source resolves');equal(ms.model.rangeText(),'1-3, 4-7, 8-10','restored marker groups');
 await $('msBack').onclick();await app.editPDF('Source changed',doc=>doc.getPage(0).drawText('NEW ALPHA EDIT',{x:20,y:290}));await app.activate('split');check(!ms.model.ready&&ms.model.changed.includes(aid),'changed source detected');check($('msZip').disabled&&$('msMessage').textContent.includes('has changed'),'stale plan blocks export');await $('msRefresh').onclick();check(ms.model.ready,'refresh accepts current source');equal(ms.model.rangeText(),'1-10','refresh requires new split plan');
 // Imports are inactive tabs and do not replace the workspace owner.
 const gamma=await many(app,'GAMMA',1);context.fileSelections.push([file('Gamma.pdf',gamma),{name:'bad.txt',type:'text/plain',arrayBuffer:async()=>new ArrayBuffer(0)}]);const count=app.tabs.length;await $('msUpload').onclick();equal(app.tabs.length,count+1,'valid PDF imported while bad type isolated');equal(app.activeTabId,aid,'upload preserves owner');check(ms.model.pages.length===11&&$('msMessage').textContent.includes('choose a PDF'),'upload adds page and reports invalid source');
 const gammaId=app.tabs.at(-1).id;$('msSourceList').querySelector('[data-ms-remove="'+gammaId+'"]').click();equal(ms.model.pages.length,10,'remove source retains source tab');check(app.tabs.some(tab=>tab.id===gammaId),'removing source does not close tab');
 const protectedBytes=app.Engine.protectPDF(gamma,{password:'split-password',ownerPassword:'owner-password',permissions:-4});const beforeLocked=app.tabs.length;
 context.fileSelections.push([file('Locked.pdf',protectedBytes)]);const cancelled=$('msUpload').onclick();await until(()=>$('splitpw'),'password prompt');$('modalcancel').click();await cancelled;equal(app.tabs.length,beforeLocked,'cancel encrypted import leaves no tab');equal(app.activeTabId,aid,'password cancellation preserves owner');
 context.fileSelections.push([file('Locked.pdf',protectedBytes)]);const unlocked=$('msUpload').onclick();await until(()=>$('splitpw'),'password prompt again');$('splitpw').value='split-password';$('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await unlocked;equal(app.tabs.length,beforeLocked+1,'encrypted upload creates unlocked source tab');check(ms.model.pages.length===11&&ms.isOpen,'encrypted source joins existing plan');const lockedId=app.tabs.at(-1).id;check(app.Engine.extractTextPDF(ms.model.sources.get(lockedId).bytes)[0].text.includes('GAMMA'),'unlocked source readable');$('msSourceList').querySelector('[data-ms-remove="'+lockedId+'"]').click();
 const beforeBroken=ms.model.serialise();context.fileSelections.push([file('Broken.pdf',new Uint8Array([1,2,3]))]);await $('msUpload').onclick();equal(ms.model.serialise(),beforeBroken,'invalid PDF import preserves plan');check($('msMessage').classList.contains('error'),'invalid import error visible');
 const form=await app.PDFLib.PDFDocument.create(),formPage=form.addPage();form.getForm().createTextField('Value').addToPage(formPage,{x:20,y:20,width:80,height:20});context.fileSelections.push([file('Form.pdf',new Uint8Array(await form.save()))]);await $('msUpload').onclick();await $('msZip').onclick();check($('msMessage').textContent.includes('Flatten form'),'form export refuses detached widgets');$('msSourceList').querySelector('[data-ms-remove="'+app.tabs.at(-1).id+'"]').click();
 // A library deletion cannot silently leave an apparently valid saved plan.
 await $('msBack').onclick();await app.local.autosave.remove(bid);await app.activate('split');check(ms.model.missing.includes(bid)&&$('msZip').disabled,'missing local source blocks export');$('msSourceList').querySelector('[data-ms-remove="'+bid+'"]').click();check(ms.model.ready&&ms.model.pages.length===6,'remove missing source recovers plan');
 await app.activate('split');check(!ms.isOpen&&!$('viewer').classList.contains('hidden'),'same feature toggles back to PDF');
 const big=await many(app,'LARGE',65);await app.openFiles([file('Large.pdf',big)]);await app.activate('split');ms=app.mergeSplit;equal($('msGrid').children.length,60,'large document grid bounded at 60 previews');check(!$('msLater').disabled&&$('msEarlier').disabled,'first preview batch controls');$('msLater').click();equal($('msGrid').children.length,5,'second preview batch only remaining pages');check($('msLater').disabled&&!$('msEarlier').disabled,'last preview batch controls');equal($('msGrid').firstElementChild.querySelector('button').dataset.msPage,'60','global page indices across batches');
 await $('msBack').onclick();check(ms.docs.size===0&&ms.previews.size===0,'closing releases native handles and preview URLs');check(!window.document.body.classList.contains('split-workspace-open'),'PDF layout restored');
 // Failed setup remains recoverable through Back, with unavailable actions disabled.
 const listSources=ms.api.listSources;ms.api.listSources=async()=>{throw Error('Fixture catalogue failure')};await app.activate('split');check($('msMessage').textContent.includes('Fixture catalogue failure'),'setup failure explained');check($('msUpload').disabled&&$('msZip').disabled&&!$('msBack').disabled,'failed setup disables dependent controls');ms.api.listSources=listSources;await $('msBack').onclick();check(!ms.isOpen,'Back recovers from failed setup');
 await context.close();context=null;
 console.log('pdfpro merge/split interface: '+assertions+' assertions passed in controlled DOM, simulated IndexedDB and real PDFs.');
}finally{if(context)await context.close();URL.createObjectURL=createURL;URL.revokeObjectURL=revokeURL}
