/* Compact on-page text editor. The saved PDF uses its original font. */
export function openDirectEditor({overlay,target,bounds,zoom,apply,onClose,fontData}){
  const document=overlay.ownerDocument,form=document.createElement('form');form.className='direct-editor';form.setAttribute('aria-label','Direct edit');
  const input=document.createElement(target.kind==='added'?'textarea':'input');input.className='direct-editor-input';input.setAttribute('aria-label','Edit PDF text');input.value=target.text;input.spellcheck=false;
  if(input.tagName==='INPUT')input.type='text';
  const face=target.fontName.replace(/^[A-Z]{6}\+/,'');
  const family=/courier|mono/i.test(face)?'Courier New':/times|roman|serif/i.test(face)&&!/sans/i.test(face)?'Times New Roman':/helvetica|sans|arial/i.test(face)?'Arial':face;
  Object.assign(input.style,{fontFamily:'"'+family.replace(/["\\]/g,'')+'", sans-serif',fontSize:Math.max(4,target.size*zoom)+'px',fontWeight:target.bold?'700':'400',fontStyle:target.italic?'italic':'normal',color:target.color});
  const left=Math.max(0,(target.rect[0]-bounds[0])*zoom),top=Math.max(0,(target.rect[1]-bounds[1])*zoom),available=Math.max(80,(bounds[2]-bounds[0])*zoom-left-8);
  Object.assign(form.style,{left:left+'px',top:top+'px',width:Math.min(available,Math.max(180,(target.rect[2]-target.rect[0])*zoom+24))+'px'});
  input.style.minHeight=Math.min(target.kind==='added'?120:64,Math.max(26,(target.rect[3]-target.rect[1])*zoom+6))+'px';
  const bar=document.createElement('div');bar.className='direct-editor-bar';
  const label=document.createElement('span');label.className='direct-editor-style';label.textContent=face+' · '+Math.round(target.size*100)/100+' pt · '+target.color;label.title='The saved PDF retains its original font, colour and size. The typing preview uses a matching local font when available.';
  const save=document.createElement('button');save.type='submit';save.className='primary small';save.textContent='Apply';
  const cancel=document.createElement('button');cancel.type='button';cancel.className='small';cancel.textContent='Cancel';
  const error=document.createElement('div');error.className='direct-editor-error';error.setAttribute('role','alert');
  bar.append(label,save,cancel);form.append(input,bar,error);overlay.append(form);
  let busy=false,closed=false,faceObject=null;
  const close=()=>{if(closed)return;closed=true;form.remove();if(faceObject)document.fonts?.delete(faceObject);onClose?.()};
  const FontFace=document.defaultView.FontFace;
  if(fontData&&FontFace&&document.fonts){
    try{
    const name='PdfProDirect'+Math.random().toString(36).slice(2),face=new FontFace(name,fontData,{weight:target.bold?'700':'400',style:target.italic?'italic':'normal'});
    void face.load().then(loaded=>{if(closed)return;faceObject=loaded;document.fonts.add(loaded);input.style.fontFamily=name}).catch(()=>{});
    }catch{}
  }
  cancel.onclick=()=>{if(!busy)close()};
  for(const event of ['pointerdown','pointerup','click'])form.addEventListener(event,e=>e.stopPropagation());
  form.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();if(!busy)close()}else if(event.key==='Enter'&&(input.tagName==='INPUT'||event.ctrlKey||event.metaKey)){event.preventDefault();void submit()}});
  const submit=async()=>{if(busy||closed)return;busy=true;save.disabled=cancel.disabled=input.disabled=true;error.textContent='';try{const applied=await apply(input.value);if(applied!==false)close()}catch(e){error.textContent=e.message}finally{busy=false;save.disabled=cancel.disabled=input.disabled=false;if(!closed)input.focus({preventScroll:true})}};
  form.onsubmit=event=>{event.preventDefault();return submit()};input.focus({preventScroll:true});input.select();return{close,form,input};
}
