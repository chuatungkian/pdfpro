/* Continuous page layout with bounded, local PDF rasterisation. AGPL-3.0-or-later. */
import * as Engine from './engine.js';
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
export class ContinuousPages{
  constructor({root,viewer,wrap,canvas,overlay,api}){
    Object.assign(this,{root,viewer,wrap,canvas,overlay,api});this.records=[];this.current=0;this.generation=0;this.cache=new Map();this.disposed=false;
    this.scroll=()=>{clearTimeout(this.scrollTimer);if(this.atRestoredPosition())return;this.restoredPosition=null;this.api.cancelGesture();this.scrollTimer=setTimeout(()=>this.followScroll(),35)};
    this.pointer=event=>{
      const row=event.composedPath().find(node=>node?.classList?.contains('pdf-page-row'));
      if(!row||!event.composedPath().some(node=>node?.classList?.contains('pdf-page-overlay'))||!this.api.visible())return;
      const index=+row.dataset.pdfPage;if(index!==this.current){if(!this.api.canActivate()){event.preventDefault();event.stopPropagation();return}this.activate(index)}
    };
    root.addEventListener('scroll',this.scroll,{passive:true});viewer.addEventListener('pointerdown',this.pointer,true);
    root.tabIndex=0;viewer.setAttribute('aria-label','PDF pages · scroll to move between pages');
  }
  reset(){
    this.generation++;clearTimeout(this.scrollTimer);this.restoredPosition=null;this.cache.clear();this.doc=null;this.bytes=null;
    // Preserve the original interactive overlay so captured pointers and callers keep one target.
    if(this.overlay.parentElement){this.wrap=this.overlay.parentElement;this.canvas=this.wrap.querySelector('canvas')||this.canvas}
    this.wrap.id='pagewrap';this.canvas.id='pagecanvas';this.overlay.replaceChildren();
    for(const record of this.records)if(record.canvas!==this.canvas){record.canvas.width=1;record.canvas.height=1}
    this.records=[];this.viewer.replaceChildren(this.wrap);
  }
  async update({doc,bytes,page,zoom,fit,width,dpr=1,valid=()=>true}){
    const changed=doc!==this.doc||bytes!==this.bytes;
    if(changed){this.reset();this.doc=doc;this.bytes=bytes;this.metadata=null}
    const generation=++this.generation,alive=()=>!this.disposed&&generation===this.generation&&valid();
    let built=false;
    if(!this.metadata){
      const metadata=[];
      for(let i=0;i<doc.countPages();i++){
        if(!alive())return false;const native=doc.loadPage(i);
        try{const bounds=native.getBounds(),w=bounds[2]-bounds[0],h=bounds[3]-bounds[1];if(!(w>0&&h>0&&Number.isFinite(w*h)))throw Error('Page '+(i+1)+' has invalid dimensions.');metadata.push({bounds,width:w,height:h})}finally{native.destroy()}
        if(i&&i%64===0)await tick();
      }
      if(!alive())return false;
      this.metadata=metadata;this.build(clamp(page,0,metadata.length-1));built=true;
    }
    if(!alive())return false;
    const widest=this.metadata.reduce((max,p)=>Math.max(max,p.width),0),area=this.metadata.reduce((max,p)=>Math.max(max,p.width*p.height),0);
    dpr=clamp(dpr||1,1,2);if(fit)zoom=clamp((Math.max(100,width)-64)/widest,.25,1.6);
    zoom=Math.min(zoom,Math.sqrt(30000000/area)/dpr);const scaleChanged=zoom!==this.zoom||dpr!==this.dpr;
    const anchor=this.records[this.current],previous=anchor&&this.zoom?{page:this.current,offset:(this.root.scrollTop-this.pageTop(this.current))/this.zoom}:null;
    this.zoom=zoom;this.dpr=dpr;this.api.scale(zoom);
    if(changed||built||scaleChanged){
      this.cache.clear();let top=0;
      this.records.forEach((record,i)=>{const info=this.metadata[i],w=Math.round(info.width*zoom),h=Math.round(info.height*zoom);record.top=top;record.height=h+22;record.width=w;top+=record.height+24;record.row.style.width=w+'px';record.view.style.width=w+'px';record.view.style.height=h+'px';record.canvas.style.width=w+'px';record.canvas.style.height=h+'px';record.canvas.width=1;record.canvas.height=1;record.painted=false;record.overlay.replaceChildren();record.hits=[]});
      this.viewer.style.width='max(100%, '+(Math.round(widest*zoom)+64)+'px)';
    }
    this.activate(clamp(page,0,this.records.length-1),false);this.paint(this.current);
    if(scaleChanged&&!changed&&previous&&previous.page===page&&this.root.clientHeight>0)this.root.scrollTop=this.pageTop(page)+previous.offset*zoom;
    this.queueNearby(generation);return true;
  }
  build(page){
    const document=this.viewer.ownerDocument,fragment=document.createDocumentFragment();
    this.records=this.metadata.map((info,index)=>{
      const row=document.createElement('section');row.className='pdf-page-row';row.dataset.pdfPage=String(index);row.setAttribute('aria-label','Page '+(index+1));
      const label=document.createElement('div');label.className='pdf-page-label';label.textContent='Page '+(index+1);row.append(label);
      const view=index===page?this.wrap:document.createElement('div'),canvas=index===page?this.canvas:document.createElement('canvas'),overlay=index===page?this.overlay:document.createElement('div');
      view.className='pdf-page-view';overlay.classList.add('pdf-page-overlay');canvas.classList.add('pdf-page-canvas');
      if(index!==page)view.append(canvas,overlay);row.append(view);fragment.append(row);return{row,view,canvas,overlay,hits:[],painted:false};
    });
    this.current=page;this.viewer.replaceChildren(fragment);this.records[page]?.row.setAttribute('aria-current','page');
  }
  activate(index,notify=true){
    const next=this.records[index];if(!next)return false;
    const previous=this.records[this.current];
    if(index!==this.current){
      previous.view.removeAttribute('id');previous.canvas.removeAttribute('id');previous.row.removeAttribute('aria-current');
      const other=next.overlay,children=[...this.overlay.childNodes];this.overlay.replaceChildren(...other.childNodes);other.replaceChildren(...children);
      previous.view.replaceChild(other,this.overlay);next.view.append(this.overlay);previous.overlay=other;next.overlay=this.overlay;
      this.current=index;
    }
    next.view.id='pagewrap';next.canvas.id='pagecanvas';next.row.setAttribute('aria-current','page');this.wrap=next.view;this.canvas=next.canvas;
    this.paint(index);if(notify)this.api.activate(index,next.hits);return true;
  }
  paint(index){
    const record=this.records[index];if(!record||!this.doc||this.zoom===undefined)return;
    if(!record.painted){
      const native=this.doc.loadPage(index);let pix;
      try{
        const b=this.metadata[index].bounds,scale=this.zoom*this.dpr;
        pix=native.toPixmap([scale,0,0,scale,-b[0]*scale,-b[1]*scale],Engine.mupdf.ColorSpace.DeviceRGB,true,true);
        record.canvas.width=pix.getWidth();record.canvas.height=pix.getHeight();record.canvas.setAttribute('aria-label','PDF page '+(index+1));
        record.canvas.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(pix.getPixels()),pix.getWidth(),pix.getHeight()),0,0);
        record.painted=true;record.hits=this.api.layers(index,record.overlay)||[];
      }finally{pix?.destroy();native.destroy()}
    }
    this.cache.delete(index);this.cache.set(index,record.canvas.width*record.canvas.height);this.trim();
  }
  trim(){
    let pixels=[...this.cache.values()].reduce((sum,n)=>sum+n,0);
    for(const [index,area] of this.cache){
      if(this.cache.size<=6&&pixels<=45000000)break;if(index===this.current)continue;
      const record=this.records[index];if(record.row.contains(this.viewer.ownerDocument.activeElement))continue;
      record.canvas.width=1;record.canvas.height=1;record.overlay.replaceChildren();record.hits=[];record.painted=false;this.cache.delete(index);pixels-=area;
    }
  }
  redrawLayers(){
    for(const [index] of this.cache){const record=this.records[index];record.hits=this.api.layers(index,record.overlay)||[]}
    return this.records[this.current]?.hits||[];
  }
  padding(){const style=this.viewer.ownerDocument.defaultView.getComputedStyle(this.viewer),value=parseFloat(style.paddingTop);return Number.isFinite(value)?value:52}
  pageTop(index){return(this.viewer.offsetTop||0)+this.padding()+(this.records[index]?.top||0)}
  captureView(){return{top:this.root.scrollTop,left:this.root.scrollLeft,zoom:this.zoom||1,offset:this.records[this.current]?this.root.scrollTop-this.pageTop(this.current):null}}
  restoreView(view,page=this.current){
    if(!view)return;const ratio=(this.zoom||1)/view.zoom;
    this.root.scrollTop=Math.max(0,view.offset!==null&&this.records[page]?this.pageTop(page)+view.offset*ratio:view.top);
    this.root.scrollLeft=Math.max(0,view.left*ratio);this.restoredPosition={top:this.root.scrollTop,left:this.root.scrollLeft};clearTimeout(this.scrollTimer);this.queueNearby();
  }
  atRestoredPosition(){return this.restoredPosition&&Math.abs(this.root.scrollTop-this.restoredPosition.top)<.5&&Math.abs(this.root.scrollLeft-this.restoredPosition.left)<.5}
  indexAt(position){
    let low=0,high=this.records.length-1;while(low<high){const mid=Math.ceil((low+high)/2);if(this.records[mid].top<=position)low=mid;else high=mid-1}return low;
  }
  viewportRange(){
    if(!this.records.length)return[0,0];const h=this.root.clientHeight;
    if(!h)return[Math.max(0,this.current-1),Math.min(this.records.length-1,this.current+1)];
    const top=this.root.scrollTop-this.pageTop(0);return[this.indexAt(Math.max(0,top-h*.65)),this.indexAt(top+h*1.65)];
  }
  queueNearby(generation=this.generation){
    const [first,last]=this.viewportRange(),indices=[];for(let i=first;i<=last;i++)if(i!==this.current)indices.push(i);
    indices.sort((a,b)=>Math.abs(a-this.current)-Math.abs(b-this.current));
    void(async()=>{for(const index of indices.slice(0,5)){await tick();if(this.disposed||generation!==this.generation||!this.api.visible())return;try{this.paint(index)}catch(error){const record=this.records[index];record.row.dataset.renderError=error.message;record.row.querySelector('.pdf-page-label').textContent='Page '+(index+1)+' · preview unavailable'}}})();
  }
  followScroll(){
    if(!this.api.visible()||!this.doc||!this.records.length||!this.root.clientHeight)return;
    if(this.atRestoredPosition())return;this.restoredPosition=null;
    const position=this.root.scrollTop-this.pageTop(0)+Math.min(this.root.clientHeight*.35,180),atBottom=this.root.scrollHeight>this.root.clientHeight+1&&this.root.scrollTop+this.root.clientHeight>=this.root.scrollHeight-2,index=atBottom?this.records.length-1:this.indexAt(Math.max(0,position));
    if(index!==this.current&&this.api.canActivate()&&this.viewer.ownerDocument.defaultView.getSelection()?.isCollapsed!==false)this.activate(index);
    this.queueNearby();
  }
  scrollToPage(index){if(!this.records[index])return;this.restoredPosition=null;clearTimeout(this.scrollTimer);this.root.scrollTop=Math.max(0,this.pageTop(index)-this.padding());this.queueNearby()}
  destroy(){this.disposed=true;this.reset();this.root.removeEventListener('scroll',this.scroll);this.viewer.removeEventListener('pointerdown',this.pointer,true)}
}
