/* Rebuild the complete offline source ZIP from shared runtime bytes and one
 * compressed copy of each remaining source file. AGPL-3.0-or-later.
 * Existing DEFLATE chunks are copied directly; no ZIP decoder is needed.
 */
const encoder=new TextEncoder();
const table=Uint32Array.from({length:256},(_,i)=>{let c=i;for(let j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0});
export function sourceCRC(bytes){let c=0xffffffff;for(const value of bytes)c=table[(c^value)&255]^(c>>>8);return(c^0xffffffff)>>>0}
export function decodeSourceBytes(value){
  if(typeof value!=='string')throw Error('An embedded source asset is missing.');
  return Uint8Array.from(atob(value),character=>character.charCodeAt(0));
}
function sharedBytes(assets,key,fontBase64){
  switch(key){
    case 'mupdf':return decodeSourceBytes(assets.mupdfBase64);
    case 'ocr-wasm':return decodeSourceBytes(assets.ocr?.coreWasmBase64);
    case 'ocr-model':return decodeSourceBytes(assets.ocr?.languageDataBase64);
    case 'ocr-worker':if(typeof assets.ocr?.workerSource==='string')return encoder.encode(assets.ocr.workerSource);break;
    case 'ocr-core':if(typeof assets.ocr?.coreSource==='string')return encoder.encode(assets.ocr.coreSource);break;
    case 'notices':if(typeof assets.notices==='string')return encoder.encode(assets.notices);break;
    case 'inter':return decodeSourceBytes(fontBase64);
  }
  throw Error('Unknown or missing embedded source asset: '+key);
}
async function compressShared(bytes,Compression){
  if(Compression){
    try{
      // 'deflate' has the same browser baseline as the existing gzip loader.
      // Strip its two-byte zlib header and four-byte checksum for ZIP method 8.
      const stream=new Blob([bytes]).stream().pipeThrough(new Compression('deflate'));
      const wrapped=new Uint8Array(await new Response(stream).arrayBuffer());
      if(wrapped.length>=6&&(wrapped[0]&15)===8&&(wrapped[0]>>4)<=7&&!(wrapped[1]&32)&&((wrapped[0]<<8)|wrapped[1])%31===0){
        const raw=wrapped.subarray(2,wrapped.length-4);
        if(raw.length<bytes.length)return{method:8,data:raw};
      }
    }catch{/* A valid stored ZIP preserves export when compression is unavailable. */}
  }
  return{method:0,data:bytes};
}
function checkedName(value,names){
  if(typeof value!=='string'||!value.startsWith('source/')||value.includes('\\')||value.includes('\0')||value.split('/').some(part=>!part||part==='.'||part==='..')||names.has(value))throw Error('Invalid path in the embedded source archive.');
  names.add(value);const name=encoder.encode(value);
  if(name.length>65535)throw Error('An embedded source path is too long.');
  return name;
}
function archiveBlob(entries){
  const parts=[],central=[];let offset=0;
  for(const entry of entries){
    const {name,data,size,crc,method}=entry,h=new DataView(new ArrayBuffer(30)),c=new DataView(new ArrayBuffer(46));
    if(offset+30+name.length+data.length>0xffffffff)throw Error('The source archive exceeds the ZIP size limit.');
    h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(8,method,true);h.setUint32(14,crc,true);h.setUint32(18,data.length,true);h.setUint32(22,size,true);h.setUint16(26,name.length,true);
    c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(10,method,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,size,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);
    parts.push(h.buffer,name,data);central.push(c.buffer,name);offset+=30+name.length+data.length;
  }
  const centralSize=central.reduce((sum,part)=>sum+part.byteLength,0),end=new DataView(new ArrayBuffer(22));
  if(offset+centralSize>0xffffffff)throw Error('The source archive exceeds the ZIP size limit.');
  end.setUint32(0,0x06054b50,true);end.setUint16(8,entries.length,true);end.setUint16(10,entries.length,true);end.setUint32(12,centralSize,true);end.setUint32(16,offset,true);
  return new Blob([...parts,...central,end.buffer],{type:'application/zip'});
}
export async function rebuildSourceZip(assets,{fontBase64,Compression=globalThis.CompressionStream}={}){
  // Retain compatibility with older full-archive payloads.
  if(!assets?.sourceArchive){if(assets?.sourceZip)return new Blob([decodeSourceBytes(assets.sourceZip)],{type:'application/zip'});throw Error('The embedded source archive is missing.')}
  const archive=assets.sourceArchive;
  if(archive.version!==1||!Array.isArray(archive.entries)||archive.entries.length>65535)throw Error('Unsupported embedded source archive.');
  const pool=decodeSourceBytes(archive.poolBase64),entries=[],shared=new Map(),names=new Set();
  for(const record of archive.entries){
    const name=checkedName(record.name,names),{size,crc}=record;
    if(!Number.isSafeInteger(size)||size<0||size>0xffffffff||!Number.isInteger(crc)||crc<0||crc>0xffffffff)throw Error('Invalid embedded source metadata.');
    let chunk;
    if(record.asset){
      if(!shared.has(record.asset)){
        const bytes=sharedBytes(assets,record.asset,fontBase64);
        shared.set(record.asset,{...await compressShared(bytes,Compression),size:bytes.length,crc:sourceCRC(bytes)});
      }
      chunk=shared.get(record.asset);
      if(chunk.size!==size||chunk.crc!==crc)throw Error('An embedded source asset failed its integrity check: '+record.asset);
    }else{
      const {offset,length}=record;
      if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||offset<0||length<0||offset+length>pool.length)throw Error('Invalid embedded source chunk.');
      chunk={method:8,data:pool.subarray(offset,offset+length)};
    }
    entries.push({name,size,crc,...chunk});
  }
  return archiveBlob(entries);
}
