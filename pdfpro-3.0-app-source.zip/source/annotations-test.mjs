/* Run with: node annotations-test.mjs */
import assert from 'node:assert/strict';
import * as mupdf from 'mupdf';
import { PDFDocument, PDFName, PDFRawStream, decodePDFRawStream } from 'pdf-lib';
import { createTextAnnotation } from './annotations.js';

let assertions = 0;
function check(condition, message) { assertions++; assert.ok(condition, message); }
function expectError(fn, matcher, message) { assertions++; assert.throws(fn, matcher, message); }
function newDocument(rotation = 0) {
  const doc = new mupdf.PDFDocument();
  // Nonzero media origin verifies page/user coordinate conversion as well.
  doc.insertPage(-1, doc.addPage([10, 20, 330, 340], rotation, {}, '0.8 0.85 0.9 rg 10 20 320 320 re f'));
  return doc;
}
function save(doc) {
  const buffer = doc.saveToBuffer('garbage=4,compress');
  try { return buffer.asUint8Array().slice(); } finally { buffer.destroy(); }
}
function pixelStats(annotation) {
  const pixmap = annotation.toPixmap(mupdf.Matrix.identity, mupdf.ColorSpace.DeviceRGB, true);
  try {
    const data = pixmap.getPixels(), width = pixmap.getWidth(), height = pixmap.getHeight(), components = pixmap.getNumberOfComponents(), stride = pixmap.getStride();
    let visible = 0, transparent = 0, solid = 0, interiorVisible = 0;
    let minX = width, minY = height, maxX = -1, maxY = -1;
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
      const alpha = data[y * stride + x * components + components - 1];
      if (alpha) { visible++; minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); }
      if (alpha > 220) solid++;
      if (!alpha) transparent++;
      if (x > 5 && x < width - 6 && y > 5 && y < height - 6 && alpha) interiorVisible++;
    }
    return { visible, transparent, solid, interiorVisible, total: width * height, minX, minY, maxX, maxY, width, height };
  } finally { pixmap.destroy(); }
}
function appearanceText(annotation) {
  const list = annotation.toDisplayList(), structured = list.toStructuredText('preserve-spans');
  try { return { text: structured.asText(), data: JSON.parse(structured.asJSON()) }; }
  finally { structured.destroy(); list.destroy(); }
}
const compact = text => text.replace(/\s/gu, '').normalize('NFC');
const color = [0, .4, .25];

// Reproduce the reported bug, so the regression checks distinguish a filled
// rectangle from actual glyph-shaped pixels rather than checking /Contents only.
{
  const doc = newDocument(), page = doc.loadPage(0), annotation = page.createAnnotation('FreeText');
  try {
    annotation.setRect([20, 20, 220, 70]); annotation.setContents('Visible words');
    annotation.setColor(color); annotation.setDefaultAppearance('Helv', 16, color); annotation.update();
    const stats = pixelStats(annotation);
    check(stats.solid / stats.total > .95, 'The original same-color FreeText path reproduces an opaque rectangle.');
  } finally { annotation.destroy(); page.destroy(); doc.destroy(); }
}

for (const rotation of [0, 90, 180, 270]) for (const kind of ['freetext', 'stamp']) {
  const doc = newDocument(rotation), page = doc.loadPage(0);
  let annotation, reopened, reopenedPage;
  try {
    // An unrelated annotation must survive unchanged.
    const original = page.createAnnotation('Text');
    original.setRect([260, 240, 280, 260]); original.setContents('Existing note'); original.update(); original.destroy();
    const text = 'Visible comment\nRésumé Ω Ж 中文';
    const rect = [20, 20, 220, 110];
    annotation = createTextAnnotation(doc, page, { kind, rect, text, size: 18, color, author: 'Reviewer' });
    const currentRect = annotation.getRect();
    check(currentRect.every((n, i) => Math.abs(n - rect[i]) < .02), `${kind} retains the selected rectangle on a ${rotation}° page.`);
    check(annotation.getType() === (kind === 'stamp' ? 'Stamp' : 'FreeText'), `${kind} has the correct native subtype.`);
    check(annotation.getContents() === text && annotation.getAuthor() === 'Reviewer', `${kind} retains editable Unicode contents and author.`);
    const stats = pixelStats(annotation);
    check(stats.interiorVisible > 100 && stats.solid > 20, `${kind} paints actual text pixels rather than an empty annotation.`);
    check(stats.transparent / stats.total > .7, `${kind} keeps its background transparent.`);
    check(stats.minX > 0 && stats.minY > 0 && stats.maxX < stats.width - 1 && stats.maxY < stats.height - 1, `${kind} glyphs and border stay inside the rectangle.`);
    const appearance = appearanceText(annotation);
    check(compact(appearance.text) === compact(text), `${kind} appearance contains every requested glyph on a ${rotation}° page.`);
    const lines = appearance.data.blocks.filter(block => block.type === 'text').flatMap(block => block.lines || []);
    check(lines.every(line => line.wmode === 0 && line.bbox.w > line.bbox.h), `${kind} stays horizontal and upright after page rotation.`);
    const bytes = save(doc);
    reopened = mupdf.Document.openDocument(bytes, 'application/pdf').asPDF(); reopened.disableJS();
    reopenedPage = reopened.loadPage(0);
    const annotations = reopenedPage.getAnnotations();
    check(annotations.length === 2 && annotations.some(a => a.getContents() === 'Existing note'), 'Existing annotations survive saving and reopening.');
    const restored = annotations.find(a => a.getContents() === text);
    check(restored && compact(appearanceText(restored).text) === compact(text), `${kind} retains visible text after reopening.`);
    check(pixelStats(restored).transparent / pixelStats(restored).total > .7, `${kind} remains transparent after reopening.`);

    // Independent parser verifies that saved /AP is a text/vector Form stream,
    // not merely stored Contents, an opaque fill, or a raster image substitute.
    const independent = await PDFDocument.load(bytes);
    const refs = independent.getPage(0).node.Annots().asArray();
    const dictionary = refs.map(ref => independent.context.lookup(ref)).find(obj => obj.get(PDFName.of('Subtype'))?.toString() === (kind === 'stamp' ? '/Stamp' : '/FreeText'));
    const normal = dictionary.lookup(PDFName.of('AP')).lookup(PDFName.of('N'));
    check(normal instanceof PDFRawStream, `${kind} saves a real normal appearance stream.`);
    const stream = new TextDecoder().decode(decodePDFRawStream(normal).decode());
    check(stream.includes('BT') && /T[Jj]/.test(stream) && !stream.includes(' re\nf'), `${kind} appearance paints text without a solid rectangular background.`);
    check(dictionary.lookup(PDFName.of('C')).size() === 0, `${kind} does not set a fill color in /C.`);
  } finally { annotation?.destroy(); reopenedPage?.destroy(); reopened?.destroy(); page.destroy(); doc.destroy(); }
}

{
  const doc = newDocument(), page = doc.loadPage(0);
  try {
    const long = 'Long text must wrap and remain fully visible. '.repeat(6).trim();
    const annotation = createTextAnnotation(doc, page, { kind: 'freetext', rect: [20, 20, 220, 110], text: long, size: 30, color });
    try {
      check(annotation.pdfproLayout.shrunk && annotation.pdfproLayout.size >= 4 && annotation.pdfproLayout.lineCount > 1, 'Long text wraps and shrinks to fit the complete message.');
      check(compact(appearanceText(annotation).text) === compact(long), 'Fitting does not drop trailing words.');
    } finally { annotation.destroy(); }
    const before = page.getAnnotations().length;
    expectError(() => createTextAnnotation(doc, page, { kind: 'stamp', rect: [20, 20, 40, 40], text: 'Cannot fit '.repeat(100), size: 30, color }), error => error.code === 'ANNOTATION_TEXT_OVERFLOW', 'Unfit text fails explicitly instead of silently clipping.');
    check(page.getAnnotations().length === before, 'Overflow leaves no empty annotation rectangle.');
    for (const text of ['مرحبا بالعالم', 'नमस्ते', 'Unsupported 😀']) {
      expectError(() => createTextAnnotation(doc, page, { kind: 'freetext', rect: [20, 20, 220, 100], text, size: 16, color }), error => error.code === 'UNSUPPORTED_ANNOTATION_GLYPH', 'Missing offline glyphs produce an explicit supported-font error.');
    }
    check(page.getAnnotations().length === before, 'Unsupported glyphs leave no invisible annotation.');
    const composed = createTextAnnotation(doc, page, { kind: 'freetext', rect: [20, 140, 220, 190], text: 'Cafe\u0301', size: 16, color });
    try { check(compact(appearanceText(composed).text) === 'Café', 'Decomposed Latin accents compose and render correctly.'); }
    finally { composed.destroy(); }
  } finally { page.destroy(); doc.destroy(); }
}

console.log(`pdfpro text annotations: ${assertions} assertions passed.`);
