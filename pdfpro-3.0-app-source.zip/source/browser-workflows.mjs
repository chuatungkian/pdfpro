import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import forge from 'node-forge';
const require=createRequire(import.meta.url);
let pw;try{pw=require('playwright')}catch{pw=require(path.join(process.env.PDFPRO_NODE_MODULES||path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'),'playwright'))}
const browser=await pw.chromium.launch({executablePath:process.env.PDFPRO_BROWSER||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--disable-background-networking']});
const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000},serviceWorkers:'block'}),page=await context.newPage();
const errors=[],requests=[],checks=[];
page.on('pageerror',e=>errors.push(e.message));
await context.route(/^https?:\/\//,r=>{requests.push(r.request().url());return r.abort()});
const assert=(ok,msg)=>{if(!ok)throw Error(msg);checks.push(msg);console.log('PASS '+msg)};
const idle=()=>page.waitForFunction(()=>!!window.PdfPro&&!window.PdfPro.state.abort&&!document.getElementById('modalroot').firstChild,{timeout:60000});
async function region(tool,x0,y0,x1,y1){await page.evaluate(async tool=>{await window.PdfPro.activate(tool)},tool);const {x,y,zoom,bounds}=await page.evaluate(()=>{const r=document.getElementById('overlay').getBoundingClientRect(),p=window.PdfPro.state.doc.loadPage(window.PdfPro.state.page),bounds=p.getBounds();p.destroy();return{x:r.left,y:r.top,zoom:window.PdfPro.state.zoom,bounds}});await page.mouse.move(x+(x0-bounds[0])*zoom,y+(y0-bounds[1])*zoom);await page.mouse.down();await page.mouse.move(x+(x1-bounds[0])*zoom,y+(y1-bounds[1])*zoom,{steps:7});await page.mouse.up()}
try{
await page.goto(pathToFileURL(path.resolve('../../outputs/pdfpro.html')).href,{waitUntil:'load',timeout:60000});await page.waitForFunction(()=>!!window.PdfPro,{timeout:60000});
await page.locator('#newBtn').click();await idle();
await page.evaluate(()=>{window.PdfPro.state.group='Edit'});
await region('text',50,70,250,110);await page.locator('#answer').fill('Hello offline PDF');await page.getByRole('button',{name:'Apply',exact:true}).click();await idle();
assert(await page.evaluate(()=>window.PdfPro.Engine.extractTextPDF(window.PdfPro.state.bytes)[0].text.includes('Hello offline PDF')),'UI add text writes searchable content');
assert(await page.locator('.textline').count()>0,'selectable text overlay');
await page.locator('[data-group="Annotate"]').click();await region('rectangle',40,50,280,130);await idle();
assert(await page.evaluate(()=>{const p=window.PdfPro.state.doc.loadPage(0);return p.getAnnotations().some(a=>a.getType()==='Square')}),'UI real PDF annotation');
await page.locator('[data-group="Forms"]').click();await region('fieldText',50,180,300,220);await page.locator('#answer').fill('test.name');await page.getByRole('button',{name:'Apply',exact:true}).click();await idle();
await page.locator('[data-tool="fill"]').click();await page.locator('#fld0').fill('Valid field');await page.getByRole('button',{name:'Apply',exact:true}).click();await idle();
assert(await page.evaluate(async()=>{const d=await window.PdfPro.PDFLib.PDFDocument.load(window.PdfPro.state.bytes);return d.getForm().getTextField('test.name').getText()==='Valid field'}),'UI creates and fills form field');
await page.locator('[data-tool="flatten"]').click();await page.getByRole('button',{name:'Flatten form',exact:true}).last().click();await idle();
assert(await page.evaluate(()=>window.PdfPro.Engine.inspectPDF(window.PdfPro.state.bytes).forms===0),'UI flatten removes widgets cleanly');
await page.locator('[data-group="View"]').click();await page.locator('[data-tool="bookmarks"]').click();await page.locator('[name=title]').fill('Résumé 日本語');await page.getByRole('button',{name:'Add bookmark'}).click();await idle();
assert(await page.evaluate(()=>window.PdfPro.state.doc.loadOutline()[0].title==='Résumé 日本語'),'Unicode bookmark survives export');
await page.locator('[data-group="Organize"]').click();await page.locator('[data-tool="duplicate"]').click();await idle();
assert(await page.evaluate(()=>window.PdfPro.state.doc.countPages()===2),'UI duplicate flattened page');
await page.locator('[data-group="Protect & sign"]').click();await page.locator('[data-tool="encrypt"]').click();await page.locator('#encpw').fill('private-test');await page.locator('#encpw2').fill('private-test');const encDownload=page.waitForEvent('download');await page.getByRole('button',{name:'Download encrypted PDF'}).click();const enc=await encDownload;await enc.saveAs('browser-encrypted.pdf');await idle();
assert(fs.statSync('browser-encrypted.pdf').size>1000,'UI encrypted PDF download');
// Actual OCR action adds an invisible searchable text layer to an image-only PDF.
await page.evaluate(async()=>{const a=window.PdfPro,c=document.createElement('canvas');c.width=1200;c.height=300;const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#000';ctx.font='72px Arial';ctx.fillText('SEARCHABLE OFFLINE 987',30,150);const d=await a.PDFLib.PDFDocument.create(),im=await d.embedPng(c.toDataURL('image/png'));const p=d.addPage([600,150]);p.drawImage(im,{x:0,y:0,width:600,height:150});await a.setBytes(await d.save(),{record:false});a.state.group='OCR & compare';a.activate('ocr')});
await page.getByRole('button',{name:'Run OCR',exact:true}).click();await page.waitForFunction(()=>!window.PdfPro.state.abort,{timeout:120000});if(await page.locator('#modaltitle').count())await page.locator('#modalcancel').click();await idle();
assert(await page.evaluate(()=>window.PdfPro.Engine.extractTextPDF(window.PdfPro.state.bytes)[0].text.includes('OFFLINE')),'UI OCR produces searchable PDF layer');
// Compare identical input, inspect the generated heatmap, and exercise redaction gating.
const same=Buffer.from(await page.evaluate(()=>Array.from(window.PdfPro.state.bytes)));
await page.locator('[data-group="OCR & compare"]').click();
const chooser=page.waitForEvent('filechooser');await page.locator('[data-tool="compare"]').click();const fc=await chooser;await fc.setFiles({name:'same.pdf',mimeType:'application/pdf',buffer:same});
await page.waitForSelector('#compareheatmap canvas',{timeout:60000});
assert((await page.locator('#compareinfo').innerText()).startsWith('0.00%'),'comparison heatmap correctly reports identical PDFs');await page.locator('#modalcancel').click();await idle();
await page.locator('[data-group="Protect & sign"]').click();await region('redact',20,30,350,110);
assert(await page.evaluate(()=>window.PdfPro.state.marks.length===1),'UI redaction mark remains pending');
await page.evaluate(async()=>{try{await window.PdfPro.activate('rotate')}catch(e){window.pendingEditBlocked=e.message}});
assert(await page.evaluate(()=>window.pendingEditBlocked?.includes('pending redaction')&&window.PdfPro.state.marks.length===1),'pending marks cannot silently disappear on edit');
const redownload=page.waitForEvent('download');await page.locator('[data-tool="applyredact"]').click();await page.getByRole('button',{name:'Apply & create copy'}).click();const red=await redownload;await red.saveAs('browser-redacted.pdf');await idle();
assert(await page.evaluate(()=>window.PdfPro.Engine.extractTextPDF(window.PdfPro.state.bytes)[0].text.trim()===''),'UI secure redaction exports an image-only PDF');
const cancelled=await page.evaluate(async()=>{const c=new AbortController();const promise=window.PdfPro.backgroundEngine('optimizePDF',[window.PdfPro.state.bytes],c.signal);setTimeout(()=>c.abort(),5);try{await promise;return false}catch(e){return e.name==='AbortError'}});
assert(cancelled,'background engine cancellation terminates worker');
// Sign through the public UI using an ephemeral test certificate, never a personal key.
const keys=forge.pki.rsa.generateKeyPair(2048),cert=forge.pki.createCertificate();cert.publicKey=keys.publicKey;cert.serialNumber='123456';cert.validity.notBefore=new Date(Date.now()-86400000);cert.validity.notAfter=new Date(Date.now()+86400000*30);cert.setSubject([{name:'commonName',value:'Offline Browser Test'}]);cert.setIssuer(cert.subject.attributes);cert.setExtensions([{name:'keyUsage',digitalSignature:true}]);cert.sign(keys.privateKey,forge.md.sha256.create());const p12=Buffer.from(forge.asn1.toDer(forge.pkcs12.toPkcs12Asn1(keys.privateKey,[cert],'test-only',{algorithm:'3des'})).getBytes(),'binary');
await page.locator('[data-group="Protect & sign"]').click();await page.locator('[data-tool="certsign"]').click();await page.locator('#p12file').setInputFiles({name:'test.p12',mimeType:'application/x-pkcs12',buffer:p12});await page.locator('#p12pw').fill('test-only');const signDownload=page.waitForEvent('download');await page.getByRole('button',{name:'Sign & download'}).click();const signed=await signDownload;await signed.saveAs('browser-signed.pdf');await page.waitForFunction(()=>document.getElementById('modaltitle')?.textContent.includes('signature'),{timeout:60000});
const sig=await page.evaluate(()=>window.PdfProSigning.verifyPdf(window.PdfPro.state.bytes));assert(sig.signatureCount===1&&sig.allCryptographicallyValid&&sig.currentFileCovered,'UI certificate signing and integrity verification');
await page.screenshot({path:'signature-dialog.png',fullPage:true});await page.locator('#modalcancel').click();
assert(requests.length===0&&errors.length===0,'all extended workflows remain offline without runtime errors');
fs.writeFileSync('browser-workflows-results.json',JSON.stringify({checks,requests,errors,browser:await browser.version()},null,2));
}finally{await browser.close()}
