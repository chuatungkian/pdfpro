/* Movable document controls. All positions are relative to the PDF working area.
 * AGPL-3.0-or-later.
 */
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const defaults=()=>({mode:'floating',minimised:false,x:.5,y:0});
export function toolbarPreferences(value){
  const source=value&&typeof value==='object'?value:{},result=defaults();
  if(['floating','top','bottom'].includes(source.mode))result.mode=source.mode;
  result.minimised=source.minimised===true;
  for(const key of ['x','y'])if(Number.isFinite(source[key]))result[key]=clamp(source[key],0,1);
  return result;
}
export class PageToolbar{
  constructor({host,bar,onChange=()=>{},onInteractionStart=()=>{}}){
    this.host=host;this.bar=bar;this.stage=host.parentElement;this.document=host.ownerDocument;this.window=this.document.defaultView;
    this.change=onChange;this.interaction=onInteractionStart;this.value=defaults();this.drag=null;this.disposers=[];
    const find=id=>this.document.getElementById(id);
    this.controls=find('pageToolbarControls');this.handle=find('movePageToolbar');this.toggle=find('minimisePageToolbar');this.summary=find('toolbarCompactSummary');this.options=find('pageToolbarOptions');this.menu=find('pageToolbarMenu');
    const listen=(node,type,fn,options)=>{node.addEventListener(type,fn,options);this.disposers.push(()=>node.removeEventListener(type,fn,options))};
    listen(this.toggle,'click',()=>this.minimise(!this.value.minimised));listen(this.summary,'click',()=>this.minimise(false));
    listen(this.options,'click',()=>this.openMenu(this.menu.hidden));
    this.menu.querySelectorAll('[data-toolbar-mode]').forEach(button=>listen(button,'click',()=>{this.setMode(button.dataset.toolbarMode);this.openMenu(false);this.options.focus()}));
    listen(find('resetPageToolbar'),'click',()=>{this.cancelDrag();this.value={...this.value,mode:'floating',x:.5,y:0};this.interaction();this.refresh();this.openMenu(false);this.change();this.handle.focus()});
    listen(this.handle,'pointerdown',event=>this.startDrag(event));listen(this.handle,'pointermove',event=>this.moveDrag(event));
    listen(this.handle,'pointerup',event=>this.endDrag(event));
    for(const type of ['pointercancel','lostpointercapture'])listen(this.handle,type,event=>{if(this.drag?.pointer===event.pointerId)this.cancelDrag()});
    listen(this.window,'blur',()=>this.cancelDrag());
    listen(this.handle,'keydown',event=>{
      if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)||this.value.mode!=='floating')return;
      event.preventDefault();event.stopPropagation();this.cancelDrag();this.interaction();
      const limits=this.limits(),step=event.shiftKey?32:8,position=this.position(limits);
      if(event.key==='ArrowLeft')position.left-=step;if(event.key==='ArrowRight')position.left+=step;
      if(event.key==='ArrowUp')position.top-=step;if(event.key==='ArrowDown')position.top+=step;
      this.setPixels(position.left,position.top,limits);this.refresh();this.change();
    });
    listen(this.host,'keydown',event=>{
      if(event.key==='Escape'&&this.drag){event.preventDefault();event.stopPropagation();this.cancelDrag();return}
      if(event.key==='Escape'&&!this.menu.hidden){event.preventDefault();event.stopPropagation();this.openMenu(false);this.options.focus();return}
      if(this.menu.hidden||!this.menu.contains(event.target)||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
      event.preventDefault();event.stopPropagation();const buttons=[...this.menu.querySelectorAll('button')],index=buttons.indexOf(this.document.activeElement);
      const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+buttons.length)%buttons.length;
      buttons[next]?.focus();
    });
    const outside=event=>{if(!this.bar.contains(event.target)&&!this.menu.contains(event.target))this.openMenu(false)};
    listen(this.document,'pointerdown',outside);listen(this.document,'click',outside);listen(this.document,'focusin',outside);
    listen(this.window,'resize',()=>this.refresh());listen(this.document,'fullscreenchange',()=>this.refresh());
    if(this.window.ResizeObserver){this.observer=new this.window.ResizeObserver(()=>this.refresh());this.observer.observe(this.host);this.observer.observe(this.bar)}
    this.refresh();
  }
  preferences(){return{...(this.drag?this.drag.original:this.value)}}
  restore(value){this.cancelDrag();this.value=toolbarPreferences(value);this.openMenu(false);this.refresh()}
  minimise(value){this.cancelDrag();this.interaction();this.value.minimised=!!value;this.refresh();this.change()}
  setMode(mode){if(!['floating','top','bottom'].includes(mode))return;this.cancelDrag();this.interaction();this.value.mode=mode;this.refresh();this.change()}
  setPage(page,total){this.summary.textContent=total?'Page '+page+' / '+total:'Page controls';this.summary.setAttribute('aria-label','Restore page toolbar'+(total?', page '+page+' of '+total:''));this.refresh()}
  limits(){
    const hostRect=this.host.getBoundingClientRect(),barRect=this.bar.getBoundingClientRect();
    const width=this.host.clientWidth||hostRect.width,height=this.host.clientHeight||hostRect.height;
    const barWidth=Math.min(this.bar.offsetWidth||barRect.width||400,Math.max(0,width-16)),barHeight=this.bar.offsetHeight||barRect.height||(this.value.minimised?30:40);
    return{width,height,barWidth,barHeight,travelX:Math.max(0,width-barWidth-16),travelY:Math.max(0,height-barHeight-16)};
  }
  position(limits=this.limits()){return{left:8+limits.travelX*this.value.x,top:8+limits.travelY*this.value.y}}
  setPixels(left,top,limits=this.limits()){
    this.value.x=limits.travelX?clamp((left-8)/limits.travelX,0,1):.5;
    this.value.y=limits.travelY?clamp((top-8)/limits.travelY,0,1):0;
  }
  refresh(){
    const {mode,minimised}=this.value;
    this.stage.dataset.toolbarMode=mode;this.stage.classList.toggle('toolbar-minimised',minimised);this.bar.dataset.position=mode;
    this.bar.classList.toggle('minimised',minimised);this.controls.hidden=minimised;this.summary.hidden=!minimised;
    const label=minimised?'Restore page toolbar':'Minimise page toolbar';this.toggle.title=label;this.toggle.setAttribute('aria-label',label);this.toggle.setAttribute('aria-expanded',String(!minimised));
    this.toggle.innerHTML=minimised?'<span aria-hidden="true">＋</span>':'<span aria-hidden="true">−</span>';
    this.handle.disabled=mode!=='floating';this.handle.title=mode==='floating'?'Drag to move · Arrow keys move · Shift moves further':'Choose Floating to move the toolbar';
    this.menu.querySelectorAll('[data-toolbar-mode]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.toolbarMode===mode)));
    const limits=this.limits();if(limits.width>0&&limits.height>0){
      if(mode==='floating'){const position=this.position(limits);this.bar.style.left=position.left+'px';this.bar.style.top=position.top+'px';this.bar.style.bottom='';}
      else{this.bar.style.left='0px';this.bar.style.top=mode==='top'?'0px':'';this.bar.style.bottom=mode==='bottom'?'0px':'';}
      this.positionMenu(limits);
    }
  }
  openMenu(open){this.menu.hidden=!open;this.options.setAttribute('aria-expanded',String(!!open));if(open){this.positionMenu();this.menu.querySelector('[aria-pressed="true"]')?.focus()}}
  positionMenu(limits=this.limits()){
    if(this.menu.hidden||!limits.width||!limits.height)return;
    const menuWidth=Math.min(this.menu.offsetWidth||210,Math.max(0,limits.width-16)),menuHeight=this.menu.offsetHeight||180;
    const position=this.value.mode==='floating'?this.position(limits):{left:0,top:this.value.mode==='bottom'?limits.height-limits.barHeight:0};
    const below=position.top+limits.barHeight+6,top=below+menuHeight<=limits.height-8?below:position.top-menuHeight-6;
    this.menu.style.left=clamp(position.left+limits.barWidth-menuWidth,8,Math.max(8,limits.width-menuWidth-8))+'px';
    this.menu.style.top=clamp(top,8,Math.max(8,limits.height-menuHeight-8))+'px';
  }
  startDrag(event){
    if(this.value.mode!=='floating'||this.drag||event.button!==0||event.isPrimary===false)return;
    event.preventDefault();this.openMenu(false);this.interaction();const limits=this.limits(),position=this.position(limits);
    this.drag={pointer:event.pointerId,startX:event.clientX,startY:event.clientY,left:position.left,top:position.top,original:{...this.value},moved:false};
    this.bar.classList.add('dragging');try{this.handle.setPointerCapture?.(event.pointerId)}catch{}
  }
  moveDrag(event){
    const drag=this.drag;if(!drag||drag.pointer!==event.pointerId)return;event.preventDefault();
    const dx=event.clientX-drag.startX,dy=event.clientY-drag.startY;if(!Number.isFinite(dx)||!Number.isFinite(dy))return;
    drag.moved=drag.moved||Math.hypot(dx,dy)>2;this.setPixels(drag.left+dx,drag.top+dy);this.refresh();
  }
  endDrag(event){if(!this.drag||this.drag.pointer!==event.pointerId)return;this.moveDrag(event);const current=this.drag;this.drag=null;this.bar.classList.remove('dragging');try{this.handle.releasePointerCapture?.(current.pointer)}catch{}if(current.moved)this.change()}
  cancelDrag(){const current=this.drag;if(!current)return;this.drag=null;this.value=current.original;this.bar.classList.remove('dragging');try{this.handle.releasePointerCapture?.(current.pointer)}catch{}this.refresh()}
  destroy(){this.cancelDrag();this.observer?.disconnect();for(const dispose of this.disposers)dispose();this.disposers=[]}
}
