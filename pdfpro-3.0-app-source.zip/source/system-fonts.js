/* Local system-font text rendering. No font downloads or font-file redistribution. */
export const SYSTEM_FONTS=Object.freeze([
  'Arial','Arial Black','Arial Narrow','Aptos','Aptos Display','Calibri','Cambria',
  'Candara','Century Gothic','Comic Sans MS','Consolas','Constantia','Corbel',
  'Courier New','Franklin Gothic Medium','Gabriola','Garamond','Georgia','Helvetica',
  'Impact','Lucida Console','Lucida Sans Unicode','Microsoft Sans Serif',
  'Palatino Linotype','Segoe UI','Segoe Print','Segoe Script','Tahoma',
  'Times New Roman','Verdana'
]);
export function systemFontFamily(name){return '"'+(SYSTEM_FONTS.includes(name)?name:'Arial')+'",Arial,sans-serif'}
const normalise=text=>String(text??'').replace(/\r\n?/g,'\n').replace(/\t/g,'    ').normalize('NFC');
function validateText(text){
  if(!text.trim())throw Error('Enter some text.');
  if([...text].length>10000)throw Error('Text is limited to 10,000 characters.');
  if(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(text))throw Error('Text contains unsupported control characters.');
}
function canvasContext(){const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');if(!ctx)throw Error('Text rendering is unavailable in this browser.');return {canvas,ctx}}
function layoutText(ctx,text,{font,size,width,height,kind}){
  const pad=kind==='stamp'?6:3,available=width-pad*2;
  ctx.font=(kind==='stamp'?'700 ':'')+size+'px '+systemFontFamily(font);ctx.textBaseline='alphabetic';
  const measure=value=>ctx.measureText(value);
  const lines=[];
  for(const paragraph of text.split('\n')){
    let line='';
    for(const token of paragraph.match(/\s+|\S+/gu)||[]){
      if(!line&&/^\s+$/u.test(token))continue;
      if(line&&measure(line+token).width>available){lines.push(line.trimEnd());line=''}
      for(const char of token){
        if(!line&&/^\s$/u.test(char))continue;
        if(line&&measure(line+char).width>available){lines.push(line.trimEnd());line=''}
        line+=char;
      }
    }
    lines.push(line.trimEnd());
  }
  const sample=measure('MgÅgj'),ascent=Math.max(size*.8,sample.actualBoundingBoxAscent||0),descent=Math.max(size*.25,sample.actualBoundingBoxDescent||0);
  const leading=Math.max(size*1.35,ascent+descent+size*.15);
  const total=ascent+descent+(lines.length-1)*leading;
  let fits=available>0&&total<=height-pad*2;
  const baseline=pad+ascent+(kind==='stamp'?Math.max(0,(height-pad*2-total)/2):0);
  const result=lines.map((text,index)=>{
    const m=measure(text),left=Math.max(0,m.actualBoundingBoxLeft||0),right=Math.max(m.width,m.actualBoundingBoxRight||0);
    const extent=left+right;
    const x=pad+left+(kind==='stamp'?Math.max(0,(available-extent)/2):0),y=baseline+index*leading;
    if(extent>available+.01||y-(m.actualBoundingBoxAscent||ascent)<0||y+(m.actualBoundingBoxDescent||descent)>height)fits=false;
    return {text,x,y,width:m.width,ink:[x-left,y-(m.actualBoundingBoxAscent||ascent),x+right,y+(m.actualBoundingBoxDescent||descent)]};
  });
  const ink=result.filter(line=>line.text.trim()).map(line=>line.ink);
  const inkRect=[Math.min(...ink.map(b=>b[0])),Math.min(...ink.map(b=>b[1])),Math.max(...ink.map(b=>b[2])),Math.max(...ink.map(b=>b[3]))];
  return {fits,lines:result,size,font,leading,pad,inkRect};
}
export async function renderSystemText(text,{font='Arial',size=14,width=240,height=60,kind='text',color='#800020',shrink=true}={}){
  text=normalise(text);validateText(text);
  if(!SYSTEM_FONTS.includes(font))throw Error('Choose a font from the font menu.');
  if(![width,height,size].every(Number.isFinite)||width<8||height<8||size<4||size>144)throw Error('Choose a larger text area and a font size from 4 to 144 pt.');
  if(!/^#[\da-f]{6}$/i.test(color))throw Error('Choose a valid text colour.');
  const {canvas,ctx}=canvasContext();
  let layout=layoutText(ctx,text,{font,size,width,height,kind});
  if(!layout.fits&&shrink){
    layout=layoutText(ctx,text,{font,size:4,width,height,kind});
    if(layout.fits){let lo=4,hi=size;for(let i=0;i<12;i++){const mid=(lo+hi)/2,next=layoutText(ctx,text,{font,size:mid,width,height,kind});if(next.fits){lo=mid;layout=next}else hi=mid}}
  }
  if(!layout.fits)throw Error('The complete text does not fit this area. Select a larger area or reduce the text size.');
  // Preserve device-font appearance in the standalone PDF at up to 288 DPI.
  const scale=Math.min(4,Math.sqrt(12000000/(width*height)));
  if(scale<.5)throw Error('This text area is too large. Select a smaller area.');
  canvas.width=Math.ceil(width*scale);canvas.height=Math.ceil(height*scale);
  const paint=canvas.getContext('2d');
  paint.scale(scale,scale);paint.font=(kind==='stamp'?'700 ':'')+layout.size+'px '+systemFontFamily(font);
  paint.textBaseline='alphabetic';paint.fillStyle=color;
  for(const line of layout.lines)paint.fillText(line.text,line.x,line.y);
  const blob=await new Promise((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(Error('Unable to prepare the selected font.')),'image/png'));
  const png=new Uint8Array(await blob.arrayBuffer());
  canvas.width=0;canvas.height=0;
  return {...layout,png,width,height,text,color,kind,shrunk:layout.size<size-.01};
}
export function measureSystemText(text,{font='Arial',size=14}={}){
  const {ctx}=canvasContext();ctx.font=size+'px '+systemFontFamily(font);
  return ctx.measureText(normalise(text)).width;
}
