/* Browser-local PDF workspace persistence. AGPL-3.0-or-later.
 * A PDF snapshot and its catalogue/session updates commit atomically.
 * Revision checks stop another app window from silently overwriting this one.
 */
const DATABASE='pdfpro-local-workspace';
const VERSION=1;
const SESSION='workspace';
const error=(name,message)=>Object.assign(new Error(message),{name});
export class LocalWorkspaceStore{
  constructor(options={}){
    try{this.factory=Object.hasOwn(options,'indexedDB')?options.indexedDB:globalThis.indexedDB}catch(e){this.accessError=e;this.factory=null}
    this.name=options.name||DATABASE;this.db=null;this.opening=null;this.revision=0;
  }
  async open(){
    if(this.db)return this.db;
    if(!this.factory)throw this.accessError||error('StorageUnavailableError','This browser does not provide local document storage here.');
    if(this.opening)return this.opening;
    this.opening=new Promise((resolve,reject)=>{
      let request,settled=false;
      try{request=this.factory.open(this.name,VERSION)}catch(e){reject(e);return}
      request.onupgradeneeded=()=>{for(const name of ['documents','views','catalogue','session'])if(!request.result.objectStoreNames.contains(name))request.result.createObjectStore(name,{keyPath:'id'})};
      request.onerror=()=>{settled=true;reject(request.error||error('StorageUnavailableError','Unable to open local document storage.'))};
      request.onblocked=()=>{settled=true;reject(error('StorageBlockedError','Another pdfpro window is blocking local storage. Close that window and reopen pdfpro.'))};
      request.onsuccess=()=>{
        if(settled){request.result.close();return}
        this.db=request.result;this.db.onversionchange=()=>{this.db?.close();this.db=null};resolve(this.db);
      };
    });
    try{return await this.opening}finally{this.opening=null}
  }
  async readSession(){
    const db=await this.open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction('session','readonly'),request=tx.objectStore('session').get(SESSION);let value;
      request.onsuccess=()=>value=request.result||null;
      tx.oncomplete=()=>{this.revision=value?.revision||0;resolve(value)};
      tx.onabort=tx.onerror=()=>reject(tx.error||request.error||Error('Unable to read the saved workspace.'));
    });
  }
  async getDocuments(ids){
    if(!ids.length)return [];
    const db=await this.open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(['documents','views'],'readonly'),out=new Array(ids.length),views=[];
      ids.forEach((id,index)=>{
        const request=tx.objectStore('documents').get(id);request.onsuccess=()=>out[index]=request.result||null;
        const view=tx.objectStore('views').get(id);view.onsuccess=()=>views[index]=view.result;
      });
      tx.oncomplete=()=>resolve(out.map((record,index)=>record?{...record,snapshot:{...record.snapshot,...views[index]?.view}}:null));
      tx.onabort=tx.onerror=()=>reject(tx.error||Error('Unable to read the saved documents.'));
    });
  }
  async getDocument(id){return (await this.getDocuments([id]))[0]}
  async listDocuments(){
    const db=await this.open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction('catalogue','readonly'),request=tx.objectStore('catalogue').getAll();let rows=[];
      request.onsuccess=()=>rows=request.result;
      tx.oncomplete=()=>resolve(rows.sort((a,b)=>b.updatedAt-a.updatedAt));
      tx.onabort=tx.onerror=()=>reject(tx.error||Error('Unable to read the local library.'));
    });
  }
  async commit({documents=[],views=[],session,removeIds=[]}={}){
    const db=await this.open(),expected=this.revision;
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(['documents','views','catalogue','session'],'readwrite');
      const sessions=tx.objectStore('session'),request=sessions.get(SESSION);let failure,nextRevision;
      request.onsuccess=()=>{
        try{
          const previous=request.result;
          if((previous?.revision||0)!==expected)throw error('WorkspaceConflictError','Another pdfpro window changed this library. Export your current work before reloading this window.');
          const docs=tx.objectStore('documents'),catalogue=tx.objectStore('catalogue');
          for(const record of documents){
            docs.put(record);
            catalogue.put({id:record.id,name:record.snapshot.name,byteLength:record.snapshot.bytes.byteLength,pageCount:record.pageCount,updatedAt:record.updatedAt,contentUpdatedAt:record.updatedAt,contentRevision:expected+1,dirty:record.snapshot.dirty,marks:record.snapshot.marks.length});
          }
          for(const view of views){
            tx.objectStore('views').put(view);
            const metadata=catalogue.get(view.id);
            metadata.onsuccess=()=>{if(metadata.result)catalogue.put({...metadata.result,name:view.view.name,dirty:view.view.dirty,marks:view.view.marks?.length||0,updatedAt:Date.now()})};
          }
          for(const id of removeIds){docs.delete(id);catalogue.delete(id);tx.objectStore('views').delete(id)}
          nextRevision=expected+1;
          const next={...previous,...session,id:SESSION,schema:1,revision:nextRevision,updatedAt:Date.now()};
          if(removeIds.length){next.openIds=(next.openIds||[]).filter(id=>!removeIds.includes(id));if(removeIds.includes(next.activeId))next.activeId=next.openIds[0]||null}
          sessions.put(next);
        }catch(e){failure=e;tx.abort()}
      };
      tx.oncomplete=()=>{this.revision=nextRevision;resolve(nextRevision)};
      tx.onabort=()=>reject(failure||tx.error||Error('The local save did not complete.'));
      tx.onerror=()=>{failure||=tx.error||Error('Unable to save the local workspace.')};
    });
  }
  close(){this.db?.close();this.db=null}
}
