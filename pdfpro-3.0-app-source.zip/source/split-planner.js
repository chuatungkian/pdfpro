/* Native merge/split planning, inspired by chuatungkian/pdfsplitter.
 * AGPL-3.0-or-later. Page identities belong to their source, not merge positions.
 */
const validId=id=>typeof id==='string'&&/^[-a-zA-Z0-9_]{1,80}$/.test(id);
export const pageIdentity=(id,page)=>id+':'+page;
export function splitPrefix(value){return String(value||'document').normalize('NFKC').replace(/\.pdf$/i,'').replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^[. -]+|[. -]+$/g,'').slice(0,80)||'document'}
export function normaliseSplitPlan(value){
  if(!value||value.version!==1||!Array.isArray(value.sourceIds))return null;
  const sourceIds=[...new Set(value.sourceIds.filter(validId))].slice(0,200);if(!sourceIds.length)return null;
  const breaks=Array.isArray(value.breaks)?[...new Set(value.breaks.filter(key=>typeof key==='string'&&/^[-a-zA-Z0-9_]{1,80}:\d+$/.test(key)))].slice(0,100000):[];
  const fingerprints={};for(const id of sourceIds)if(typeof value.fingerprints?.[id]==='string'&&/^[\da-f]+:[\da-f]+:\d+$/i.test(value.fingerprints[id]))fingerprints[id]=value.fingerprints[id];
  return{version:1,sourceIds,breaks,fingerprints,baseName:splitPrefix(value.baseName)};
}
export function parseSplitRanges(text,total){
  if(!Number.isSafeInteger(total)||total<1)throw Error('Add a PDF with at least one page.');
  const cleaned=String(text).replace(/\s/g,'');if(!cleaned)return[{start:1,end:total}];
  const ranges=[];let expected=1;
  for(const part of cleaned.split(',')){
    const match=/^(\d+)(?:-(\d+))?$/.exec(part);if(!match)throw Error('Use consecutive groups, for example 1-3,4-7,8-10.');
    const start=+match[1],end=+(match[2]||match[1]);
    if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start!==expected)throw Error('The next group must begin at page '+expected+'.');
    if(end<start||end>total)throw Error('Group '+part+' must end between '+start+' and '+total+'.');
    ranges.push({start,end});expected=end+1;
  }
  if(expected!==total+1)throw Error('The groups must cover every page through page '+total+'.');return ranges;
}
export function parseSplitPoints(text,total){
  if(!Number.isSafeInteger(total)||total<1)throw Error('Add a PDF with at least one page.');
  if(!String(text).trim())return[];
  if(total===1)throw Error('A one-page PDF has no internal split points.');
  const points=String(text).split(',').map(value=>{const part=value.trim(),page=Number(part);if(!/^\d+$/.test(part)||!Number.isSafeInteger(page)||page<1||page>=total)throw Error('Enter page numbers from 1 to '+Math.max(0,total-1)+', separated by commas. The final page ends the last file automatically.');return page});
  return[...new Set(points)].sort((a,b)=>a-b);
}
export class SplitPlan{
  constructor(saved,sources){
    this.value=normaliseSplitPlan(saved);if(!this.value)throw Error('Invalid split plan.');
    this.sources=sources;this.rebuild();
  }
  rebuild(){
    this.pages=[];this.missing=[];this.changed=[];
    for(const id of this.value.sourceIds){
      const source=this.sources.get(id);if(!source||source.error){this.missing.push(id);continue}
      if(this.value.fingerprints[id]&&this.value.fingerprints[id]!==source.fingerprint)this.changed.push(id);
      for(let page=0;page<source.pageCount;page++)this.pages.push({id,page,key:pageIdentity(id,page),name:source.name});
    }
  }
  get ready(){return this.pages.length>0&&!this.missing.length&&!this.changed.length}
  ranges(){const result=[];let start=1;const cuts=new Set(this.value.breaks);this.pages.forEach((page,index)=>{if(index===this.pages.length-1||cuts.has(page.key)){result.push({start,end:index+1});start=index+2}});return result}
  rangeText(){return this.ranges().map(({start,end})=>start===end?String(start):start+'-'+end).join(', ')}
  toggle(index){if(index<0||index>=this.pages.length-1)return false;const key=this.pages[index].key,cuts=new Set(this.value.breaks);cuts.has(key)?cuts.delete(key):cuts.add(key);this.value.breaks=[...cuts];return true}
  applyRanges(text){const groups=parseSplitRanges(text,this.pages.length);this.value.breaks=groups.slice(0,-1).map(group=>this.pages[group.end-1].key)}
  pointText(){return this.ranges().slice(0,-1).map(group=>group.end).join(', ')}
  applyPoints(text){this.value.breaks=parseSplitPoints(text,this.pages.length).map(page=>this.pages[page-1].key)}
  everyPage(){this.value.breaks=this.pages.slice(0,-1).map(page=>page.key)}
  reset(){this.value.breaks=[]}
  acceptCurrent(){this.reset();this.value.fingerprints=Object.fromEntries(this.value.sourceIds.filter(id=>this.sources.has(id)&&!this.sources.get(id).error).map(id=>[id,this.sources.get(id).fingerprint]));this.rebuild()}
  add(source){if(this.value.sourceIds.includes(source.id))return;if(!validId(source.id)||!Number.isSafeInteger(source.pageCount)||source.pageCount<1)throw Error('Invalid source PDF.');if(this.value.sourceIds.length>=200)throw Error('Use no more than 200 source PDFs in one plan.');this.sources.set(source.id,source);this.value.sourceIds.push(source.id);this.value.fingerprints[source.id]=source.fingerprint;this.rebuild()}
  remove(id){if(this.value.sourceIds.length===1)throw Error('Keep at least one source PDF.');this.value.sourceIds=this.value.sourceIds.filter(value=>value!==id);this.sources.delete(id);delete this.value.fingerprints[id];this.value.breaks=this.value.breaks.filter(key=>!key.startsWith(id+':'));this.rebuild()}
  move(id,to){const from=this.value.sourceIds.indexOf(id);if(from<0||to<0||to>=this.value.sourceIds.length||from===to)return;this.value.sourceIds.splice(from,1);this.value.sourceIds.splice(to,0,id);this.rebuild()}
  serialise(){return structuredClone(this.value)}
}
export function splitOutputName(prefix,index,range,count){return splitPrefix(prefix)+'-'+String(index+1).padStart(Math.max(2,String(count).length),'0')+'-'+(range.start===range.end?'page-'+range.start:'pages-'+range.start+'-'+range.end)+'.pdf'}
