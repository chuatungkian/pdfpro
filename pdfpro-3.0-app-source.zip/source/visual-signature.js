/* Compose typed and drawn visual signatures without changing the drawing. AGPL-3.0-or-later. */
import {systemFontFamily} from './system-fonts.js';
export async function composeVisualSignature(source,{text='',font='Arial',hasDrawing=false}={}){
  text=String(text).trim();if(!text&&!hasDrawing)throw Error('Type, draw, or import a signature.');
  const output=document.createElement('canvas');output.width=source.width;output.height=source.height+(hasDrawing&&text?160:0);
  const context=output.getContext('2d');if(!context)throw Error('The signature image could not be created.');
  if(hasDrawing)context.drawImage(source,0,0);
  if(text){context.fillStyle='#101d3a';context.font='100px '+systemFontFamily(font);context.fillText(text,25,hasDrawing?source.height+125:185,source.width-50)}
  const blob=await new Promise(resolve=>output.toBlob(resolve,'image/png'));if(!blob)throw Error('The signature image could not be saved.');
  return{bytes:new Uint8Array(await blob.arrayBuffer()),type:'image/png'};
}
