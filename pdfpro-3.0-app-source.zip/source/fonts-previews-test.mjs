/* Font and compact-preview integration regression in a controlled test DOM with real PDF bytes.
 * This is not a browser/layout-engine test and does not open user documents.
 * Requires jsdom and @napi-rs/canvas (test-only dependencies).
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
let JSDOM,canvas;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
const dom=new JSDOM(fs.readFileSync('shell.html','utf8'),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
await import('./app.mjs');
const app=window.PdfPro,$=id=>document.getElementById(id);
const {SYSTEM_FONTS,systemFontFamily,renderSystemText,measureSystemText}=await import('./system-fonts.js');
const {drawSystemText,removeSystemTextBoxes,scaleSystemTextBoxes}=await import('./pdf-font-text.js');
const {createTextAnnotation}=await import('./annotations.js');
let assertions=0;
const check=(value,label)=>{assertions++;assert.ok(value,label)};
const equal=(value,expected,label)=>{assertions++;assert.deepEqual(value,expected,label)};
const pause=(ms=15)=>new Promise(r=>nativeSetTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
function pointer(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button:0});Object.defineProperty(event,'pointerId',{value:1});overlay.dispatchEvent(event)}
function drag(x0,y0,x1,y1){pointer('pointerdown',x0,y0);pointer('pointermove',x1,y1);pointer('pointerup',x1,y1)}
function submit(){ $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true})) }
async function group(name){document.querySelector(`[data-group="${name}"]`).click();await until(()=>app.state.group===name&&app.state.paneOpen,'tool group');await pause()}
function selectFont(name){$('toolFont').value=name;$('toolFont').dispatchEvent(new window.Event('change',{bubbles:true}))}
function allText(bytes){return app.Engine.extractTextPDF(bytes).map(page=>page.text).join('\n')}
try{
 equal(SYSTEM_FONTS.length,30,'30 system fonts supplied');equal(new Set(SYSTEM_FONTS).size,30,'all names unique');
 for(const name of ['Arial','Calibri','Georgia','Times New Roman','Consolas','Verdana'])check(SYSTEM_FONTS.includes(name),'common font '+name);
 equal($('toolFont').options.length,30,'tool settings offer all 30 fonts');
 equal(app.state.font,'Arial','default document font');
 const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<4;i++)doc.addPage([595,842]).drawText('BASE PAGE '+(i+1),{x:45,y:760,size:16});
 await app.setBytes(await doc.save({useObjectStreams:false}),{record:false,dirty:false});
 app.state.fit=false;app.state.zoom=1;await app.render();const initial=app.state.bytes;
 $('togglePages').click();check(app.state.pagesCompact,'compact mode enabled');check(document.body.classList.contains('pages-compact'),'compact layout class');
 equal($('togglePages').getAttribute('aria-expanded'),'false','compact control reports collapsed state');
 equal($('togglePages').getAttribute('aria-label'),'Expand page previews','compact control explains expanding');
 equal(document.querySelectorAll('#thumbs [data-page]').length,4,'compact mode keeps each page tile');
 equal(document.querySelectorAll('.thumbcompactnum').length,4,'small tiles have page numbers');check(app.state.bytes===initial,'compacting does not rewrite PDF');
 document.querySelector('#thumbs [data-page="1"]').click();await until(()=>app.state.page===1,'compact tile navigation');await app.render();equal(app.state.page,1,'small tile selects its page');
 $('togglePages').click();check(!app.state.pagesCompact,'previews expand again');equal($('togglePages').getAttribute('aria-expanded'),'true','expanded control state');
 await group('Edit');selectFont('Georgia');equal(app.state.font,'Georgia','font selector changes font');
 check($('fontSample').style.fontFamily.includes('Georgia'),'sample follows selected family');check(app.state.bytes===initial,'choosing font does not rewrite PDF');
 document.querySelector('[data-tool="text"]').click();await until(()=>app.state.tool==='text','add-text placement');
 const previous=app.state.bytes;drag(50,130,460,195);await until(()=>$('answer'),'add text prompt');$('answer').value='Selected Georgia font: café Ω 日本語';submit();
 await until(()=>app.state.bytes!==previous&&!app.state.abort,'add selected-font text');await app.render();
 check(allText(app.state.bytes).replace(/\s+/g,' ').includes('Selected Georgia font: café Ω 日本語'),'saved added text has Unicode ActualText search/copy content');
 const searchable=app.state.doc.loadPage(1);check(searchable.search('日本語').length>0,'selected-font Unicode can be found by PDF text search');searchable.destroy();
 const selectedId=app.activeTabId;await app.newDocument();equal(app.state.font,'Arial','new tab starts with default font');await app.switchTab(selectedId);equal(app.state.font,'Georgia','tab restores font selection');
 const overflowBytes=app.state.bytes;let failed=false;try{await renderSystemText('A'.repeat(500),{font:'Arial',width:9,height:9,size:144})}catch{failed=true}check(failed,'overflow rejects instead of clipping');check(app.state.bytes===overflowBytes,'font layout failure does not rewrite active document');
 for(const font of SYSTEM_FONTS){
   const appearance=await renderSystemText('Aa Bb Cc 0123',{font,size:18,width:300,height:45});
   check(appearance.png.length>100&&appearance.lines.length===1,'render saved appearance for '+font);
 }
 const a=await renderSystemText('A visible serif sample',{font:'Georgia',size:22,width:340,height:56});
 const b=await renderSystemText('A visible serif sample',{font:'Consolas',size:22,width:340,height:56});
 check(Buffer.compare(Buffer.from(a.png),Buffer.from(b.png))!==0,'different installed font families produce different appearance pixels');
 const loaded=await canvas.loadImage(a.png);equal(loaded.width,a.width*4,'font image uses full 288-DPI width');equal(loaded.height,a.height*4,'font image uses full 288-DPI height');const alpha=canvas.createCanvas(loaded.width,loaded.height);alpha.getContext('2d').drawImage(loaded,0,0);
 const data=alpha.getContext('2d').getImageData(0,0,alpha.width,alpha.height).data;let visible=0,transparent=0;
 for(let i=3;i<data.length;i+=4){if(data[i])visible++;else transparent++}check(visible>100,'font image has visible glyph pixels');check(transparent>visible,'font image background remains transparent');
 // Independent round-trip with selected-font page content and native annotations at rotations.
 const nativeDoc=await app.PDFLib.PDFDocument.create();nativeDoc.addPage([595,842]);nativeDoc.getPage(0).drawRectangle({x:400,y:700,width:60,height:40,color:app.PDFLib.rgb(.063,.114,.227)});
 await drawSystemText(nativeDoc,nativeDoc.getPage(0),a,{x:40,y:730});
 const base=new Uint8Array(await nativeDoc.save({useObjectStreams:false}));
 // Replacing an app-generated box removes its image and search layer together.
 const editable=await app.PDFLib.PDFDocument.load(base,{updateMetadata:false});let partial=false;
 try{removeSystemTextBoxes(editable,editable.getPage(0),[50,765,60,770])}catch{partial=true}
 check(partial,'partial intersection asks for the complete added text box');
 equal(removeSystemTextBoxes(editable,editable.getPage(0),[40,730,380,786]),1,'complete selected-font box is removed as one object');
 const removed=app.Engine.replaceTextPDF(await editable.save({useObjectStreams:false}),[{page:0,rect:[40,56,380,112],text:'',size:4,padding:0}]);
 check(!allText(removed).includes('A visible serif sample'),'replacing generated text removes its search layer');
 const cleared=app.Engine.renderPagePixels(removed);let dark=0;
 for(let y=56;y<112;y++)for(let x=40;x<380;x++){const i=y*cleared.stride+x*cleared.components;if(cleared.pixels[i]<250||cleared.pixels[i+1]<250||cleared.pixels[i+2]<250)dark++}
 equal(dark,0,'replacing generated text removes every visible glyph pixel');
 const graphicIndex=122*cleared.stride+410*cleared.components;check(cleared.pixels[graphicIndex]<30&&cleared.pixels[graphicIndex+2]>40,'unrelated original vector graphic survives replacement');
 const independent=await app.PDFLib.PDFDocument.load(removed,{updateMetadata:false});
 check(!independent.context.enumerateIndirectObjects().some(([,object])=>object.dict?.get(app.PDFLib.PDFName.of('Subtype'))?.toString()==='/Image'),'native cleanup leaves no old font image objects');
 const privateBoxes=(await app.PDFLib.PDFDocument.load(base)).getPage(0).node.lookup(app.PDFLib.PDFName.of('PdfProFontBoxes'),app.PDFLib.PDFArray);
 check(privateBoxes.lookup(0,app.PDFLib.PDFDict).get(app.PDFLib.PDFName.of('Resource')) instanceof app.PDFLib.PDFName,'text metadata stores resource name without retaining old content reference');
 const scaled=await app.PDFLib.PDFDocument.load(base),scaledPage=scaled.getPage(0);scaledPage.scale(.5,.5);scaleSystemTextBoxes(scaled,scaledPage,.5,.5);
 equal(removeSystemTextBoxes(scaled,scaledPage,[20,365,190,393]),1,'resized added text box stays replaceable at scaled coordinates');
 const doubled=await app.PDFLib.PDFDocument.load(base);const [copied]=await doubled.copyPages(doubled,[0]);doubled.addPage(copied);
 removeSystemTextBoxes(doubled,doubled.getPage(0),[40,730,380,786]);
 const isolated=app.Engine.replaceTextPDF(await doubled.save({useObjectStreams:false}),[{page:0,rect:[40,56,380,112],text:'',size:4,padding:0}]);
 const isolatedPages=app.Engine.extractTextPDF(isolated);
 check(!isolatedPages[0].text.includes('A visible serif sample')&&isolatedPages[1].text.includes('A visible serif sample'),'replacing one duplicated page does not alter its counterpart');
 const native=app.Engine.openPDF(base);
 for(const rotation of [0,90,180,270]){
   const page=native.loadPage(0),object=page.getObject();object.put('Rotate',rotation);object.destroy();
   for(const kind of ['freetext','stamp']){
     const appearance=await renderSystemText('Font comment '+rotation,{font:kind==='stamp'?'Consolas':'Georgia',kind,size:18,width:280,height:55});
     const annotation=createTextAnnotation(native,page,{kind,rect:[50,200+rotation/2,330,255+rotation/2],text:'Font comment '+rotation,size:18,color:[.5,0,.125],appearance});
     equal(annotation.getType(),kind==='stamp'?'Stamp':'FreeText','native selected-font annotation subtype '+kind+' '+rotation);
     equal(annotation.getContents(),'Font comment '+rotation,'complete selected-font comment contents '+rotation);
     equal(annotation.getColor(),[],'selected-font annotation has no background fill');annotation.destroy();
   }
   page.destroy();
 }
 const buffer=native.saveToBuffer('garbage=4,compress'),nativeBytes=buffer.asUint8Array().slice();buffer.destroy();native.destroy();
 check(allText(nativeBytes).includes('A visible serif sample'),'image-backed selected font remains searchable after native rewrite');
 fs.writeFileSync('font-appearance-preview.png',app.Engine.renderPagePNG(nativeBytes,0,{scale:1}).bytes);
 const clean=app.Engine.replaceTextPDF(initial,[{page:0,rect:[40,60,400,100],text:'',size:4,padding:0}]);
 check(!allText(clean).includes('BASE PAGE 1'),'empty engine replacement removes source text for selected-font insertion');
 const replacement=await app.PDFLib.PDFDocument.load(clean,{updateMetadata:false});await drawSystemText(replacement,replacement.getPage(0),a,{x:40,y:730});
 check(allText(await replacement.save({useObjectStreams:false})).includes('A visible serif sample'),'selected-font replacement exports searchable appearance');
 // Page decorations use the current chosen font and remain searchable.
 await group('Edit');selectFont('Consolas');const beforeNumber=app.state.bytes,pending=app.activate('number');await until(()=>$('modalform'),'number dialogue');$('modalform').querySelector('[name=prefix]').value='FONT-PAGE ';submit();await pending;
 check(app.state.bytes!==beforeNumber&&allText(app.state.bytes).includes('FONT-PAGE 1'),'page numbers use new font-rendered content');
 equal(app.state.font,'Consolas','selected font survives edits and tool pane refresh');
 // Batch decorations honour the chosen font and preserve the active working PDF.
 const batchBytes=app.state.bytes,batchDownloadCount=downloads.length;
 fileSelections.push([{name:'batch-font.pdf',type:'application/pdf',arrayBuffer:async()=>initial.slice().buffer}]);
 const batch=app.activate('batch');await until(()=>$('modalform'),'batch dialogue');
 $('modalform').querySelector('[name=operation]').value='watermark';$('modalform').querySelector('[name=text]').value='SYSTEM FONT WATERMARK';submit();await batch;
 equal(app.state.bytes,batchBytes,'batch font export leaves active PDF untouched');
 check(downloads.length===batchDownloadCount+1&&downloads.at(-1).name==='pdfpro-batch.zip','batch font export downloads ZIP');
 const {resolveObjectURL}=await import('node:buffer');const zip=new Uint8Array(await resolveObjectURL(downloads.at(-1).href).arrayBuffer()),view=new DataView(zip.buffer);
 equal(view.getUint16(8,true),0,'batch ZIP stores directly inspectable PDF bytes');
 const start=30+view.getUint16(26,true)+view.getUint16(28,true),length=view.getUint32(18,true);
 check(allText(zip.slice(start,start+length)).includes('SYSTEM FONT WATERMARK'),'batch selected-font watermark remains searchable');
 check(systemFontFamily('not a font').startsWith('"Arial"'),'invalid family resolves to safe default');
 console.log(`pdfpro fonts and compact previews: ${assertions} assertions passed in test DOM (not browser layout).`);
}finally{app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout}
