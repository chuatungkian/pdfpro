/* Preserve device-font appearance and searchable text in an offline PDF. */
import {StandardFonts,degrees,PDFName,PDFDict,PDFArray,PDFHexString,PDFOperator,pushGraphicsState,popGraphicsState,beginText,endText,setFontAndSize,setTextRenderingMode,setTextMatrix,showText,TextRenderingMode} from 'pdf-lib';
const fonts=new WeakMap();
const BOXES=PDFName.of('PdfProFontBoxes');
export async function drawSystemText(doc,page,appearance,{x,y,rotation=0,scale=1,opacity=1,track=true}={}){
  // A self-contained Form keeps the visible image and search layer together,
  // so replacing a complete added text box can remove both without touching graphics.
  const formPage=doc.addPage([appearance.width,appearance.height]);
  let form;
  try{
    const image=await doc.embedPng(appearance.png);
    formPage.drawImage(image,{x:0,y:0,width:appearance.width,height:appearance.height});
    let font=fonts.get(doc);if(!font){font=await doc.embedFont(StandardFonts.Helvetica);fonts.set(doc,font)}
    const key=formPage.node.newFontDictionary(font.name,font.ref);
    for(const line of appearance.lines){
      if(!line.text.trim())continue;
      // ActualText retains Unicode even where the invisible base font lacks a glyph.
      const encoded=[...line.text].map(char=>{try{font.encodeText(char);return char}catch{return '?'}}).join('');
      const natural=font.widthOfTextAtSize(encoded,appearance.size),sx=natural?line.width/natural:1;
      formPage.pushOperators(pushGraphicsState(),
        PDFOperator.of('BDC',[PDFName.of('Span'),doc.context.obj({ActualText:PDFHexString.fromText(line.text)})]),
        beginText(),setFontAndSize(key,appearance.size),setTextRenderingMode(TextRenderingMode.Invisible),
        setTextMatrix(sx,0,0,1,line.x,appearance.height-line.y),showText(font.encodeText(encoded)),endText(),PDFOperator.of('EMC'),popGraphicsState());
    }
    form=await doc.embedPage(formPage);
  }finally{doc.removePage(doc.getPageCount()-1)}
  page.drawPage(form,{x,y,xScale:scale,yScale:scale,rotate:degrees(rotation),opacity});
  if(track){
    const angle=rotation*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),b=appearance.inkRect||[0,0,appearance.width,appearance.height];
    const points=[[b[0],b[1]],[b[2],b[1]],[b[0],b[3]],[b[2],b[3]]].map(([u,v])=>{
      const dx=u*scale,dy=(appearance.height-v)*scale;return [x+c*dx-s*dy,y+s*dx+c*dy];
    });
    const rect=[Math.min(...points.map(p=>p[0])),Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[0])),Math.max(...points.map(p=>p[1]))];
    let boxes=page.node.lookupMaybe(BOXES,PDFArray);if(!boxes){boxes=doc.context.obj([]);page.node.set(BOXES,boxes)}
    const objects=page.node.Resources().lookup(PDFName.of('XObject'),PDFDict);
    const resource=objects.entries().find(([,ref])=>ref.toString()===form.ref.toString())?.[0];
    if(!resource)throw Error('Unable to record the new text box.');
    // Store only a resource name, never a reference that could retain an old
    // unredacted Form after a native redaction replaces its page resource.
    const style={text:appearance.text,font:appearance.font,size:appearance.size,color:appearance.color,kind:appearance.kind,width:appearance.width,height:appearance.height,x,y,rotation,scale,opacity};
    boxes.push(doc.context.obj({Rect:rect,Resource:resource,Style:PDFHexString.fromText(JSON.stringify(style))}));
  }
}
export function removeSystemTextBoxes(doc,page,region,{resource}={}){
  const boxes=page.node.lookupMaybe(BOXES,PDFArray);if(!boxes)return 0;
  const selected=[],remaining=[];
  for(const entry of boxes.asArray()){
    const box=doc.context.lookup(entry,PDFDict),rect=box.lookup(PDFName.of('Rect'),PDFArray).asArray().map(n=>doc.context.lookup(n).asNumber());
    if(resource&&box.get(PDFName.of('Resource')).toString()!=='/'+resource){remaining.push(entry);continue}
    const intersects=region[0]<rect[2]&&region[2]>rect[0]&&region[1]<rect[3]&&region[3]>rect[1];
    if(!intersects){remaining.push(entry);continue}
    if(region[0]>rect[0]+1||region[1]>rect[1]+1||region[2]<rect[2]-1||region[3]<rect[3]-1)throw Error('This selection intersects an added text box. Select the complete text box to replace it.');
    selected.push(box.get(PDFName.of('Resource')).toString());
  }
  if(!selected.length)return 0;
  const resources=page.node.Resources().clone(doc.context),objects=resources.lookup(PDFName.of('XObject'),PDFDict).clone(doc.context);
  const available=new Set(objects.entries().map(([name])=>name.toString()));
  if(selected.some(name=>!available.has(name)))throw Error('This added text box was changed by another PDF tool. Restore the source copy before replacing it.');
  const empty=doc.context.register(doc.context.flateStream(new Uint8Array(),{Type:'XObject',Subtype:'Form',BBox:[0,0,1,1],Resources:{}}));
  for(const[key,ref]of objects.entries())if(selected.includes(key.toString()))objects.set(key,empty);
  resources.set(PDFName.of('XObject'),objects);page.node.set(PDFName.of('Resources'),resources);page.node.set(BOXES,doc.context.obj(remaining));
  return selected.length;
}
export function scaleSystemTextBoxes(doc,page,sx,sy){
  const boxes=page.node.lookupMaybe(BOXES,PDFArray);if(!boxes)return;
  const scaled=boxes.asArray().map(entry=>{
    const box=doc.context.lookup(entry,PDFDict).clone(doc.context);
    const rect=box.lookup(PDFName.of('Rect'),PDFArray).asArray().map(n=>doc.context.lookup(n).asNumber());
    box.set(PDFName.of('Rect'),doc.context.obj(rect.map((n,index)=>n*(index%2?sy:sx))));
    const value=box.get(PDFName.of('Style'));
    if(value){if(Math.abs(sx-sy)<.00001){const style=JSON.parse(value.decodeText());style.x*=sx;style.y*=sy;style.scale*=sx;box.set(PDFName.of('Style'),PDFHexString.fromText(JSON.stringify(style)))}else box.delete(PDFName.of('Style'))}
    return box;
  });
  page.node.set(BOXES,doc.context.obj(scaled));
}
