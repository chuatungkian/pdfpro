/* Integration regression in a test DOM with real MuPDF/PDF bytes.
 * This is not a browser/layout-engine test. It does not open user documents.
 * Requires jsdom and @napi-rs/canvas (test-only dependencies).
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
let JSDOM,canvas;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
const dom=new JSDOM(fs.readFileSync('shell.html','utf8'),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){
  let current=backings.get(this);
  if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}
  return current.getContext(kind);
};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{
  constructor(callback){this.callback=callback}
  observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}
  unobserve(){}disconnect(){}
};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');
overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});
Object.defineProperty(overlay,'clientWidth',{get:()=>595});
await import('./app.mjs');
const app=window.PdfPro,$=id=>document.getElementById(id);
let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
async function until(predicate,label){const end=Date.now()+6000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await new Promise(r=>setTimeout(r,5))}}
function press(type,x,y,target=overlay){const event=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button:0});Object.defineProperty(event,'pointerId',{value:1});target.dispatchEvent(event)}
function drag(x0,y0,x1,y1){press('pointerdown',x0,y0);press('pointermove',x1,y1);press('pointerup',x1,y1)}
function clickAt(x,y){press('pointerdown',x,y);press('pointerup',x,y)}
async function group(name){document.querySelector(`[data-group="${name}"]`).click();await until(()=>app.state.group===name&&app.state.paneOpen,'open tool group')}
async function place(tool,rect,text){
  await group('Annotate');document.querySelector(`[data-tool="${tool}"]`).click();
  await until(()=>app.state.tool===tool,'activate '+tool);
  const previous=app.state.bytes;drag(...rect);
  await until(()=>$('annotationText'),'annotation dialogue');$('annotationText').value=text;
  $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
  await until(()=>app.state.bytes!==previous&&!app.state.abort,'save '+tool);
  // Placement now persists; explicitly leave the tool before testing comment viewing.
  await app.activate(tool);
  await app.render();
}
function annotations(){const page=app.state.doc.loadPage(0),all=page.getAnnotations();try{return all.map(a=>({type:a.getType(),contents:a.getContents(),rect:a.getBounds()}))}finally{all.forEach(a=>a.destroy());page.destroy()}}
try{
 check(!$('workspace').classList.contains('pane-open'),'tools start closed');
 check($('nav').closest('.navigation-rail')!==null,'navigation sits in left rail');
 check($('panel').closest('#toolpane')!==null,'tools are in the expandable left pane');
 check($('toolpane').nextElementSibling?.id==='documentStage'&&$('main').parentElement.id==='documentStage','tool pane precedes the document stage');
 check($('workspace').nextElementSibling?.id==='pagesdock','page previews follow workspace at bottom');
 const doc=await app.PDFLib.PDFDocument.create();
 const p=doc.addPage([595,842]);p.drawText('Annotation rendering',{x:55,y:760,size:23,color:app.PDFLib.rgb(.063,.114,.227)});
 p.drawText('Transparent comment and outlined stamp',{x:55,y:730,size:12});doc.addPage([595,842]);
 app.state.fit=false;app.state.zoom=1;await app.setBytes(await doc.save({useObjectStreams:false}),{record:false,dirty:false});
 check(document.querySelectorAll('#thumbs [data-page]').length===2,'bottom page preview buttons created');
 await group('Annotate');check($('workspace').classList.contains('pane-open'),'nav click opens tool pane');
 $('closeTools').click();await until(()=>!app.state.paneOpen,'close pane');check($('toolpane').getAttribute('aria-hidden')==='true','closed tool pane hidden accessibly');
 await place('freetext',[55,150,450,225],'A visible text comment.\nSecond line: café 日本語.');
 let records=annotations();check(records.some(a=>a.type==='FreeText'&&a.contents.includes('Second line: café 日本語.')),'real FreeText full contents saved');
 check(document.querySelectorAll('.annotation-badge').length===1,'saved comment gets keyboard-accessible button');
 clickAt(90,180);await until(()=>$('modaltitle')?.textContent==='Text comment','click comment body');
 check(document.querySelector('.comment-body').textContent==='A visible text comment.\nSecond line: café 日本語.','click opens full multiline contents');$('modalcancel').click();
 const span=document.querySelector('.textline');const range=document.createRange();range.selectNodeContents(span);window.getSelection().removeAllRanges();window.getSelection().addRange(range);check(!window.getSelection().isCollapsed,'test text selection established');
 clickAt(90,180);await new Promise(r=>setTimeout(r,15));check(!$('modaltitle'),'existing text selection does not open comment');window.getSelection().removeAllRanges();
 press('pointerdown',90,180);press('pointerup',140,180);await new Promise(r=>setTimeout(r,15));check(!$('modaltitle'),'drag selection does not open comment');
 document.querySelector('.annotation-badge').click();await until(()=>$('modaltitle'),'comment badge click');check($('modaltitle').textContent==='Text comment','badge opens comment');$('modalcancel').click();
 await place('stamp',[55,290,330,350],'APPROVED 2026');records=annotations();
 check(records.some(a=>a.type==='Stamp'&&a.contents==='APPROVED 2026'),'stamp uses real Stamp subtype with full label');
 clickAt(150,320);await until(()=>$('modaltitle')?.textContent==='Stamp','click stamp body');check(document.querySelector('.comment-body').textContent==='APPROVED 2026','stamp body opens label');$('modalcancel').click();
 const staleBadge=[...document.querySelectorAll('.annotation-badge')].find(e=>e.getAttribute('aria-label').startsWith('View stamp'));
 const beforeUndo=app.state.bytes;$('undo').click();await until(()=>app.state.bytes!==beforeUndo&&!app.state.abort,'undo stamp');
 check(!annotations().some(a=>a.type==='Stamp'),'undo removes stamp');staleBadge.click();await new Promise(r=>setTimeout(r,15));check(!$('modaltitle'),'stale annotation targets cannot open after undo');
 const beforeRedo=app.state.bytes;$('redo').click();await until(()=>app.state.bytes!==beforeRedo&&!app.state.abort,'redo stamp');check(annotations().some(a=>a.type==='Stamp'),'redo restores stamp and interaction targets');
 await app.render();
 fs.writeFileSync('../../outputs/pdfpro-annotation-preview.png',app.Engine.renderPagePNG(app.state.bytes,0,{scale:1.25}).bytes);
 // Existing opaque comments from earlier versions remain readable through the popup.
 const legacy=app.Engine.openPDF(app.state.bytes),legacyPage=legacy.loadPage(0);
 const legacyComment=legacyPage.createAnnotation('FreeText');legacyComment.setRect([350,290,545,360]);legacyComment.setContents('<img src=x onerror=alert(1)> Legacy comment');legacyComment.setColor([.5,0,.125]);legacyComment.setDefaultAppearance('Helv',12,[.5,0,.125]);legacyComment.update();legacyComment.destroy();
 const hidden=legacyPage.createAnnotation('Text');hidden.setRect([350,400,380,430]);hidden.setContents('HIDDEN COMMENT');hidden.setFlags(hidden.getFlags()|2);hidden.update();hidden.destroy();legacyPage.destroy();
 const legacyBuffer=legacy.saveToBuffer('garbage=4,compress');const legacyBytes=legacyBuffer.asUint8Array().slice();legacyBuffer.destroy();legacy.destroy();await app.setBytes(legacyBytes,{record:false});
 const beforeView=app.state.bytes;clickAt(400,320);await until(()=>$('modaltitle'),'legacy comment view');
 check(document.querySelector('.comment-body').textContent==='<img src=x onerror=alert(1)> Legacy comment','legacy invisible comment contents open as literal text');
 check(!document.querySelector('.comment-body img'),'untrusted comment text is escaped');check(app.state.bytes===beforeView,'view is read-only');$('modalcancel').click();
 check(![...document.querySelectorAll('.annotation-badge')].some(e=>e.getAttribute('aria-label').includes('HIDDEN COMMENT')),'hidden annotations have no view target');
 document.querySelector('[data-page="1"]').click();await until(()=>app.state.page===1,'navigate bottom preview');await app.render();clickAt(90,180);await new Promise(r=>setTimeout(r,15));check(!$('modaltitle'),'page navigation clears old comment targets');
 document.querySelector('[data-page="0"]').click();await until(()=>app.state.page===0,'navigate back');await app.render();check(document.querySelectorAll('.annotation-badge').length===3,'returning to page rebuilds comment targets');
 const bytes=app.state.bytes;narrow=true;await group('Annotate');document.querySelector('[data-tool="freetext"]').click();
 check(!app.state.paneOpen&&app.state.tool==='freetext','small-screen placement closes tool drawer without cancelling tool');
 check(app.state.bytes===bytes,'pane interaction does not rewrite PDF');
 console.log(`pdfpro annotation interactions: ${assertions} assertions passed in test DOM (not browser layout).`);
}finally{
 app.state.doc?.destroy();dom.window.close();
}
