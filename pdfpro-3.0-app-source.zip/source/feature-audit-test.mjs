/* Broad tool workflows with synthetic PDFs and real embedded engines. No browser or user files are opened. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
import {gunzipSync} from 'node:zlib';
import {installTestWorkers} from './test-worker-runtime.mjs';
import {readTestZip} from './source-zip-test-utils.mjs';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLCanvasElement.prototype.toDataURL=function(type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));return 'data:'+type+';base64,'+backing.toBuffer(type).toString('base64')};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+30000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
const runtime=installTestWorkers(),errors=[],consoleError=console.error;
console.error=(...args)=>{errors.push(args.map(String).join(' '));consoleError(...args)};
try{
 context=await boot();const {app,$,window}=context;await until(()=>$('recentDocuments').getAttribute('aria-busy')==='false','Home ready');
 const html=fs.readFileSync('../../outputs/pdfpro.html','utf8'),assets=JSON.parse(gunzipSync(Buffer.from(html.match(/id="pdfpro-payload"[^>]*>([^<]+)/)[1],'base64')));window.PDFPRO_ASSETS=assets;app.OCR.configureOCR(assets.ocr);
 const base=await fixture(app,'FEATURE AUDIT'),two=await fixture(app,'MERGE SOURCE');await app.openFiles([file('Feature audit.pdf',base)]);app.state.fit=false;app.state.zoom=1;await app.render();
 const submit=()=> $('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
 function fields(values){for(const [key,value]of Object.entries(values)){const node=$(key)||$('modalform').querySelector('[name="'+key+'"]');assert.ok(node,'Missing field '+key);if(node.type==='checkbox')node.checked=!!value;else node.value=String(value)}}
 async function action(tool,values={},setup){const pending=app.activate(tool);await until(()=>$('modalform'),'dialogue '+tool);if(setup)setup();fields(values);submit();await pending;await pause()}
 async function closeAction(tool){const pending=app.activate(tool);await until(()=>$('modalform'),'dialogue '+tool);$('modalcancel').click();await pending;await pause()}
 function pointer(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0});Object.defineProperties(event,{pointerId:{value:2},isPrimary:{value:true}});$('overlay').dispatchEvent(event)}
 async function place(tool,rect,dialogs=[]){if(app.state.tool!==tool)await app.activate(tool);const previous=app.state.bytes,marks=app.state.marks.length;pointer('pointerdown',rect[0],rect[1]);pointer('pointermove',rect[2],rect[3]);pointer('pointerup',rect[2],rect[3]);for(const values of dialogs){await until(()=>$('modalform'),'placement '+tool);fields(values);submit();await pause()}await until(()=>(tool==='redact'?app.state.marks.length!==marks:app.state.bytes!==previous)&&!app.state.abort,'saved '+tool);await app.local.flush();await pause()}
 const blob=()=>runtime.blob(context.downloads.at(-1).href),pdfDownload=async()=>new Uint8Array(await blob().arrayBuffer());
 // View: real search, metadata, bookmarks and attachment round trips.
 await app.activate('search');$('searchquery').value='FEATURE';$('searchquery').dispatchEvent(new window.Event('input'));await $('dosearch').onclick();await until(()=>app.state.hits.length===2&&!app.state.abort,'search results');equal(app.state.hits.length,2,'Find text locates both pages');
 await action('metadata',{title:'Audited title',author:'Test author',subject:'Offline checks',keywords:'qa,pdf'});equal(app.Engine.inspectPDF(app.state.bytes).metadata.Title,'Audited title','properties persist');
 await action('bookmarks',{title:'Start here'});equal(app.state.doc.loadOutline()[0].title,'Start here','bookmark stored');
 const attachBytes=new TextEncoder().encode('Attachment round trip');await action('attachments',{},()=>Object.defineProperty($('newattachment'),'files',{configurable:true,value:[{name:'evidence.txt',type:'text/plain',arrayBuffer:async()=>attachBytes.slice().buffer}]}));check(app.Engine.inspectPDF(app.state.bytes).attachments.includes('evidence.txt'),'attachment embedded');const attachmentDialog=app.activate('attachments');await until(()=>$('att0'),'attachment download');await $('att0').onclick();equal(await blob().text(),'Attachment round trip','attachment download exact');$('modalcancel').click();await attachmentDialog;
 // Organise: all destructive changes use copies/undo; native page order is checked.
 await app.activate('rotate');equal((await app.PDFLib.PDFDocument.load(app.state.bytes)).getPage(0).getRotation().angle,90,'rotate action');await $('undo').onclick();
 await app.activate('duplicate');equal(app.state.doc.countPages(),3,'duplicate action');await app.activate('moveup');equal(app.state.page,0,'move earlier');await app.activate('movedown');equal(app.state.page,1,'move later');await action('delete');equal(app.state.doc.countPages(),2,'delete action');await app.activate('blank');equal(app.state.doc.countPages(),3,'insert blank action');
 context.fileSelections.push([file('Source.pdf',two)]);await app.activate('merge');equal(app.state.doc.countPages(),5,'quick merge appends source pages');
 await action('extract',{answer:'2-3'});equal(app.Engine.inspectPDF(await pdfDownload()).pageCount,2,'extract exports requested pages');await action('reorder',{answer:'5,4,3,2,1'});check(app.Engine.extractTextPDF(app.state.bytes)[0].text.includes('MERGE SOURCE 2'),'reorder uses requested order');
 await action('resize',{width:420,height:595});equal(app.Engine.inspectPDF(app.state.bytes).pages[0].width,420,'resize action');await place('crop',[20,30,320,420]);equal(Math.round(app.Engine.inspectPDF(app.state.bytes).pages[0].width),300,'crop action');
 // Fresh simple document avoids deliberate form/copy restrictions in page operations.
 await app.openFiles([file('Edit and annotate.pdf',base)]);app.state.fit=false;app.state.zoom=1;await app.render();
 await place('text',[50,150,400,190],[{answer:'Added audit text'}]);check(text(app).includes('Added audit text'),'add text action');
 await place('replace',[35,65,300,105],[{answer:'Replacement audit text'}]);check(app.Engine.extractTextPDF(app.state.bytes)[0].text.includes('Replacement audit text'),'replace action writes searchable replacement');check(!app.Engine.extractTextPDF(app.state.bytes)[0].text.includes('FEATURE AUDIT 1'),'replace removes selected original text');
 const c=canvas.createCanvas(80,40);c.getContext('2d').fillRect(0,0,80,40);const png=new Uint8Array(c.toBuffer('image/png'));context.fileSelections.push([{name:'image.png',type:'image/png',arrayBuffer:async()=>png.slice().buffer}]);await app.activate('image');await place('image',[50,220,210,300]);check(app.state.bytes.length>base.length,'image placement');
 await action('watermark',{text:'AUDIT WATERMARK',opacity:.2,pages:'1-2'});check(text(app).includes('AUDIT WATERMARK'),'watermark action');await action('number',{prefix:'PageAudit-',start:4,pages:'1-2'});check(text(app).includes('PageAudit-4'),'page number action');await action('bates',{prefix:'QA-',start:8,digits:4,pages:'1-2'});check(text(app).includes('QA-0008'),'Bates number action');await action('header',{header:'Audit header',footer:'Audit footer',pages:'1-2'});check(text(app).includes('Audit header')&&text(app).includes('Audit footer'),'header/footer action');
 const kinds={highlight:'Highlight',underline:'Underline',strikeout:'StrikeOut',rectangle:'Square',ellipse:'Circle',line:'Line',arrow:'Line'};
 for(const [tool,type]of Object.entries(kinds)){await place(tool,[55,350,240,380]);const page=app.state.doc.loadPage(0),annotations=page.getAnnotations();check(annotations.some(a=>a.getType()===type),tool+' creates native annotation');annotations.forEach(a=>a.destroy());page.destroy()}
 await place('note',[300,350,325,375],[{annotationText:'Audit sticky note'}]);await place('freetext',[50,450,400,510],[{annotationText:'Audit text comment'}]);await place('stamp',[50,540,300,590],[{annotationText:'AUDITED'}]);
 const comments=app.activate('comments');await until(()=>$('modalform'),'comments list');check($('modalform').textContent.includes('Audit sticky note')&&$('modalform').textContent.includes('Audit text comment'),'comments list includes all contents');$('modalform').querySelector('[name=remove]').checked=true;submit();await comments;check(true,'comments remove selected annotation');
 // Form creation, filling, JSON round trip and flattening.
 await app.newDocument();app.state.fit=false;app.state.zoom=1;await app.render();
 await place('fieldText',[50,100,300,130],[{answer:'Name'}]);await place('fieldCheck',[50,170,70,190],[{answer:'Reviewed'}]);await place('fieldRadio',[50,240,300,265],[{answer:'Decision'},{answer:'Yes,No'}]);await place('fieldDropdown',[50,320,300,350],[{answer:'Category'},{answer:'Alpha,Beta'}]);
 let form=await app.PDFLib.PDFDocument.load(app.state.bytes);equal(form.getForm().getFields().length,4,'all field types created');await action('fill',{fld0:'Audit person',fld1:true,fld2:'Yes',fld3:'Beta'});form=await app.PDFLib.PDFDocument.load(app.state.bytes);equal(form.getForm().getTextField('Name').getText(),'Audit person','text field filled');check(form.getForm().getCheckBox('Reviewed').isChecked(),'checkbox filled');equal(form.getForm().getRadioGroup('Decision').getSelected(),'Yes','radio selected');equal(form.getForm().getDropdown('Category').getSelected(),['Beta'],'dropdown selected');
 await app.activate('formexport');const values=JSON.parse(await blob().text());equal(values.Name,'Audit person','form JSON export');context.fileSelections.push([{name:'values.json',type:'application/json',text:async()=>JSON.stringify({...values,Name:'Imported name'})}]);await app.activate('formimport');form=await app.PDFLib.PDFDocument.load(app.state.bytes);equal(form.getForm().getTextField('Name').getText(),'Imported name','form JSON import');await action('flatten');equal(app.Engine.inspectPDF(app.state.bytes).forms,0,'flatten removes live widgets');check(text(app).includes('Imported name'),'flatten keeps visible field appearance');
 // OCR uses the actual bundled worker/core/model in the controlled worker adapter.
 const scan=canvas.createCanvas(1400,300),sc=scan.getContext('2d');sc.fillStyle='white';sc.fillRect(0,0,1400,300);sc.fillStyle='black';sc.font='85px Arial';sc.fillText('PDFPRO AUDIT TEXT 987',45,165);const scanDoc=await app.PDFLib.PDFDocument.create(),scanImage=await scanDoc.embedPng(scan.toBuffer('image/png'));scanDoc.addPage([504,108]).drawImage(scanImage,{x:0,y:0,width:504,height:108});await app.openFiles([file('Scan.pdf',await scanDoc.save())]);
 const ocrTask=app.activate('ocr');await until(()=>$('modalform'),'OCR settings');fields({pages:'1',dpi:200,skip:true});submit();await until(()=>!app.state.abort&&text(app).includes('AUDIT TEXT 987'),'OCR search layer').catch(error=>{consoleError('OCR diagnostic',text(app),document.getElementById('toast').textContent,document.getElementById('busytitle').textContent,document.getElementById('busydetail').textContent);throw error});if($('modalform'))$('modalcancel').click();await ocrTask;check(text(app).includes('AUDIT TEXT 987'),'OCR UI creates searchable text');
 const beforeOptimize=text(app);await app.activate('optimize');check(text(app).includes('AUDIT TEXT 987')&&beforeOptimize.includes('AUDIT TEXT 987'),'optimise preserves searchable content');await app.activate('textExport');check((await blob().text()).includes('AUDIT TEXT 987'),'text export worker action');
 const comparisonDoc=await fixture(app,'DIFFERENT DOCUMENT');context.fileSelections.push([file('Comparison.pdf',comparisonDoc)]);const compare=app.activate('compare');await until(()=>$('comparepage'),'comparison results');await until(()=>$('compareheatmap').querySelector('canvas'),'heatmap ready');check($('modalform').textContent.includes('Text changed'),'comparison detects text changes');check($('modalform').textContent.includes('Only in comparison file'),'comparison detects extra page');$('modalcancel').click();await compare;
 // Protection: export encryption, pending redactions, secure rebuild and sanitation.
 await app.openFiles([file('Protect.pdf',base)]);const unencrypted=app.state.bytes;await action('encrypt',{encpw:'audit-password',encpw2:'audit-password',ownerPassword:'audit-owner'});const protectedBytes=await pdfDownload();assertions++;assert.throws(()=>app.Engine.openPDF(protectedBytes),/password/);const protectedDoc=app.Engine.openPDF(protectedBytes,'audit-password');equal(protectedDoc.countPages(),2,'encrypted export opens with password');protectedDoc.destroy();equal(app.state.bytes,unencrypted,'encryption leaves working PDF unlocked');
 await place('redact',[30,60,300,100]);equal(app.state.marks.length,1,'redaction marks created');await app.activate('clearmarks');equal(app.state.marks.length,0,'clear redactions');await place('redact',[30,60,300,100]);await action('applyredact',{method:'raster',dpi:150});check(app.Engine.extractTextPDF(app.state.bytes).every(p=>!p.text.trim()),'apply redaction secure rebuild removes source text');equal(app.state.marks.length,0,'applied redactions clear marks');
 await app.openFiles([file('Sanitise.pdf',base)]);await action('sanitize');check(app.Engine.extractTextPDF(app.state.bytes).every(p=>!p.text.trim()),'sanitise action creates image-only copy');
 // Certificate sign and verify through the actual UI with a synthetic test-only P12.
 await app.openFiles([file('Sign.pdf',base)]);const forge=window.forge,keys=forge.pki.rsa.generateKeyPair({bits:2048,e:0x10001}),cert=forge.pki.createCertificate();cert.publicKey=keys.publicKey;cert.serialNumber='27';cert.validity.notBefore=new Date(Date.now()-86400000);cert.validity.notAfter=new Date(Date.now()+86400000);cert.setSubject([{name:'commonName',value:'Synthetic audit signer'}]);cert.setIssuer(cert.subject.attributes);cert.sign(keys.privateKey,forge.md.sha256.create());const p12=Uint8Array.from(forge.asn1.toDer(forge.pkcs12.toPkcs12Asn1(keys.privateKey,[cert],'test-audit-only',{algorithm:'3des'})).getBytes(),c=>c.charCodeAt(0));
 const signing=app.activate('certsign');await until(()=>$('p12file'),'signing inputs');Object.defineProperty($('p12file'),'files',{configurable:true,value:[{name:'audit.p12',arrayBuffer:async()=>p12.slice().buffer}]});fields({p12pw:'test-audit-only',signreason:'Synthetic audit'});submit();await until(()=>$('modaltitle')?.textContent==='Offline signature inspection','signed inspection');check($('modalform').textContent.includes('valid'),'certificate UI reports valid byte integrity');$('modalcancel').click();await signing;const verification=await window.PdfProSigning.verifyPdf(app.state.bytes);equal(verification.signatures[0].integrity,'valid','signed UI output independently verifies');await closeAction('verify');
 // Exports, portable workspace, batching and the controlled print popup.
 await app.openFiles([file('Exports.pdf',base)]);await app.activate('save');equal(await pdfDownload(),app.state.bytes,'Save PDF exports active bytes');for(const type of ['png','jpeg']){await app.activate(type);const bytes=await pdfDownload();check(type==='png'?bytes[0]===137:bytes[0]===255&&bytes[1]===216,'page '+type+' export')}
 await app.activate('allimages');const imageZip=readTestZip(await blob().arrayBuffer());equal(imageZip.size,2,'all-page PNG ZIP valid');check([...imageZip.values()].every(entry=>entry.bytes[0]===137),'all image ZIP entries PNGs');await app.activate('project');const workspace=await blob().text();equal(JSON.parse(workspace).format,'pdfpro-workspace','portable workspace export');context.fileSelections.push([{name:'saved.pdfpro',text:async()=>workspace}]);const count=app.tabs.length;await app.activate('restore');equal(app.tabs.length,count+1,'portable workspace opens independent tab');check(text(app).includes('FEATURE AUDIT'),'portable workspace preserves PDF content');
 for(const operation of ['optimize','watermark','number','bates','rotate','text']){context.fileSelections.push([file('Résumé.pdf',base),file('Second.pdf',two)]);await action('batch',{operation,text:'BATCH-',start:2});const archive=readTestZip(await blob().arrayBuffer());equal(archive.size,2,'batch '+operation+' exports both inputs');check([...archive.keys()][0].includes('Résumé'),'batch preserves UTF-8 filenames');if(operation==='rotate')equal((await app.PDFLib.PDFDocument.load(archive.values().next().value.bytes)).getPage(0).getRotation().angle,90,'batch rotation saved');if(operation==='text')check(archive.values().next().value.bytes.toString().includes('FEATURE AUDIT'),'batch text output')}
 let printed=false,printDom;window.open=()=>{printDom=new JSDOM('<!doctype html><html><body></body></html>',{url:'https://pdfpro-print.test/'});printDom.window.HTMLImageElement.prototype.decode=async()=>{};printDom.window.focus=()=>{};printDom.window.print=()=>printed=true;return printDom.window};await app.activate('print');check(printed&&printDom.window.document.querySelectorAll('img').length===2,'print builds all page images and requests print');printDom.window.close();
 equal(runtime.networkAttempts,0,'all embedded-worker paths remain offline');equal(errors,[],'feature workflows have no unexpected runtime errors');app.OCR.cancelOCR();await context.close();context=null;console.log('pdfpro feature audit: '+assertions+' assertions passed across UI/native workflows; browser transport/layout remain unverified.');
}finally{console.error=consoleError;if(context)await context.close();runtime.close()}
