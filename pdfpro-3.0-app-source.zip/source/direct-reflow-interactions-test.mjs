/* Direct edit and insertion viewport regression. Native PDFs, controlled DOM and simulated browser scroll clamping. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {directTextTargets,addedTextTargets,directEditTargets} from './direct-text.js';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}const ctx=current.getContext(kind);if(!ctx._pdfproDrawPatched){const draw=ctx.drawImage.bind(ctx);ctx.drawImage=(source,...args)=>draw(backings.get(source)||source,...args);ctx._pdfproDrawPatched=true}return ctx};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
try{
 context=await boot();let {app,$,window}=context;const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<5;i++){const p=doc.addPage([595,842]);p.drawText('A paragraph contains several lines of text.\nChanges should pull the following words up.\nIts final sentence ends here.',{x:50,y:740,size:14,lineHeight:18,color:app.PDFLib.rgb(.5,0,.125)});p.drawText('The next paragraph stays separate.\nIt also has another line.',{x:50,y:600,size:14,lineHeight:18})}
 await app.openFiles([file('Paragraphs.pdf',await doc.save())]);app.state.fit=false;app.state.zoom=1;await app.render();$('pageinput').value='5';await $('pageinput').onchange({target:$('pageinput')});const pages=app.continuousPages,main=$('main'),viewer=$('viewer');Object.defineProperty(main,'clientHeight',{get:()=>600});
 const replace=viewer.replaceChildren.bind(viewer);viewer.replaceChildren=(...nodes)=>{replace(...nodes);main.scrollTop=main.scrollLeft=0;main.dispatchEvent(new window.Event('scroll'))};main.scrollTop=pages.pageTop(4)+31;main.scrollLeft=9;const top=main.scrollTop;
 equal(app.state.directMode,'paragraph','Paragraph is the default editing scope');app.state.group='Edit';await app.activate('directedit');equal($('directEditScope').value,'paragraph','tool options expose the default');
 function targets(){return pages.records[4].overlay.querySelectorAll('.direct-text-target')}
 async function open(phrase){const button=[...targets()].find(b=>b.getAttribute('aria-label').includes(phrase));check(!!button,'selected text has an editable target');await button.onclick(new window.MouseEvent('click',{bubbles:true}));return document.querySelector('.direct-editor')}
 let form=await open('A paragraph');let input=form.querySelector('textarea');check(!!input,'paragraph opens a multiline editor');check(input.value.includes('text. Changes should'),'paragraph soft line breaks become continuous text');equal(form.querySelector('.direct-editor-scope').value,'paragraph','inline scope selector is present');check(!!form.querySelector('.direct-editor-width'),'paragraph width can be adjusted');
 const originalWidth=+form.querySelector('.direct-editor-width').value,old=app.state.bytes;input.value='A compact paragraph closes the gaps.';const key=new window.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true});input.dispatchEvent(key);check(!key.defaultPrevented,'Enter is available for paragraph line breaks');equal(app.state.bytes,old,'plain Enter does not apply a paragraph');await form.onsubmit({preventDefault(){}});await pause(80);
 check(!form.isConnected,'paragraph Apply closes the editor');equal(app.state.page,4,'paragraph edit retains page 5');equal(main.scrollTop,top,'paragraph edit retains vertical scroll');equal(main.scrollLeft,9,'paragraph edit retains horizontal scroll');check(text(app).includes('A compact paragraph closes the gaps.'),'saved PDF contains replacement');check(!app.Engine.extractTextPDF(app.state.bytes)[4].text.includes('Its final sentence ends here.'),'old paragraph is removed completely');const paragraph=directEditTargets(app.state.doc,4).find(p=>p.text.startsWith('A compact'));check(paragraph.parts.length<3,'shortened paragraph uses fewer lines');equal(Math.round(paragraph.layout.width*10)/10,originalWidth,'wrapping width survives shortening');
 await $('undo').onclick();check(app.Engine.extractTextPDF(app.state.bytes)[4].text.includes('Its final sentence ends here.'),'undo restores all old lines');await $('redo').onclick();check(text(app).includes('A compact paragraph'),'redo restores the whole edited paragraph');
 form=await open('A compact');form.querySelector('textarea').value='Unapplied draft';const selector=form.querySelector('.direct-editor-scope');selector.value='line';selector.onchange();equal(selector.value,'paragraph','scope change does not discard a typed draft');check(form.querySelector('[role="alert"]').textContent.includes('Apply or cancel'),'draft protection explains how to change scope');form.querySelector('[type="button"]').click();
 form=await open('A compact');form.querySelector('.direct-editor-scope').value='line';form.querySelector('.direct-editor-scope').onchange();form=document.querySelector('.direct-editor');equal(app.state.directMode,'line','inline selector switches to Line');check(form.querySelector('input.direct-editor-input'),'Line uses a single-line input');check(!form.querySelector('.direct-editor-width'),'Line does not reflow the paragraph');form.querySelector('[type="button"]').click();
 $('directEditScope').value='paragraph';$('directEditScope').onchange({target:$('directEditScope')});form=await open('A compact');form.querySelector('textarea').value='Unavailable 😀';const retained=app.state.bytes;await form.onsubmit({preventDefault(){}});check(form.isConnected,'font errors keep the paragraph editor open');equal(app.state.bytes,retained,'font error preserves the original PDF');check(form.querySelector('[role="alert"]').textContent.includes('does not contain'),'source-font error is shown');form.querySelector('[type="button"]').click();
 // Scope changes to Text chunk enter drag selection without applying the text.
 form=await open('A compact');form.querySelector('.direct-editor-scope').value='chunk';form.querySelector('.direct-editor-scope').onchange();check(!document.querySelector('.direct-editor'),'Text chunk waits for an area selection');equal(app.state.directMode,'chunk','Text chunk selection persists');
 function pointer(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0});Object.defineProperties(event,{pointerId:{value:1},isPrimary:{value:true}});$('overlay').dispatchEvent(event)}
 pointer('pointerdown',35,75);pointer('pointermove',400,280);pointer('pointerup',400,280);await until(()=>document.querySelector('.direct-editor'),'selected chunk opens');form=document.querySelector('.direct-editor');equal(form.querySelector('.direct-editor-scope').value,'chunk','chunk editor identifies its scope');check(form.querySelector('textarea').value.includes('The next paragraph'),'chunk includes the other selected paragraph');
 form.querySelector('textarea').value='First compact paragraph.\n\nSecond compact paragraph.';form.querySelector('.direct-editor-width').value='270';await form.onsubmit({preventDefault(){}});await pause(80);const runs=directTextTargets(app.state.doc,4),first=runs.find(r=>r.text.startsWith('First compact')),second=runs.find(r=>r.text.startsWith('Second compact'));equal(second.matrix[5]-first.matrix[5],36,'chunk reflow closes the original large paragraph gap');equal(main.scrollTop,top,'chunk edit retains the viewport');equal(app.state.tool,'directedit','Direct edit stays selected');equal(app.state.directMode,'chunk','chunk scope stays selected after Apply');
 await app.local.flush();const owner=app.activeTabId;await context.close();context=await boot();({app,$,window}=context);equal(app.activeTabId,owner,'edited document recovers');equal(app.state.directMode,'chunk','editing scope recovers locally');equal(app.state.page,4,'paragraph edits retain the recovered page');check(text(app).includes('Second compact paragraph.'),'chunk edits recover from IndexedDB');
 await context.close();context=null;console.log('pdfpro paragraph/chunk UI: '+assertions+' assertions passed with controlled drag/inline actions, native reflow, view retention and IndexedDB recovery.');
}finally{if(context)await context.close()}
