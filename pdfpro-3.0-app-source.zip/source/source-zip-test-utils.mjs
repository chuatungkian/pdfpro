// Independent native ZIP reader for source export/release verification. Test only.
import assert from 'node:assert/strict';
import {inflateRawSync} from 'node:zlib';
const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0});
const crcOf=bytes=>{let n=0xffffffff;for(const b of bytes)n=crcTable[(n^b)&255]^(n>>>8);return(n^0xffffffff)>>>0};
export function readTestZip(value){
 const zip=Buffer.from(value),end=zip.length-22;assert.equal(zip.readUInt32LE(end),0x06054b50);
 const count=zip.readUInt16LE(end+10),size=zip.readUInt32LE(end+12);let cursor=zip.readUInt32LE(end+16);
 assert.equal(cursor+size,end);assert.equal(zip.readUInt16LE(end+8),count);
 const entries=new Map();
 for(let index=0;index<count;index++){
  assert.equal(zip.readUInt32LE(cursor),0x02014b50);
  const flags=zip.readUInt16LE(cursor+8),method=zip.readUInt16LE(cursor+10),crc=zip.readUInt32LE(cursor+16),compressed=zip.readUInt32LE(cursor+20),size=zip.readUInt32LE(cursor+24),nameLength=zip.readUInt16LE(cursor+28),extra=zip.readUInt16LE(cursor+30),comment=zip.readUInt16LE(cursor+32),offset=zip.readUInt32LE(cursor+42);
  const name=zip.subarray(cursor+46,cursor+46+nameLength).toString('utf8');assert(!entries.has(name));
  assert.equal(flags,0x800);assert.equal(zip.readUInt32LE(offset),0x04034b50);assert.equal(zip.readUInt16LE(offset+6),flags);assert.equal(zip.readUInt16LE(offset+8),method);
  assert.equal(zip.readUInt32LE(offset+14),crc);assert.equal(zip.readUInt32LE(offset+18),compressed);assert.equal(zip.readUInt32LE(offset+22),size);
  const localLength=zip.readUInt16LE(offset+26),localExtra=zip.readUInt16LE(offset+28);assert.equal(zip.subarray(offset+30,offset+30+localLength).toString('utf8'),name);
  const start=offset+30+localLength+localExtra,data=zip.subarray(start,start+compressed);assert([0,8].includes(method));
  const bytes=method===8?inflateRawSync(data):data;assert.equal(bytes.length,size);assert.equal(crcOf(bytes),crc);
  entries.set(name,{bytes,method});cursor+=46+nameLength+extra+comment;
 }
 assert.equal(cursor,end);return entries;
}
