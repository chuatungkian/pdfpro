/* pdfpro 3.0 PDF engine. Copyright 2026. AGPL-3.0-or-later.
 * MuPDF is Copyright (C) 2004-2026 Artifex Software, Inc.
 * Region coordinates are MuPDF page coordinates: top-left origin, y down,
 * 72 units per inch. Page numbers are zero-based. No PDF JavaScript executes.
 */
import * as mupdf from 'mupdf';
export { mupdf };

const FULL_SAVE = 'garbage=4,compress=yes,compress-fonts=yes,compress-images=yes';
const INFO_KEYS = ['Title', 'Author', 'Subject', 'Keywords', 'Creator', 'Producer', 'CreationDate', 'ModDate'];

function bytesOf(value) {
  if (value instanceof Uint8Array) return new Uint8Array(value);
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (value?.asUint8Array) return new Uint8Array(value.asUint8Array());
  throw new TypeError('Expected PDF bytes as Uint8Array or ArrayBuffer.');
}
function save(doc, options = FULL_SAVE) {
  const buffer = doc.saveToBuffer(options);
  try { return bytesOf(buffer); } finally { buffer.destroy(); }
}
function close(value) { if (value?.destroy) value.destroy(); }
function validPage(doc, index) {
  if (!Number.isInteger(index) || index < 0 || index >= doc.countPages()) throw new RangeError('Page number is outside this document.');
  return doc.loadPage(index);
}
function normalizedRect(rect, bounds) {
  if (!Array.isArray(rect) || rect.length !== 4 || !rect.every(Number.isFinite)) throw new TypeError('A region needs four finite coordinates.');
  const result = [Math.max(bounds[0], Math.min(rect[0], rect[2])), Math.max(bounds[1], Math.min(rect[1], rect[3])), Math.min(bounds[2], Math.max(rect[0], rect[2])), Math.min(bounds[3], Math.max(rect[1], rect[3]))];
  if (result[2] <= result[0] || result[3] <= result[1]) throw new RangeError('The selected region does not intersect the page.');
  return result;
}
function ensureRegions(doc, regions) {
  if (!Array.isArray(regions) || !regions.length) throw new Error('Select at least one region.');
  return regions.map(region => {
    const page = validPage(doc, region.page);
    try { return { ...region, rect: normalizedRect(region.rect, page.getBounds()) }; } finally { page.destroy(); }
  });
}
function ensureScale(scale) {
  if (!Number.isFinite(scale) || scale <= 0 || scale > 8) throw new RangeError('Render scale must be greater than 0 and at most 8.');
  return scale;
}
function renderPixmap(page, scale = 1, showExtras = true) {
  ensureScale(scale);
  const bounds = page.getBounds();
  const w = Math.ceil((bounds[2] - bounds[0]) * scale), h = Math.ceil((bounds[3] - bounds[1]) * scale);
  if (w * h > 50000000) throw new Error('Page render exceeds 50 million pixels. Reduce the resolution.');
  const matrix = [scale, 0, 0, scale, -bounds[0] * scale, -bounds[1] * scale];
  return page.toPixmap(matrix, mupdf.ColorSpace.DeviceRGB, false, showExtras);
}

export function openPDF(bytes, password = '') {
  const doc = mupdf.Document.openDocument(bytesOf(bytes), 'application/pdf').asPDF();
  if (!doc) throw new Error('This file is not a PDF.');
  doc.disableJS();
  if (doc.needsPassword() && !doc.authenticatePassword(String(password))) {
    doc.destroy();
    const error = new Error(password ? 'The PDF password is incorrect.' : 'This PDF requires a password.');
    error.code = 'PASSWORD_REQUIRED';
    throw error;
  }
  return doc;
}

export function inspectPDF(bytes, password = '') {
  const doc = openPDF(bytes, password);
  try {
    const metadata = Object.fromEntries(INFO_KEYS.map(key => [key, doc.getMetaData(`info:${key}`) || '']));
    const pages = [];
    let forms = 0, signatures = 0, annotations = 0;
    for (let i = 0; i < doc.countPages(); i++) {
      const page = doc.loadPage(i);
      try {
        const bounds = page.getBounds();
        const widgets = page.getWidgets();
        forms += widgets.length;
        for (const widget of widgets) {
          if (widget.getFieldType?.() === 'signature' || widget.getObject().getInheritable('FT').asName() === 'Sig') signatures++;
        }
        annotations += page.getAnnotations().length;
        pages.push({ index: i, bounds, width: bounds[2] - bounds[0], height: bounds[3] - bounds[1], label: page.getLabel() });
      } finally { page.destroy(); }
    }
    const root = doc.getTrailer().get('Root');
    const permissions = Object.fromEntries(['print', 'copy', 'edit', 'annotate', 'form', 'accessibility', 'assemble', 'print-hq'].map(key => [key, doc.hasPermission(key)]));
    return { pageCount: pages.length, pages, metadata, encryption: doc.getMetaData('encryption') || '', permissions, forms, signatures, annotations, attachments: Object.keys(doc.getEmbeddedFiles()), outline: doc.loadOutline() || [], tagged: !root.get('StructTreeRoot').isNull(), hasXFA: !root.get('AcroForm', 'XFA').isNull(), version: doc.getVersion(), repaired: doc.wasRepaired(), versions: doc.countVersions() };
  } finally { doc.destroy(); }
}

export function readPagePDF(bytes, pageIndex = 0, { password = '' } = {}) {
  const doc = openPDF(bytes, password);
  let page, structured;
  try {
    page = validPage(doc, pageIndex);
    const bounds = page.getBounds();
    structured = page.toStructuredText('preserve-spans');
    const data = JSON.parse(structured.asJSON());
    const lines = (data.blocks || []).filter(block => block.type === 'text').flatMap(block => block.lines || []).map(line => ({ ...line, rect: [line.bbox.x, line.bbox.y, line.bbox.x + line.bbox.w, line.bbox.y + line.bbox.h] }));
    const annotations = page.getAnnotations().map((annotation, index) => ({ index, type: annotation.getType(), rect: annotation.getBounds(), contents: annotation.getContents(), author: annotation.getAuthor() }));
    return { page: pageIndex, bounds, width: bounds[2] - bounds[0], height: bounds[3] - bounds[1], text: structured.asText(), lines, blocks: data.blocks || [], annotations };
  } finally { close(structured); close(page); doc.destroy(); }
}

export function extractTextPDF(bytes, { password = '', pages } = {}) {
  const doc = openPDF(bytes, password);
  try {
    const indices = pages || Array.from({ length: doc.countPages() }, (_, i) => i);
    return indices.map(index => {
      const page = validPage(doc, index);
      let text;
      try { text = page.toStructuredText('preserve-spans'); return { page: index, text: text.asText() }; }
      finally { close(text); page.destroy(); }
    });
  } finally { doc.destroy(); }
}

export function searchPDF(bytes, needle, { password = '', maxHits = 1000 } = {}) {
  if (!needle) return [];
  const doc = openPDF(bytes, password);
  try {
    const hits = [];
    for (let i = 0; i < doc.countPages() && hits.length < maxHits; i++) {
      const page = doc.loadPage(i);
      try {
        for (const quads of page.search(String(needle), {})) {
          hits.push({ page: i, quads, rects: quads.map(q => [Math.min(q[0], q[2], q[4], q[6]), Math.min(q[1], q[3], q[5], q[7]), Math.max(q[0], q[2], q[4], q[6]), Math.max(q[1], q[3], q[5], q[7])]) });
          if (hits.length >= maxHits) break;
        }
      } finally { page.destroy(); }
    }
    return hits;
  } finally { doc.destroy(); }
}

export function renderPagePNG(bytes, pageIndex = 0, { password = '', scale = 1, showExtras = true, format = 'png', quality = 85 } = {}) {
  const doc = openPDF(bytes, password);
  let page, pixmap;
  try {
    page = validPage(doc, pageIndex);
    pixmap = renderPixmap(page, scale, showExtras);
    return { bytes: bytesOf(format === 'jpeg' ? pixmap.asJPEG(quality) : pixmap.asPNG()), width: pixmap.getWidth(), height: pixmap.getHeight(), bounds: page.getBounds(), scale, mime: format === 'jpeg' ? 'image/jpeg' : 'image/png' };
  } finally { close(pixmap); close(page); doc.destroy(); }
}

export function renderPagePixels(bytes, pageIndex = 0, { password = '', scale = 1, showExtras = true } = {}) {
  const doc = openPDF(bytes, password);
  let page, pixmap;
  try {
    page = validPage(doc, pageIndex);
    pixmap = renderPixmap(page, scale, showExtras);
    return { pixels: new Uint8Array(pixmap.getPixels()), width: pixmap.getWidth(), height: pixmap.getHeight(), components: pixmap.getNumberOfComponents(), stride: pixmap.getStride(), bounds: page.getBounds(), scale };
  } finally { close(pixmap); close(page); doc.destroy(); }
}

export function decryptPDF(bytes, password = '') {
  const doc = openPDF(bytes, password);
  try { return save(doc, `${FULL_SAVE},encrypt=none`); } finally { doc.destroy(); }
}

function optionPassword(value, label) {
  const text = String(value || '');
  // MuPDF options are comma-separated, without a documented escape syntax.
  if (text.includes(',') || /[\u0000\r\n]/.test(text)) throw new Error(`${label} cannot contain commas, NUL, or line breaks.`);
  if (new TextEncoder().encode(text).length > 127) throw new Error(`${label} exceeds 127 UTF-8 bytes.`);
  return text;
}
export function protectPDF(bytes, { password = '', ownerPassword = '', permissions = -4 } = {}, inputPassword = '') {
  const user = optionPassword(password, 'Open password');
  const owner = optionPassword(ownerPassword || password, 'Owner password');
  if (!user && !owner) throw new Error('Enter an open password or an owner password.');
  if (!Number.isInteger(permissions)) throw new Error('Permissions must be a PDF integer bit mask.');
  const doc = openPDF(bytes, inputPassword);
  try { return save(doc, `${FULL_SAVE},encrypt=aes-256,user-password=${user},owner-password=${owner},permissions=${permissions}`); }
  finally { doc.destroy(); }
}

export function optimizePDF(bytes, { password = '', subsetFonts = true, sanitize = false } = {}) {
  const doc = openPDF(bytes, password);
  try {
    if (sanitize) sanitizeDocument(doc);
    if (subsetFonts) doc.subsetFonts();
    return save(doc);
  } finally { doc.destroy(); }
}

// Native sanitation removes non-page-content stores that can retain sensitive
// material. Raster reconstruction below is the stronger confidentiality mode.
function sanitizeDocument(doc) {
  const trailer = doc.getTrailer();
  trailer.delete('Info');
  const root = trailer.get('Root');
  for (const key of ['Metadata', 'Names', 'AF', 'OpenAction', 'AA', 'AcroForm', 'Outlines', 'StructTreeRoot', 'MarkInfo', 'PieceInfo', 'Collection', 'Threads', 'Dests', 'SpiderInfo', 'Perms', 'Legal', 'Requirements']) root.delete(key);
  const seen = new Set();
  const removeKeys = new Set(['Metadata', 'PieceInfo', 'AF', 'AA', 'OpenAction', 'JS', 'JavaScript', 'ActualText', 'Alt', 'TU', 'TM', 'EmbeddedFiles', 'RichMediaContent', 'RichMediaSettings']);
  function walk(obj, depth = 0) {
    if (!obj || obj.isNull() || depth > 150) return;
    if (obj.isIndirect()) { const id = obj.asIndirect(); if (seen.has(id)) return; seen.add(id); }
    if (obj.isDictionary()) {
      const entries = [];
      obj.forEach((value, key) => entries.push([value, key]));
      for (const [value, key] of entries) {
        if (removeKeys.has(key)) obj.delete(key);
        else walk(value, depth + 1);
      }
    } else if (obj.isArray()) {
      obj.forEach(value => walk(value, depth + 1));
    }
  }
  walk(root);
  for (let i = 0; i < doc.countPages(); i++) {
    const page = doc.loadPage(i);
    try {
      const obj = page.getObject();
      obj.delete('Annots'); obj.delete('PresSteps'); obj.delete('Thumb'); obj.delete('StructParents');
    } finally { page.destroy(); }
  }
}

function applyRegions(doc, regions, { blackBoxes = true, textOnly = false } = {}) {
  const grouped = new Map();
  for (const region of regions) { if (!grouped.has(region.page)) grouped.set(region.page, []); grouped.get(region.page).push(region); }
  for (const [index, items] of grouped) {
    const page = doc.loadPage(index);
    try {
      for (const item of items) {
        const annotation = page.createAnnotation('Redact');
        annotation.setRect(item.rect);
        annotation.update();
      }
      page.applyRedactions(blackBoxes,
        textOnly ? mupdf.PDFPage.REDACT_IMAGE_NONE : mupdf.PDFPage.REDACT_IMAGE_PIXELS,
        textOnly ? mupdf.PDFPage.REDACT_LINE_ART_NONE : mupdf.PDFPage.REDACT_LINE_ART_REMOVE_IF_TOUCHED,
        mupdf.PDFPage.REDACT_TEXT_REMOVE);
    } finally { page.destroy(); }
  }
}

function rasterRebuild(doc, { dpi = 150, quality = 92, format = 'png', masks = [], blackBoxes = true } = {}) {
  const scale = ensureScale(dpi / 72);
  const output = new mupdf.PDFDocument();
  try {
    for (let i = 0; i < doc.countPages(); i++) {
      const page = doc.loadPage(i);
      let pixmap, image;
      try {
        const bounds = page.getBounds(), width = bounds[2] - bounds[0], height = bounds[3] - bounds[1];
        pixmap = renderPixmap(page, scale, true);
        // Reapply masks to the actual pixels, after all annotations and widgets
        // have rendered. An existing FreeText/Stamp annotation must never be
        // able to paint sensitive content back over a native redaction box.
        const pageMasks = masks.filter(mask => mask.page === i);
        if (pageMasks.length) {
          const pixels = pixmap.getPixels(), stride = pixmap.getStride(), components = pixmap.getNumberOfComponents();
          for (const mask of pageMasks) {
            const [x0, y0, x1, y1] = mask.rect;
            const left = Math.max(0, Math.floor((x0 - bounds[0]) * scale)), top = Math.max(0, Math.floor((y0 - bounds[1]) * scale));
            const right = Math.min(pixmap.getWidth(), Math.ceil((x1 - bounds[0]) * scale)), bottom = Math.min(pixmap.getHeight(), Math.ceil((y1 - bounds[1]) * scale));
            for (let y = top; y < bottom; y++) pixels.fill(blackBoxes ? 0 : 255, y * stride + left * components, y * stride + right * components);
          }
        }
        image = new mupdf.Image(format === 'jpeg' ? pixmap.asJPEG(quality) : pixmap.asPNG());
        const ref = output.addImage(image);
        const pageObject = output.addPage([0, 0, width, height], 0, { XObject: { Im0: ref } }, `q ${width} 0 0 ${height} 0 0 cm /Im0 Do Q`);
        output.insertPage(-1, pageObject);
      } finally { close(image); close(pixmap); page.destroy(); }
    }
    return save(output, `${FULL_SAVE},encrypt=none`);
  } finally { output.destroy(); }
}

export function redactPDF(bytes, regions, { password = '', sanitize = true, blackBoxes = true, rasterize = true, dpi = 150 } = {}) {
  const doc = openPDF(bytes, password);
  try {
    const checked = ensureRegions(doc, regions);
    applyRegions(doc, checked, { blackBoxes });
    if (rasterize) return rasterRebuild(doc, { dpi, masks: checked, blackBoxes });
    if (sanitize) sanitizeDocument(doc);
    return save(doc, `${FULL_SAVE},encrypt=none`);
  } finally { doc.destroy(); }
}

function shallowDict(doc, original) {
  const dict = doc.newDictionary();
  if (original && !original.isNull()) original.forEach((value, key) => dict.put(key, value));
  return dict;
}
function appendContent(doc, page, content) {
  const obj = page.getObject(), original = obj.get('Contents'), array = doc.newArray();
  if (!original.isNull()) {
    if (original.isArray()) original.forEach(value => array.push(value));
    else array.push(original);
  }
  array.push(doc.addStream(content, {}));
  obj.put('Contents', array);
}
function literal(text) { return text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)'); }
function layoutReplacement(item, font) {
  const text = String(item.text ?? '');
  if (/[^\x20-\x7e\r\n\t]/.test(text)) throw new Error('Existing-text replacement currently supports basic Latin characters. Use an added text box for other scripts.');
  const rect = item.rect, pad = Math.max(0, Number(item.padding ?? 1));
  const width = rect[2] - rect[0] - pad * 2, height = rect[3] - rect[1] - pad * 2;
  let size = Number(item.size || 12);
  if (!Number.isFinite(size) || size < 4 || size > 144) throw new Error('Replacement font size must be between 4 and 144 points.');
  const advance = text => [...text].reduce((sum, ch) => sum + font.advanceGlyph(font.encodeCharacter(ch)), 0) * size;
  const lines = [];
  for (const paragraph of text.replace(/\r/g, '').replace(/\t/g, '    ').split('\n')) {
    let current = '';
    for (const word of paragraph.split(' ')) {
      const next = current ? `${current} ${word}` : word;
      if (advance(next) <= width) current = next;
      else {
        if (current) lines.push(current);
        if (advance(word) > width) throw new Error('Replacement text is too wide. Select a larger region or reduce the font size.');
        current = word;
      }
    }
    lines.push(current);
  }
  const leading = size * 1.4;
  // MuPDF's Helvetica text bounds include its full ascender/descender box.
  if (lines.length && size * 1.374 + (lines.length - 1) * leading > height) throw new Error('Replacement text does not fit. Select a taller region or reduce the font size.');
  const color = item.color || [0, 0, 0];
  if (!Array.isArray(color) || color.length !== 3 || color.some(v => !Number.isFinite(v) || v < 0 || v > 1)) throw new Error('Replacement colour must be three values between 0 and 1.');
  return { ...item, text, lines, size, leading, pad, color };
}

export function replaceTextPDF(bytes, replacements, { password = '' } = {}) {
  const doc = openPDF(bytes, password), font = new mupdf.Font('Helvetica');
  try {
    const items = ensureRegions(doc, replacements).map(item => layoutReplacement(item, font));
    // Layout is validated before deleting any content. Only text is removed;
    // image backgrounds and graphics remain. This is bounded replacement.
    applyRegions(doc, items, { blackBoxes: false, textOnly: true });
    const fontRef = doc.addSimpleFont(font, 'Latin');
    for (const item of items) {
      const page = doc.loadPage(item.page);
      try {
        const obj = page.getObject(), resources = shallowDict(doc, obj.getInheritable('Resources'));
        const fonts = shallowDict(doc, resources.get('Font'));
        fonts.put('PdfProEdit', fontRef); resources.put('Font', fonts); obj.put('Resources', resources);
        // MuPDF 1.28.1 exposes PDF-user-space -> page-space here; invert to
        // insert in page coordinates, including page rotation and crop offset.
        const t = mupdf.Matrix.invert(page.getTransform()), x = item.rect[0] + item.pad, y = item.rect[1] + item.pad + item.size * 1.075;
        let stream = `q ${t.join(' ')} cm ${item.rect[0]} ${item.rect[1]} ${item.rect[2] - item.rect[0]} ${item.rect[3] - item.rect[1]} re W n BT /PdfProEdit ${item.size} Tf ${item.color.join(' ')} rg `;
        item.lines.forEach((line, index) => { stream += `1 0 0 -1 ${x} ${y + index * item.leading} Tm (${literal(line)}) Tj `; });
        stream += 'ET Q';
        appendContent(doc, page, stream);
      } finally { page.destroy(); }
    }
    return save(doc, `${FULL_SAVE},encrypt=none`);
  } finally { font.destroy(); doc.destroy(); }
}

export function updateMetadataPDF(bytes, metadata, { password = '' } = {}) {
  const doc = openPDF(bytes, password);
  try {
    for (const key of INFO_KEYS) if (Object.hasOwn(metadata, key)) doc.setMetaData(`info:${key}`, String(metadata[key] || ''));
    // Remove stale XMP so old title/author values do not contradict edited Info.
    doc.getTrailer().get('Root').delete('Metadata');
    return save(doc);
  } finally { doc.destroy(); }
}

export function flattenPDF(bytes, { password = '', annotations = true, forms = true } = {}) {
  const doc = openPDF(bytes, password);
  try { doc.bake(annotations, forms); return save(doc); } finally { doc.destroy(); }
}

export function sanitizePDF(bytes, { password = '', rasterize = false, dpi = 150 } = {}) {
  const doc = openPDF(bytes, password);
  try { if (rasterize) return rasterRebuild(doc, { dpi }); sanitizeDocument(doc); return save(doc, `${FULL_SAVE},encrypt=none`); }
  finally { doc.destroy(); }
}

export const engineInfo = Object.freeze({ name: 'MuPDF', version: '1.28.1', license: 'AGPL-3.0-or-later', coordinates: 'top-left, y down, 72 units/inch, zero-based pages', redactionDefault: 'raster rebuild of all pages at 150 dpi', textEditing: 'bounded replacement, Helvetica, basic Latin' });
