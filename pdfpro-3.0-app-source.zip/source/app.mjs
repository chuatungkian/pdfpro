import * as PDFLib from 'pdf-lib';
import forge from 'node-forge';
import * as Engine from './engine.js';
import {createTextAnnotation} from './annotations.js';
import {toolIcon} from './tool-icons.js';
import {SYSTEM_FONTS,systemFontFamily,renderSystemText,measureSystemText} from './system-fonts.js';
import {drawSystemText,removeSystemTextBoxes,scaleSystemTextBoxes} from './pdf-font-text.js';
import {LocalWorkspaceStore} from './local-store.js';
import {WorkspaceAutosave} from './workspace-autosave.js';
import {PageToolbar} from './page-toolbar.js';
import {ContinuousPages} from './continuous-pages.js';
import {webLink,pageLink,inspectLinks,writeLink} from './pdf-links.js';
import {composeVisualSignature} from './visual-signature.js';
import {directTextTargets,replaceDirectText,addedTextTargets,saveDirectEdit,directFontData} from './direct-text.js';
import {openDirectEditor} from './direct-editor.js';
import {MergeSplitWorkspace} from './merge-split.js';
import {normaliseSplitPlan} from './split-planner.js';
import {rebuildSourceZip} from './source-package.js';
import {inkPoint,appendInkSamples,savedInkPoints} from './freehand.js';
import * as OCR from './ocr.js';
import './signing.js';

window.PDFLib = PDFLib;
window.forge = forge;
const {PDFDocument, StandardFonts, rgb, degrees, PDFName, PDFString, PDFArray, PDFDict, PDFRef, pushGraphicsState,popGraphicsState,beginText,endText,setFontAndSize,setTextRenderingMode,setTextMatrix,showText,TextRenderingMode} = PDFLib;
const mupdf = Engine.mupdf;
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => n>1048576?(n/1048576).toFixed(1)+' MB':(n/1024).toFixed(0)+' KB';
const delay = () => new Promise(r=>setTimeout(r,0));
const state={bytes:null,original:null,name:'Untitled.pdf',doc:null,page:0,zoom:1,fit:true,scrollTop:0,scrollLeft:0,group:'View',paneOpen:false,paneDocked:false,settingsOpen:false,pagesCompact:false,navCollapsed:false,font:'Arial',tool:'select',undo:[],redo:[],marks:[],hits:[],searchQuery:'',color:'#800020',size:14,dirty:false,renderId:0,abort:null,selectedImage:null,splitPlan:null,continuousView:true};
// Native PDF handles remain active-tab only. Local snapshots are stored in IndexedDB.
const tabs=[];
let activeTabId=null,nextTabId=1,pendingActions=0,documentTransitions=0,restoringView=false,homeVisible=true,splitWorkspace=null,continuousPages=null;
const documentKeys=['bytes','original','name','page','zoom','fit','scrollTop','scrollLeft','group','font','tool','undo','redo','marks','hits','searchQuery','dirty','selectedImage','splitPlan','continuousView'];
const emptyDocument=()=>({bytes:null,original:null,name:'Untitled.pdf',page:0,zoom:1,fit:true,scrollTop:0,scrollLeft:0,group:'View',font:'Arial',tool:'select',undo:[],redo:[],marks:[],hits:[],searchQuery:'',dirty:false,selectedImage:null,splitPlan:null,continuousView:true});
function snapshotDocument(){return Object.fromEntries(documentKeys.map(key=>[key,state[key]]))}
function rememberDocument(){const tab=tabs.find(tab=>tab.id===activeTabId);if(tab){if(!restoringView&&!homeVisible&&!splitWorkspace?.isOpen){state.scrollTop=$('main').scrollTop;state.scrollLeft=$('main').scrollLeft}tab.snapshot=snapshotDocument()}}
function hasUnsavedDocuments(){return tabs.some(tab=>{const doc=tab.id===activeTabId?state:tab.snapshot;return doc.dirty||doc.marks.length})||(!tabs.length&&(state.dirty||state.marks.length))}
function transitionBlocked(){return pendingActions>0||documentTransitions>0||!!state.abort||!!$('modalroot').firstChild||!!drag}
function renderTabs(){
  rememberDocument();
  const root=$('documenttabs'),focused=root.contains(document.activeElement)?document.activeElement:null;
  const focusId=focused?.closest('[data-tab-id]')?.dataset.tabId,focusClose=focused?.classList.contains('document-tab-close');
  root.innerHTML=tabs.length?tabs.map(tab=>{
    const doc=tab.snapshot,active=tab.id===activeTabId&&!homeVisible,unsaved=doc.dirty||doc.marks.length;
    return `<div class="document-tab ${active?'active':''}" data-tab-id="${tab.id}"><button type="button" class="document-tab-select" id="tab-${tab.id}" role="tab" aria-controls="main" aria-selected="${active}" tabindex="${tab.id===activeTabId?'0':'-1'}" title="${esc(doc.name)}${unsaved?' · Unsaved changes':''}"><span class="tab-name">${esc(doc.name)}</span>${unsaved?'<span class="tab-dirty" aria-label="Unsaved changes">•</span>':''}</button><button type="button" class="document-tab-close" aria-label="Close ${esc(doc.name)}" title="Close ${esc(doc.name)}">×</button></div>`;
  }).join(''):'<span class="documents-empty">Open PDFs to work in separate tabs</span>';
  root.querySelectorAll('.document-tab').forEach(element=>{
    const id=element.dataset.tabId,button=element.querySelector('.document-tab-select');
    button.onclick=guard(()=>switchTab(id));
    element.querySelector('.document-tab-close').onclick=guard(()=>closeTab(id));
    button.onkeydown=event=>{
      const index=tabs.findIndex(tab=>tab.id===id);let next;
      if(event.key==='ArrowRight')next=(index+1)%tabs.length;
      if(event.key==='ArrowLeft')next=(index+tabs.length-1)%tabs.length;
      if(event.key==='Home')next=0;
      if(event.key==='End')next=tabs.length-1;
      if(next===undefined)return;
      event.preventDefault();event.stopPropagation();
      guard(async()=>{if(await switchTab(tabs[next].id))$('tab-'+activeTabId)?.focus()})();
    };
  });
  $('main').setAttribute('role',homeVisible?'region':'tabpanel');
  if(activeTabId&&!homeVisible){$('main').setAttribute('aria-labelledby','tab-'+activeTabId);$('main').removeAttribute('aria-label')}
  else{$('main').removeAttribute('aria-labelledby');$('main').setAttribute('aria-label','Documents')}
  if(focusId)root.querySelector(`[data-tab-id="${focusId}"] .${focusClose?'document-tab-close':'document-tab-select'}`)?.focus();
  root.querySelector('.document-tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});
}
function resetDocumentTargets(){directEditor?.close();state.renderId++;annotationHits=[];commentPress=null;drag=null;$('overlay').innerHTML='';$('dragrect')?.remove();window.getSelection()?.removeAllRanges()}
async function showDocument(label){
  splitWorkspace?.close();pageToolbar.openMenu(false);
  homeVisible=false;recentGeneration++;document.body.classList.remove('home-visible');$('homeBtn').setAttribute('aria-pressed','false');
  restoringView=true;
  try{
    $('welcome').classList.add('hidden');$('viewer').classList.remove('hidden');
    refresh();await render();if(!state.continuousView){state.scrollTop=continuousPages.pageTop(state.page)+state.scrollTop;state.continuousView=true}$('main').scrollTop=state.scrollTop;$('main').scrollLeft=state.scrollLeft;
  }finally{restoringView=false}
  status(label);await persistLocal();
}
async function activateTab(tab){
  const next=Engine.openPDF(tab.snapshot.bytes);
  rememberDocument();resetDocumentTargets();closeDoc();
  activeTabId=tab.id;Object.assign(state,tab.snapshot);state.doc=next;state.settingsOpen=false;
  await showDocument('Active PDF · '+state.name);
}
async function switchTab(id){
  // UI callbacks themselves hold one guard; any other action must finish first.
  if(pendingActions>1||documentTransitions||state.abort||$('modalroot').firstChild||drag){toast('Finish the current operation before switching PDFs.');return false}
  const tab=tabs.find(tab=>tab.id===id);if(!tab)return false;
  documentTransitions++;try{if(id===activeTabId){if(homeVisible||splitWorkspace?.isOpen)await showDocument('Active PDF · '+state.name)}else await activateTab(tab);return true}finally{documentTransitions--}
}
async function addDocument(bytes,{name='Untitled.pdf',dirty=false,page=0,marks=[],fit=true,zoom=1,font='Arial',label='Opened '+name}={}){
  bytes=new Uint8Array(bytes);
  const next=Engine.openPDF(bytes),count=next.countPages();
  if(!count){next.destroy();throw Error('This PDF has no pages')}
  rememberDocument();resetDocumentTargets();closeDoc();
  const snapshot={...emptyDocument(),bytes,original:bytes.slice(),name:String(name),dirty,page:Math.max(0,Math.min(count-1,page)),marks,fit,zoom,continuousView:page===0,font:SYSTEM_FONTS.includes(font)?font:'Arial'};
  const tab={id:globalThis.crypto?.randomUUID?.()||'pdf-'+Date.now().toString(36)+'-'+nextTabId++,snapshot,pageCount:count};tabs.push(tab);activeTabId=tab.id;Object.assign(state,snapshot);state.doc=next;state.settingsOpen=false;
  await showDocument(label);return tab.id;
}
async function closeTab(id){
  if(pendingActions>1||documentTransitions||state.abort||$('modalroot').firstChild||drag){toast('Finish the current operation before closing a PDF.');return false}
  const tab=tabs.find(tab=>tab.id===id);if(!tab)return false;const wasHome=homeVisible;
  documentTransitions++;
  try{
    rememberDocument();
    const locallySaved=await persistLocal();
    if(!locallySaved&&(tab.snapshot.dirty||tab.snapshot.marks.length)&&!await confirm('Close '+tab.snapshot.name+'?','This tab has edits or redaction marks that are not saved locally. Save PDF or Save workspace first to keep your work. Closing this tab discards its working copy.','Close tab'))return false;
    const index=tabs.indexOf(tab);
    if(id===activeTabId){
      const neighbour=tabs[index+1]||tabs[index-1];
      if(neighbour)await activateTab(neighbour);
      else{
        splitWorkspace?.close();resetDocumentTargets();closeDoc();activeTabId=null;Object.assign(state,emptyDocument());
        homeVisible=true;recentSignature='';document.body.classList.add('home-visible');$('homeBtn').setAttribute('aria-pressed','true');
        $('welcome').classList.remove('hidden');$('viewer').classList.add('hidden');
      }
    }
    tabs.splice(index,1);tab.snapshot=null;
    if(wasHome){homeVisible=true;recentSignature='';document.body.classList.add('home-visible');$('homeBtn').setAttribute('aria-pressed','true');$('welcome').classList.remove('hidden');$('viewer').classList.add('hidden')}
    refresh();await persistLocal();
    if(!tabs.length)status('Ready · Open a file to begin');
    $('tab-'+activeTabId)?.focus();return true;
  }finally{documentTransitions--}
}
let annotationHits=[],directEditor=null;
let commentPress=null;
const groups={'View':'01','Organize':'02','Edit':'03','Annotate':'04','Forms':'05','OCR & compare':'06','Protect & sign':'07','Export & batch':'08'};
const tools={
  View:[['search','Find text'],['bookmarks','Bookmarks'],['metadata','Properties'],['attachments','Attachments']],
  Organize:[['rotate','Rotate 90°'],['duplicate','Duplicate'],['moveup','Move earlier'],['movedown','Move later'],['delete','Delete page'],['blank','Insert blank'],['merge','Merge files'],['extract','Extract pages'],['split','Merge & split'],['reorder','Reorder pages'],['crop','Crop area'],['resize','Resize page']],
  Edit:[['directedit','Direct edit'],['text','Add text'],['image','Add image'],['replace','Replace text'],['link','Add link'],['watermark','Watermark'],['number','Page numbers'],['bates','Bates numbers'],['header','Header / footer']],
  Annotate:[['highlight','Highlight'],['underline','Underline'],['strikeout','Strikeout'],['note','Sticky note'],['freetext','Text comment'],['ink','Draw'],['rectangle','Rectangle'],['ellipse','Ellipse'],['line','Line'],['arrow','Arrow'],['stamp','Stamp'],['comments','Comments']],
  Forms:[['fill','Fill form'],['fieldText','Text field'],['fieldCheck','Checkbox'],['fieldRadio','Radio group'],['fieldDropdown','Dropdown'],['flatten','Flatten form'],['formexport','Export values'],['formimport','Import values']],
  'OCR & compare':[['ocr','Recognise text'],['compare','Compare PDFs'],['textExport','Extract text'],['optimize','Optimise PDF']],
  'Protect & sign':[['redact','Mark redaction'],['applyredact','Apply redactions'],['clearmarks','Clear marks'],['sanitize','Sanitise PDF'],['encrypt','Encrypt PDF'],['signature','Visual signature'],['certsign','Certificate sign'],['verify','Verify signatures']],
  'Export & batch':[['save','Save PDF'],['png','Page to PNG'],['jpeg','Page to JPEG'],['allimages','All pages to PNG'],['textExport','Extract text'],['project','Save workspace'],['restore','Open workspace'],['batch','Batch tools'],['print','Print document']]
};


const groupIcons={View:'view',Organize:'reorder',Edit:'edit',Annotate:'comments',Forms:'fill','OCR & compare':'ocr','Protect & sign':'encrypt','Export & batch':'save'};
let localProblem=null,storageErrorShown='';
const pageToolbar=new PageToolbar({host:$('pageToolbarHost'),bar:$('pageToolbar'),onChange:scheduleLocal,onInteractionStart:cancelPageDrag});
continuousPages=new ContinuousPages({root:$('main'),viewer:$('viewer'),wrap:$('pagewrap'),canvas:$('pagecanvas'),overlay:$('overlay'),api:{
  visible:()=>!!state.doc&&!homeVisible&&!splitWorkspace?.isOpen&&!$('viewer').classList.contains('hidden'),
  canActivate:()=>!restoringView&&!pendingActions&&!documentTransitions&&!state.abort&&!drag&&!$('modalroot').firstChild,
  cancelGesture:()=>{if(drag)cancelPageDrag()},scale:value=>{state.zoom=value},layers:drawPageOverlays,
  activate:(page,hits)=>{cancelPageDrag();state.page=page;annotationHits=hits;refreshNavigation();scheduleLocal()}
}});
const localStore=new LocalWorkspaceStore();
const localAutosave=new WorkspaceAutosave({store:localStore,capture:captureLocalWorkspace,onState:localStorageState});
splitWorkspace=new MergeSplitWorkspace({root:$('mergeSplitView'),api:{
  scrollRoot:$('main'),run:fn=>guard(fn)(),job,listSources:listSplitSources,getSource:readSplitSource,
  chooseFiles:()=>choose('application/pdf',true),importFiles:importSplitFiles,ensureSafe:ensureSplitSourcesSafe,
  visibility:open=>document.body.classList.toggle('split-workspace-open',open),
  savePlan:(id,plan)=>{if(id===activeTabId){state.splitPlan=plan;scheduleLocal()}},
  close:guard(()=>showDocument('Returned to PDF · '+state.name)),
  openMerged:async(bytes,name)=>{requireDocumentTransition();documentTransitions++;try{await addDocument(bytes,{name,dirty:true,label:'Merged working copy created'})}finally{documentTransitions--}}
}});
function captureLocalWorkspace(){
  rememberDocument();
  return {documents:tabs.map(tab=>({id:tab.id,snapshot:tab.snapshot,pageCount:tab.pageCount||1})),session:{openIds:tabs.map(tab=>tab.id),activeId:activeTabId,preferences:{pageToolbar:pageToolbar.preferences(),navCollapsed:state.navCollapsed,pagesCompact:state.pagesCompact,paneDocked:state.paneDocked,dark:document.body.classList.contains('dark'),color:state.color,size:state.size}}};
}
function localStorageState(value,error){
  const labels={saved:'Saved on this device',saving:'Saving locally…',waiting:'Local save pending',error:'Not saved locally',unavailable:'Local saving unavailable'};
  $('storageStatus').dataset.state=value;$('storageLabel').textContent=labels[value]||labels.unavailable;
  if(error)localProblem=error;
  else if(value==='saved'){localProblem=null;storageErrorShown='';void refreshLocalCount()}
  $('storageStatus').title=error?.message||'Open the Local library';
  if(value==='error'&&error){
    const message=error.name==='QuotaExceededError'?'Browser storage is full. Export current work, or remove closed copies from the Local library.':error.message;
    if(message!==storageErrorShown){storageErrorShown=message;toast('Local save failed. '+message)}
  }
}
function scheduleLocal(){localAutosave.schedule()}
function persistLocal(){return localAutosave.flush()}
let catalogueRead=0,recentGeneration=0,recentSignature='',appClosed=false;
const recentPreviews=new Map();
async function refreshLocalCount(){
  if(appClosed)return;
  const request=++catalogueRead;
  try{
    const rows=await localStore.listDocuments();if(appClosed||request!==catalogueRead)return;
    $('libraryCount').textContent=rows.length?String(rows.length):'';
    if(homeVisible)await renderRecentDocuments(rows);
  }catch(error){if(!appClosed&&homeVisible&&request===catalogueRead)showRecentUnavailable(error)}
}
function showRecentUnavailable(error){
  recentGeneration++;recentSignature='';$('recentDocuments').replaceChildren();$('recentDocuments').setAttribute('aria-busy','false');
  $('recentEmpty').hidden=false;$('recentEmpty').querySelector('strong').textContent='Local library unavailable';
  $('recentEmpty').querySelector('span:last-child').textContent='You can still open and download PDFs. '+(error?.message||'Local storage is unavailable here.');
  $('recentSummary').textContent='Open files to begin a new session';
}
async function renderRecentDocuments(rows){
  if(!homeVisible)return;
  const recent=rows.slice(0,6),signature=JSON.stringify({recent,openIds:tabs.map(tab=>tab.id)});
  if(signature===recentSignature)return;
  recentSignature=signature;const generation=++recentGeneration,root=$('recentDocuments');
  root.setAttribute('aria-busy',String(!!recent.length));
  $('recentSummary').textContent=rows.length?rows.length+' locally saved document'+(rows.length===1?'':'s')+' · Most recently used first':'Saved documents are kept on this device';
  $('recentEmpty').hidden=!!recent.length;
  $('recentEmpty').querySelector('strong').textContent='Your documents will appear here';
  $('recentEmpty').querySelector('span:last-child').textContent='Open a PDF to start. Saved working copies stay in your local library.';
  // Only tiny first-page PNGs are cached. Full PDF snapshots are read one at a time
  // while Home is visible; normal view autosaves do not rerender unchanged previews.
  const validKeys=new Set(recent.map(row=>row.id+':'+(row.contentRevision??row.contentUpdatedAt??row.updatedAt)));
  for(const key of recentPreviews.keys())if(!validKeys.has(key))recentPreviews.delete(key);
  root.innerHTML=recent.map(row=>{
    const date=new Date(row.updatedAt),dateLabel=Number.isFinite(date.getTime())?date.toLocaleDateString('en-GB',{day:'numeric',month:'short'}):'Saved locally';
    const pageCount=row.pageCount||1;
    return `<article class="recent-card" data-recent-id="${esc(row.id)}"><div class="recent-preview"><div class="preview-placeholder">${toolIcon('blank')}<span>Loading preview…</span></div>${tabs.some(tab=>tab.id===row.id)?'<span class="recent-state">Open in a tab</span>':''}</div><div class="recent-body"><h3 title="${esc(row.name)}">${esc(row.name)}</h3><p class="recent-meta">${pageCount} ${pageCount===1?'page':'pages'} · ${fmt(row.byteLength)}${row.marks?' · Pending redactions':''}</p><div class="recent-footer"><time ${Number.isFinite(date.getTime())?'datetime="'+date.toISOString()+'"':''}>${esc(dateLabel)}</time><button type="button" data-resume="${esc(row.id)}" aria-label="Resume ${esc(row.name)}">Resume <span aria-hidden="true">↗</span></button></div></div></article>`;
  }).join('');
  root.querySelectorAll('[data-resume]').forEach(button=>button.onclick=guard(()=>openStoredDocument(button.dataset.resume)));
  for(const row of recent){
    await delay();if(generation!==recentGeneration||!homeVisible)return;
    const card=[...root.children].find(card=>card.dataset.recentId===row.id),placeholder=card?.querySelector('.preview-placeholder');
    if(!placeholder)continue;
    const key=row.id+':'+(row.contentRevision??row.contentUpdatedAt??row.updatedAt);
    try{
      let preview=recentPreviews.get(key);
      if(!preview){
        const record=await localStore.getDocument(row.id);if(generation!==recentGeneration||!homeVisible)return;
        if(!record?.snapshot?.bytes)throw Error('Stored copy unavailable');
        let doc,page,pix;
        try{
          doc=Engine.openPDF(record.snapshot.bytes);page=doc.loadPage(0);const b=page.getBounds();
          const scale=Math.min(180/(b[2]-b[0]),150/(b[3]-b[1]));
          if(!Number.isFinite(scale)||scale<=0)throw Error('Invalid page dimensions');
          pix=page.toPixmap([scale,0,0,scale,-b[0]*scale,-b[1]*scale],mupdf.ColorSpace.DeviceRGB,false,true);
          preview='data:image/png;base64,'+toBase64(pix.asPNG());recentPreviews.set(key,preview);
        }finally{pix?.destroy();page?.destroy();doc?.destroy()}
      }
      const image=document.createElement('img');image.alt='First page of '+row.name;image.src=preview;image.decoding='async';placeholder.replaceWith(image);
    }catch{placeholder.innerHTML=toolIcon('blank')+'<span>Preview unavailable</span>'}
  }
  if(generation===recentGeneration)root.setAttribute('aria-busy','false');
}
async function showHome(){
  pageToolbar.openMenu(false);requireDocumentTransition();directEditor?.close();rememberDocument();splitWorkspace?.close();
  homeVisible=true;recentSignature='';state.paneOpen=false;state.settingsOpen=false;
  document.body.classList.add('home-visible');$('homeBtn').setAttribute('aria-pressed','true');
  $('welcome').classList.remove('hidden');$('viewer').classList.add('hidden');$('main').scrollTop=0;$('main').scrollLeft=0;
  refresh();$('welcome').focus();await persistLocal();await refreshLocalCount();
}
function applyInterfacePreferences(preferences={}){
  if(!preferences||typeof preferences!=='object')preferences={};
  pageToolbar.restore(preferences.pageToolbar);
  for(const key of ['navCollapsed','pagesCompact','paneDocked'])state[key]=preferences[key]===true;
  if(/^#[\da-f]{6}$/i.test(preferences.color||''))state.color=preferences.color;
  if(Number.isFinite(preferences.size))state.size=Math.max(4,Math.min(144,preferences.size));
  document.body.classList.toggle('dark',preferences.dark===true);
  document.body.classList.toggle('nav-compact',state.navCollapsed);document.body.classList.toggle('pages-compact',state.pagesCompact);
  const navLabel=state.navCollapsed?'Expand navigation':'Collapse navigation';
  $('toggleNav').setAttribute('aria-label',navLabel);$('toggleNav').setAttribute('aria-expanded',String(!state.navCollapsed));$('toggleNav').title=navLabel;
  const pagesLabel=state.pagesCompact?'Expand page previews':'Compact page previews';
  $('togglePages').setAttribute('aria-label',pagesLabel);$('togglePages').setAttribute('aria-expanded',String(!state.pagesCompact));$('togglePages').title=pagesLabel;
}
function restoreSnapshot(record){
  if(!record||!/^[-a-zA-Z0-9_]{1,80}$/.test(record.id)||!(record.snapshot?.bytes instanceof Uint8Array))throw Error('This stored copy is incomplete.');
  const source=record.snapshot,doc=Engine.openPDF(source.bytes);let count;
  try{count=doc.countPages();if(!count)throw Error('This stored PDF has no pages.')}finally{doc.destroy()}
  const snapshot={...emptyDocument(),bytes:source.bytes,original:source.original instanceof Uint8Array?source.original:source.bytes,name:String(source.name||'Recovered.pdf')};
  snapshot.page=Math.max(0,Math.min(count-1,Math.floor(+source.page)||0));
  snapshot.zoom=Number.isFinite(source.zoom)?Math.max(.2,Math.min(4,source.zoom)):1;snapshot.fit=source.fit!==false;
  for(const key of ['scrollTop','scrollLeft'])snapshot[key]=Number.isFinite(source[key])?Math.max(0,source[key]):0;
  snapshot.group=Object.hasOwn(groups,source.group)?source.group:'View';snapshot.font=SYSTEM_FONTS.includes(source.font)?source.font:'Arial';
  const validTools=['select','signatureImage',...Object.values(tools).flatMap(items=>items.map(item=>item[0]))];
  snapshot.tool=validTools.includes(source.tool)?source.tool:'select';snapshot.dirty=!!source.dirty;snapshot.splitPlan=normaliseSplitPlan(source.splitPlan);snapshot.continuousView=source.continuousView===true;
  snapshot.searchQuery=typeof source.searchQuery==='string'?source.searchQuery:'';
  for(const key of ['undo','redo'])snapshot[key]=Array.isArray(source[key])?source[key].filter(item=>item.bytes instanceof Uint8Array).slice(-20).map(item=>({bytes:item.bytes,page:Math.max(0,Math.floor(+item.page)||0)})):[];
  for(const key of ['marks','hits'])snapshot[key]=Array.isArray(source[key])?source[key].filter(item=>Number.isInteger(item.page)&&item.page>=0&&item.page<count&&Array.isArray(item.rect)&&item.rect.length===4&&item.rect.every(Number.isFinite)).map(item=>({page:item.page,rect:[...item.rect]})):[];
  if(source.selectedImage?.bytes instanceof Uint8Array&&['image/png','image/jpeg'].includes(source.selectedImage.type))snapshot.selectedImage={bytes:source.selectedImage.bytes,type:source.selectedImage.type};
  if(['image','signatureImage'].includes(snapshot.tool)&&!snapshot.selectedImage)snapshot.tool='select';
  return {id:record.id,snapshot,pageCount:count};
}
async function initialiseLocalWorkspace(){
  documentTransitions++;
  try{
    const saved=await localStore.readSession();
    if(saved&&saved.schema!==1)throw Error('This local workspace uses an unsupported version.');
    applyInterfacePreferences(saved?.preferences);
    const ids=[...new Set((Array.isArray(saved?.openIds)?saved.openIds:[]).filter(id=>typeof id==='string'))];
    const records=await localStore.getDocuments(ids);let skipped=0;
    for(const record of records){
      try{tabs.push(restoreSnapshot(record))}catch{skipped++}
    }
    if(tabs.length){
      const tab=tabs.find(tab=>tab.id===saved?.activeId)||tabs[0];activeTabId=tab.id;Object.assign(state,tab.snapshot);state.doc=Engine.openPDF(state.bytes);
      await showDocument('Recovered '+tabs.length+' locally saved PDF'+(tabs.length===1?'':'s'));
    }else refresh();
    const current=captureLocalWorkspace();localAutosave.start(current);
    // Retain skipped records in the library; only the valid open-tab list is repaired.
    if(skipped){await localStore.commit({session:current.session});toast(skipped+' stored copy could not be reopened. Other local documents remain in the library.')}
    void refreshLocalCount();
  }catch(error){localProblem=error;localStorageState('unavailable',error);showRecentUnavailable(error);refresh()}
  finally{documentTransitions--}
}
async function openStoredDocument(id){
  if(tabs.some(tab=>tab.id===id))return switchTab(id);
  requireDocumentTransition();documentTransitions++;
  try{
    let tab;try{tab=restoreSnapshot(await localStore.getDocument(id))}catch(error){throw Error('Unable to resume this stored PDF. '+error.message)}
    rememberDocument();tabs.push(tab);await activateTab(tab);
  }finally{documentTransitions--}
}
async function showLocalLibrary(){
  requireDocumentTransition();
  if(!localAutosave.enabled){await modal('Local library unavailable','<p>'+esc(localProblem?.message||'This browser cannot save documents locally at this location.')+'</p><p>Use Save PDF or Save workspace to keep your work. Browser support for local files and private browsing varies.</p>',{ok:null});return}
  await persistLocal();
  const rows=await localStore.listDocuments();
  const problem=localProblem?'<div class="notice warning">'+esc(localProblem.message)+'</div>':'';
  const choice=await modal('Local library',problem+'<p>Working copies and edits are saved in this browser profile. Closed tabs remain here. Recovery includes original bytes and undo history, even after a redacted export. Local copies may be unlocked; remove stored copies when you finish handling sensitive files.</p><input type="hidden" id="libraryAction">'+(rows.length?'<div class="local-library-list">'+rows.map(row=>{
    const open=tabs.some(tab=>tab.id===row.id),date=new Date(row.updatedAt).toLocaleString('en-GB',{dateStyle:'medium',timeStyle:'short'});
    return '<div class="local-library-row"><div class="library-file-icon">'+toolIcon('metadata')+'</div><div class="library-file-info"><strong>'+esc(row.name)+'</strong><span>'+esc(row.pageCount)+' pages · '+fmt(row.byteLength)+' · '+esc(date)+'</span></div><div class="library-file-actions"><button type="button" class="small" data-library-open="'+esc(row.id)+'">'+(open?'Switch to tab':'Open')+'</button><button type="button" class="quiet small danger" data-library-remove="'+esc(row.id)+'" '+(open?'disabled title="Close this tab before removing its stored copy"':'')+'>Remove</button></div></div>';
  }).join('')+'</div>':'<div class="notice">No documents saved here yet. Open a PDF to begin.</div>')+'<p class="help">Storage belongs to this browser and app location. Clearing browser data can erase it. Download important PDFs or workspaces as backups.</p>',{ok:null,wide:true,read:()=>$('libraryAction').value,setup:()=>{
    document.querySelectorAll('[data-library-open],[data-library-remove]').forEach(button=>button.onclick=()=>{$('libraryAction').value=button.dataset.libraryOpen?'open:'+button.dataset.libraryOpen:'remove:'+button.dataset.libraryRemove;$('modalform').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}))});
  }});
  if(!choice)return;
  const [action,id]=choice.split(':');
  if(action==='open'){await openStoredDocument(id);return}
  if(action==='remove'){
    const record=rows.find(row=>row.id===id);if(!record||tabs.some(tab=>tab.id===id))return;
    documentTransitions++;
    try{if(await confirm('Remove '+record.name+' from this device?','This deletes its stored working copy and history from the Local library. Downloaded files are kept.','Remove stored copy')){await localAutosave.remove(id);await refreshLocalCount();toast('Stored copy removed from this device.')}}finally{documentTransitions--}
  }
}

function toast(message){$('toast').textContent=message;$('toast').classList.remove('hidden');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.add('hidden'),4500)}
function status(message){$('statusText').textContent=message}
function download(bytes,name,type='application/pdf'){const blob=bytes instanceof Blob?bytes:new Blob([bytes],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000)}
function outname(suffix,ext='pdf'){return state.name.replace(/\.[^.]+$/,'')+suffix+'.'+ext}
async function choose(accept,multiple=false){return new Promise(resolve=>{const input=document.createElement('input');input.type='file';input.accept=accept;input.multiple=multiple;input.onchange=()=>resolve(multiple?[...input.files]:input.files[0]);input.oncancel=()=>resolve(multiple?[]:null);input.click()})}
async function modal(title,html,{ok='Apply',wide=false,read,setup}={}){return new Promise(resolve=>{const root=$('modalroot');const prev=document.activeElement;root.innerHTML=`<div class="modalback"><section class="modal ${wide?'wide':''}" role="dialog" aria-modal="true" aria-labelledby="modaltitle"><h2 id="modaltitle">${esc(title)}</h2><form id="modalform">${html}<div id="modalerror" class="help danger" role="alert"></div><div class="actions"><button type="button" id="modalcancel">${ok?'Cancel':'Close'}</button>${ok?`<button type="submit" class="primary">${esc(ok)}</button>`:''}</div></form></section></div>`;root.querySelectorAll('label').forEach((label,i)=>{if(label.htmlFor||label.querySelector('input,select,textarea'))return;const control=label.nextElementSibling;if(control?.matches('input,select,textarea')){if(!control.id)control.id='dialog-field-'+i;label.htmlFor=control.id}});const close=value=>{document.removeEventListener('keydown',key);root.innerHTML='';prev?.focus();resolve(value)};const key=e=>{if(e.key==='Escape')close(null);if(e.key==='Tab'){const nodes=[...root.querySelectorAll('button,input,select,textarea,a[href]')].filter(x=>!x.disabled);if(!nodes.length)return;const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}};document.addEventListener('keydown',key);$('modalcancel').onclick=()=>close(null);$('modalform').onsubmit=async e=>{e.preventDefault();try{const v=read?await read():Object.fromEntries(new FormData($('modalform')));close(v)}catch(err){$('modalerror').textContent=err.message}};setup?.();setTimeout(()=>root.querySelector('input:not([type=file]),textarea,select,button')?.focus(),20)})}
async function ask(title,label,value='',extra=''){const v=await modal(title,`<label for="answer">${esc(label)}</label><input id="answer" name="value" value="${esc(value)}" required>${extra}`);return v?.value??null}
async function confirm(title,text,ok='Continue'){return !!await modal(title,`<p>${esc(text)}</p>`,{ok})}
function showJobProgress(value){const known=typeof value==='number'&&Number.isFinite(value),fraction=known?Math.max(0,Math.min(1,value)):0;$('processingRing').classList.toggle('is-indeterminate',!known);$('processingArc').style.strokeDashoffset=known?String(100-fraction*100):'';$('processingPercent').textContent=known?Math.round(fraction*100)+'%':'';$('progress').max=1;if(known)$('progress').value=fraction;else $('progress').removeAttribute('value')}
async function job(title,fn){if(state.abort)throw Error('Another operation is running');const controller=new AbortController();state.abort=controller;$('busytitle').textContent=title;$('busydetail').textContent='Processing on your device';showJobProgress();$('busy').classList.remove('hidden');$('cancelJob').onclick=()=>controller.abort();await delay();try{return await fn((p,msg)=>{if(controller.signal.aborted)throw new DOMException('Cancelled','AbortError');showJobProgress(p);if(msg)$('busydetail').textContent=msg},controller.signal)}finally{state.abort=null;$('busy').classList.add('hidden')}}
function guard(fn){return async(...args)=>{if(documentTransitions){if(fn!==render)toast('Finish opening or closing PDFs before using another tool.');return false}pendingActions++;try{return await fn(...args)}catch(err){if(err.name==='AbortError'){toast('Operation cancelled');return}console.error(err);toast(err.message||String(err));status('Operation did not complete · '+(err.message||err))}finally{pendingActions--;if(!pendingActions)scheduleLocal()}}}
function need(){if(!state.bytes)throw Error('Open a PDF first')}
async function backgroundEngine(method,args,signal=state.abort?.signal){
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  const source='(async()=>{globalThis["$libmupdf_wasm_Module"]={locateFile:()=>"embedded.wasm",wasmBinary:Uint8Array.from(atob('+JSON.stringify(window.PDFPRO_ASSETS.mupdfBase64)+'),c=>c.charCodeAt(0))};\n'+window.PDFPRO_ASSETS.engineWorker+'\n})().catch(e=>self.postMessage({id:1,error:{message:e.message,name:e.name}}));';
  const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));
  const worker=new Worker(url);
  return new Promise((resolve,reject)=>{
    const cleanup=()=>{worker.terminate();URL.revokeObjectURL(url);signal?.removeEventListener('abort',abort)};
    const abort=()=>{cleanup();reject(new DOMException('Cancelled','AbortError'))};
    signal?.addEventListener('abort',abort,{once:true});
    worker.onerror=e=>{cleanup();reject(Error(e.message||'Background PDF task failed'))};
    worker.onmessage=e=>{if(e.data.ready){worker.postMessage({id:1,method,args});return}cleanup();if(e.data.error)reject(Object.assign(Error(e.data.error.message),{name:e.data.error.name}));else resolve(e.data.result)};

  });
}
function parsePages(value,count=state.doc?.countPages()){const out=[];for(const bit of String(value).split(',')){const m=bit.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!m)throw Error('Use page numbers or ranges, for example 1-3,5');const a=+m[1],b=+(m[2]||m[1]);if(a<1||b<1||a>count||b>count)throw Error(`Pages must be between 1 and ${count}`);for(let i=a;a<=b?i<=b:i>=b;a<=b?i++:i--)out.push(i-1)}return out}
function closeDoc(){continuousPages?.reset();state.doc?.destroy();state.doc=null}
async function setBytes(bytes,{record=true,label='Updated document',dirty=true}={}){
  if(splitWorkspace?.isOpen){splitWorkspace.close();$('main').scrollTop=state.scrollTop;$('main').scrollLeft=state.scrollLeft}
  if(!activeTabId)return addDocument(bytes,{name:state.name,dirty,page:state.page,fit:state.fit,zoom:state.zoom,label});
  bytes=new Uint8Array(bytes);const next=Engine.openPDF(bytes),view=continuousPages.captureView();
  if(record&&state.bytes){state.undo.push({bytes:state.bytes,page:state.page});let size=state.undo.reduce((n,v)=>n+v.bytes.length,0);while(state.undo.length>20||size>150*1048576){size-=state.undo.shift().bytes.length}state.redo=[]}
  const wasRestoring=restoringView;restoringView=true;
  try{
    closeDoc();state.bytes=bytes;state.doc=next;state.page=Math.min(state.page,next.countPages()-1);state.dirty=dirty;state.marks=[];state.hits=[];state.searchQuery='';homeVisible=false;recentGeneration++;
    $('welcome').classList.add('hidden');$('viewer').classList.remove('hidden');refresh();await render();
    continuousPages.restoreView(view,state.page);state.scrollTop=$('main').scrollTop;state.scrollLeft=$('main').scrollLeft;
  }finally{restoringView=wasRestoring}
  status(label);await persistLocal();
}
let thumbObserver=null;
function observeThumbs(){
  thumbObserver?.disconnect();
  if(!state.doc)return;
  const current=state.doc;
  thumbObserver=new IntersectionObserver(entries=>{
    for(const entry of entries){
      if(!entry.isIntersecting)continue;
      thumbObserver.unobserve(entry.target);
      setTimeout(()=>{
        if(state.doc!==current||!entry.target.isConnected)return;
        let page,pix;
        try{
          page=current.loadPage(+entry.target.dataset.page);
          const b=page.getBounds(),scale=Math.min(58/(b[2]-b[0]),68/(b[3]-b[1]));
          pix=page.toPixmap([scale,0,0,scale,-b[0]*scale,-b[1]*scale],mupdf.ColorSpace.DeviceRGB,true,true);
          const canvas=document.createElement('canvas');canvas.width=pix.getWidth();canvas.height=pix.getHeight();
          canvas.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(pix.getPixels()),canvas.width,canvas.height),0,0);
          entry.target.querySelector('.thumbnumber')?.replaceWith(canvas);
        }catch{}finally{pix?.destroy();page?.destroy()}
      },0);
    }
  },{root:$('thumbs'),rootMargin:'80px'});
  $('thumbs').querySelectorAll('[data-page]').forEach(t=>thumbObserver.observe(t));
}
function refresh(){
  document.body.classList.toggle('home-visible',homeVisible);$('homeBtn').setAttribute('aria-pressed',String(homeVisible));
  renderTabs();
  const n=state.doc?.countPages()||0;const active=tabs.find(tab=>tab.id===activeTabId);if(active)active.pageCount=n;
  $('filename').textContent=state.bytes?state.name+(state.dirty?' •':''):'Your PDF workspace';
  $('pagecount').textContent=n?String(n):'';
  $('totalpages').textContent='/ '+n;$('pageinput').value=state.page+1;$('pageinput').max=n;pageToolbar.setPage(state.page+1,n);
  $('memory').textContent=state.bytes?fmt(state.bytes.length)+' · Local processing':'Offline edition';
  $('undo').disabled=homeVisible||!state.undo.length;$('redo').disabled=homeVisible||!state.redo.length;
  $('saveBtn').disabled=homeVisible||!n;$('printBtn').disabled=homeVisible||!n;
  $('prev').disabled=state.page===0;$('next').disabled=state.page>=n-1;
  $('thumbs').innerHTML=n?Array.from({length:n},(_,i)=>`<button class="thumb ${state.page===i?'active':''}" data-page="${i}" aria-label="Go to page ${i+1}" ${state.page===i?'aria-current="page"':''}><span class="thumbnumber">${i+1}</span><span class="thumbtext">Page ${i+1}</span><span class="thumbcompactnum" aria-hidden="true">${i+1}</span></button>`).join(''):'<p class="pages-empty">Open a PDF to preview its pages.</p>';
  $('thumbs').querySelectorAll('button').forEach(button=>button.onclick=guard(()=>go(+button.dataset.page)));
  renderPanel();observeThumbs();
}
async function setPane(open){
  state.paneOpen=!!open;renderPanel();drawOverlays();
  if(state.doc&&state.fit)await render();
}
function toolSelected(key){return(key==='split'&&splitWorkspace?.isOpen)||state.tool===key||(key==='signature'&&state.tool==='signatureImage')}
function deselectTool(){cancelPageDrag();state.tool='select';state.hits=[];state.settingsOpen=false;renderPanel();drawOverlays()}
function renderPanel(){
  const group=state.group;
  const visible=state.paneOpen||state.paneDocked;
  $('workspace').classList.toggle('pane-open',state.paneOpen);
  $('workspace').classList.toggle('pane-docked',state.paneDocked);
  $('toolpane').classList.toggle('settings-open',state.settingsOpen);
  $('toolpane').setAttribute('aria-hidden',String(!visible));
  $('dockTools').setAttribute('aria-pressed',String(state.paneDocked));
  $('dockTools').setAttribute('aria-label',state.paneDocked?'Unpin tools':'Dock tools on right');
  $('dockTools').title=state.paneDocked?'Unpin tools':'Dock tools on right';
  $('toolSettings').setAttribute('aria-expanded',String(state.settingsOpen));
  $('toolSettings').setAttribute('aria-controls','toolsettingsbody');
  $('nav').innerHTML=Object.keys(groups).map(key=>`<button class="${key===group&&visible?'active':''}" data-group="${esc(key)}" aria-label="${esc(key==='Organize'?'Organise':key)}" title="${esc(key==='Organize'?'Organise':key)}" aria-controls="toolpane" aria-expanded="${key===group&&visible}"><span class="nav-icon">${toolIcon(groupIcons[key])}</span><span class="nav-label">${esc(key==='Organize'?'Organise':key)}</span></button>`).join('');
  $('nav').querySelectorAll('button').forEach(button=>button.onclick=guard(async()=>{
    const next=button.dataset.group;
    if(splitWorkspace?.isOpen)await showDocument('Returned to PDF · '+state.name);
    if(homeVisible&&state.doc)await showDocument('Active PDF · '+state.name);
    if(homeVisible){toast('Open a PDF to use document tools.');return}
    state.paneOpen=true;
    state.group=next;state.settingsOpen=false;renderPanel();drawOverlays();
    if(state.doc&&state.fit)await render();
  }));
  const descriptions={View:'Find text and inspect document details.',Organize:'Arrange, combine and resize pages.',Edit:'Add text, images and document details.',Annotate:'Highlight, draw and add comments.',Forms:'Fill fields or create a reusable form.','OCR & compare':'Recognise text and compare documents.','Protect & sign':'Redact, protect and sign your PDF.','Export & batch':'Download files or process a batch.'};
  const textTools=['text','replace','freetext','stamp'],strokeTools=['ink','rectangle','ellipse','line','arrow'];
  const hasFont=textTools.includes(state.tool),hasStroke=strokeTools.includes(state.tool);
  const hasColour=hasFont||hasStroke||['highlight','underline','strikeout','note'].includes(state.tool);
  const hasOptions=hasColour||state.tool==='search';
  const activeLabel=Object.values(tools).flat().find(item=>toolSelected(item[0]))?.[1]||'Tool settings';
  $('toolSettings').title=hasOptions?'Settings for '+activeLabel:'Tool settings';
  $('panel').innerHTML=`<span class="tag">Workspace tools</span><h2>${esc(group==='Organize'?'Organise':group)}</h2><div class="help">${descriptions[group]}</div><div class="toolgrid">${tools[group].map(([key,label])=>`<button data-tool="${key}" class="${toolSelected(key)?'selected':''}" aria-pressed="${toolSelected(key)}" aria-label="${esc(label)}" title="${esc(label)}"><span class="tool-icon">${toolIcon(key)}</span><span class="tool-label">${esc(label)}</span></button>`).join('')}</div>
  <div id="toolsettingsbody" class="tool-settings ${hasFont?'text-settings':''}" ${!hasOptions&&!state.paneDocked?'hidden':''}>
    <div class="settings-heading"><h3 class="settings-title">${esc(hasOptions?activeLabel:'Tool settings')}</h3><button type="button" id="closeToolSettings" class="quiet settings-close" aria-label="Close tool settings" title="Close tool settings">×</button></div>
    <p class="settings-idle" ${hasOptions?'hidden':''}>Select a tool to see its options. Document actions open their own settings.</p>
    <div id="tooloptions" ${state.tool==='search'?'':'hidden'}></div>
    <div class="block" id="fontSetting" ${hasFont?'':'hidden'}><label for="toolFont">Font</label><select id="toolFont">${SYSTEM_FONTS.map(name=>`<option value="${esc(name)}" ${name===state.font?'selected':''}>${esc(name)}</option>`).join('')}</select><div id="fontSample" class="font-sample" aria-label="Selected font preview">Aa Bb Cc · 0123456789</div><p class="font-help">Uses fonts on this device. Unavailable fonts use a sans-serif fallback.</p></div>
    <div class="setting-pair"><div class="block" id="colourSetting" ${hasColour?'':'hidden'}><label for="toolColor">Colour</label><input id="toolColor" type="color" value="${state.color}"></div><div class="block" id="sizeSetting" ${hasFont||hasStroke?'':'hidden'}><label for="toolSize">${hasStroke?'Stroke width (pt)':'Text size (pt)'}</label><input id="toolSize" type="number" min="${hasStroke?1:4}" max="${hasStroke?20:144}" step="${hasStroke?0.5:1}" value="${hasStroke?Math.round(Math.max(1,state.size/7)*10)/10:state.size}"></div></div>
  </div><div class="notice tool-notice"><span>${state.tool==='select'?'Select a function':state.tool==='search'?'Search all pages in this PDF.':state.tool==='directedit'?'Click an outlined text line to edit. Original font, colour and size are retained. Scanned, outlined and older image-backed text is not editable.':state.tool==='ink'?'Draw freely on the page. Release to finish each stroke.':esc(activeLabel)+': drag an area on the page, or click to place.'}</span>${state.tool!=='select'?'<button id="doneTool" class="small">Done</button>':''}</div>${group==='Protect & sign'?'<div class="notice warning" style="margin-top:12px">Apply marked redactions to remove content. Certificate trust and revocation are not checked offline.</div>':''}`;
  $('panel').querySelectorAll('[data-tool]').forEach(button=>button.onclick=guard(()=>activate(button.dataset.tool)));
  $('toolColor').oninput=e=>{state.color=e.target.value;scheduleLocal()};
  $('toolSize').onchange=e=>{state.size=hasStroke?Math.max(7,Math.min(140,(+e.target.value||1)*7)):Math.max(4,Math.min(144,+e.target.value||14));scheduleLocal()};
  if($('doneTool'))$('doneTool').onclick=()=>{deselectTool();scheduleLocal()};
  $('closeToolSettings').onclick=()=>{state.settingsOpen=false;renderPanel();$('toolSettings').focus()};
  $('fontSample').style.fontFamily=systemFontFamily(state.font);
  $('toolFont').onchange=event=>{state.font=event.target.value;$('fontSample').style.fontFamily=systemFontFamily(state.font);scheduleLocal()};
  if(state.tool==='search')showSearch(false);
}
function color(s=state.color){return [parseInt(s.slice(1,3),16)/255,parseInt(s.slice(3,5),16)/255,parseInt(s.slice(5,7),16)/255]}
function pageInfo(index=state.page){const p=state.doc.loadPage(index);const bounds=p.getBounds();const transform=p.getTransform();p.destroy();return{bounds,width:bounds[2]-bounds[0],height:bounds[3]-bounds[1],transform}}
function toPdf(point){const inv=mupdf.Matrix.invert(pageInfo().transform);return[inv[0]*point[0]+inv[2]*point[1]+inv[4],inv[1]*point[0]+inv[3]*point[1]+inv[5]]}
function pdfRect(rect){const pts=[toPdf([rect[0],rect[1]]),toPdf([rect[2],rect[3]])];return{x:Math.min(pts[0][0],pts[1][0]),y:Math.min(pts[0][1],pts[1][1]),width:Math.abs(pts[1][0]-pts[0][0]),height:Math.abs(pts[1][1]-pts[0][1])}}
async function render(){
  directEditor?.close();if(!state.doc)return;const id=++state.renderId,doc=state.doc;
  const ready=await continuousPages.update({doc,bytes:state.bytes,page:state.page,zoom:state.zoom,fit:state.fit,width:$('main').clientWidth,dpr:devicePixelRatio||1,valid:()=>id===state.renderId&&state.doc===doc});
  if(!ready||id!==state.renderId)return;$('zoomlabel').textContent=Math.round(state.zoom*100)+'%';drawOverlays();refreshNavigation();
}
function refreshNavigation(){
  $('pageinput').value=state.page+1;pageToolbar.setPage(state.page+1,state.doc.countPages());
  $('prev').disabled=state.page===0;$('next').disabled=state.page===state.doc.countPages()-1;
  $('thumbs').querySelectorAll('[data-page]').forEach(button=>{
    const active=+button.dataset.page===state.page;button.classList.toggle('active',active);
    if(active){button.setAttribute('aria-current','page');button.scrollIntoView({block:'nearest',inline:'nearest'})}
    else button.removeAttribute('aria-current');
  });
}
function collectAnnotationTargets(overlay,bounds,pageIndex,hits){
  if(state.tool!=='select')return;
  const page=state.doc.loadPage(pageIndex);
  let annotations=[];
  try{
    annotations=page.getAnnotations();
    annotations.forEach((annotation,index)=>{
      let object;
      try{
        const type=annotation.getType(),contents=annotation.getContents()||'';
        if(['Popup','Link','Widget'].includes(type)||(annotation.getFlags()&(1|2|32)))return;
        if(!contents&&!['Text','FreeText','Stamp'].includes(type))return;
        const rect=annotation.getBounds();
        if(!rect.every(Number.isFinite)||rect[2]<=rect[0]||rect[3]<=rect[1])return;
        object=annotation.getObject();
        const record={page:pageIndex,index,type,contents,author:annotation.getAuthor()||'',rect:[...rect],objectId:object.isIndirect()?object.asIndirect():null,revision:state.bytes};
        hits.push(record);
        const badge=document.createElement('button');badge.type='button';badge.className='annotation-badge';badge.textContent='⋯';
        const kind=type==='Stamp'?'stamp':type==='Text'?'sticky note':type==='FreeText'?'text comment':'comment';
        badge.setAttribute('aria-label','View '+kind+(contents?': '+contents.slice(0,100):''));
        badge.title='View '+kind;
        Object.assign(badge.style,{left:Math.max(0,Math.min((rect[2]-bounds[0])*state.zoom-12,overlay.clientWidth-21))+'px',top:Math.max(0,(rect[1]-bounds[1])*state.zoom-10)+'px'});
        badge.onclick=guard(async event=>{event.stopPropagation();await viewAnnotation(record)});
        overlay.append(badge);
      }finally{object?.destroy()}
    });
  }finally{annotations.forEach(annotation=>annotation.destroy());page.destroy()}
}
function collectLinkTargets(overlay,bounds,pageIndex){
  if(!['select','link'].includes(state.tool))return;
  for(const info of inspectLinks(state.doc,pageIndex)){
    const record={...info,revision:state.bytes},label=info.href|| (info.target!==null?'Page '+(info.target+1):'Unavailable link'),node=document.createElement(state.tool==='select'?'a':'span');
    node.className='pdf-link'+(state.tool==='link'?' link-placement-outline':'');
    Object.assign(node.style,{left:(info.rect[0]-bounds[0])*state.zoom+'px',top:(info.rect[1]-bounds[1])*state.zoom+'px',width:(info.rect[2]-info.rect[0])*state.zoom+'px',height:(info.rect[3]-info.rect[1])*state.zoom+'px'});
    node.setAttribute('aria-label',(info.error?'Unavailable link: ':'Open link: ')+label);node.title=info.error||label;
    if(state.tool==='select'){
      if(info.href){node.href=info.href;node.target='_blank';node.rel='noopener noreferrer'}else{node.href='#';if(info.error)node.setAttribute('aria-disabled','true')}
      node.onclick=event=>{if(record.revision!==state.bytes||window.getSelection()?.isCollapsed===false){event.preventDefault();return}if(info.error){event.preventDefault();toast(info.error)}else if(info.target!==null){event.preventDefault();void guard(()=>go(info.target))()}};
    }
    overlay.append(node);
    if(state.tool==='select'){
      const button=document.createElement('button');button.type='button';button.className='pdf-link-badge';button.textContent='↗';button.title='Edit or remove link: '+label;button.setAttribute('aria-label',button.title);
      Object.assign(button.style,{left:Math.max(0,(info.rect[2]-bounds[0])*state.zoom-20)+'px',top:Math.max(0,(info.rect[1]-bounds[1])*state.zoom-10)+'px'});
      button.onclick=guard(async event=>{event.preventDefault();event.stopPropagation();if(record.revision!==state.bytes)return;continuousPages.activate(record.page);const value=await linkSettings(record);if(value)await editMu(value.remove?'Removed link':'Updated link',doc=>writeLink(doc,record.page,record.rect,value.remove?null:value.uri,record))});overlay.append(button);
    }
  }
}
function collectDirectTargets(overlay,bounds,pageIndex){
  if(state.tool!=='directedit')return;
  for(const target of [...directTextTargets(state.doc,pageIndex),...addedTextTargets(state.doc,pageIndex)]){
    const button=document.createElement('button');button.type='button';button.className='direct-text-target';
    button.setAttribute('aria-label','Direct edit: '+target.text.slice(0,160));button.title=target.editable?'Edit '+target.fontName+' · '+Math.round(target.size*100)/100+' pt':'This font encoding or writing direction cannot be edited directly.';
    Object.assign(button.style,{left:(target.rect[0]-bounds[0])*state.zoom+'px',top:(target.rect[1]-bounds[1])*state.zoom+'px',width:Math.max(6,(target.rect[2]-target.rect[0])*state.zoom)+'px',height:Math.max(8,(target.rect[3]-target.rect[1])*state.zoom)+'px'});
    const revision=state.bytes;
    button.onclick=guard(event=>{
      event.stopPropagation();if(revision!==state.bytes||state.tool!=='directedit')return;
      directEditor?.close();if(!target.editable){toast(button.title);return}
      continuousPages.activate(pageIndex);state.page=pageIndex;
      directEditor=openDirectEditor({overlay:$('overlay'),target,bounds,zoom:state.zoom,fontData:target.kind==='added'?null:directFontData(state.doc,pageIndex,target),onClose:()=>{directEditor=null},apply:async value=>{
        if(documentTransitions||state.abort)throw Error('Finish the current operation first.');pendingActions++;try{
        if(revision!==state.bytes||state.page!==pageIndex||state.tool!=='directedit')throw Error('The document changed. Select the text again.');
        if(value===target.text)return true;
        if(!await signedMutation())return false;
        await job('Direct edit',async()=>{
          if(target.kind==='added'){
            const doc=await PDFDocument.load(state.bytes,{updateMetadata:false}),page=doc.getPage(pageIndex),s=target.style;
            const appearance=value.trim()?await renderSystemText(value,{font:s.font,size:s.size,color:s.color,width:s.width,height:s.height,kind:s.kind,shrink:false}):null;
            if(!removeSystemTextBoxes(doc,page,target.source,{resource:target.resource}))throw Error('This text box changed. Select it again.');
            if(appearance)await drawSystemText(doc,page,appearance,s);
            const cleaned=Engine.openPDF(await doc.save({useObjectStreams:false}));try{await setBytes(saveDirectEdit(cleaned),{label:'Direct edit applied'})}finally{cleaned.destroy()}
          }else{
            const doc=Engine.openPDF(state.bytes);try{replaceDirectText(doc,pageIndex,target,value);await setBytes(saveDirectEdit(doc),{label:'Direct edit applied'})}finally{doc.destroy()}
          }
        });return true;
        }finally{pendingActions--;if(!pendingActions)scheduleLocal()}
      }});
    });overlay.append(button);
  }
}
async function linkSettings(record=null){
  let remove=false;const internal=record?.target!==null&&record?.target!==undefined;
  return modal(record?'Edit link':'Add link',`<label for="linkType">Destination</label><select id="linkType"><option value="web" ${internal?'':'selected'}>Website or email</option><option value="page" ${internal?'selected':''}>Page in this PDF</option></select><div id="linkWeb"><label for="answer">Website URL or email address</label><input id="answer" value="${esc(record?.href||(!internal&&record?.uri)||'https://')}" spellcheck="false"><p class="help">For example https://example.com or name@example.com.</p></div><div id="linkInternal"><label for="linkPage">Page number</label><input id="linkPage" type="number" min="1" max="${state.doc.countPages()}" value="${internal?record.target+1:Math.min(state.page+2,state.doc.countPages())}"></div><p class="help">The selected area becomes the link. Choose Done after placing links to follow them.</p>${record?'<button id="removePdfLink" type="button" class="danger small">Remove link</button>':''}`,{
    ok:record?'Save link':'Add link',setup:()=>{const toggle=()=>{$('linkWeb').hidden=$('linkType').value==='page';$('linkInternal').hidden=!$('linkWeb').hidden};$('linkType').onchange=toggle;toggle();if(record)$('removePdfLink').onclick=()=>{remove=true;$('modalform').noValidate=true;$('modalform').requestSubmit()}},
    read:()=>remove?{remove:true}:{uri:$('linkType').value==='page'?pageLink($('linkPage').value,state.doc.countPages()):webLink($('answer').value)}
  });
}
async function viewAnnotation(record){
  if(record.revision!==state.bytes)return;if(record.page!==state.page){if(!continuousPages.activate(record.page))return;continuousPages.scrollToPage(record.page)}
  const title=record.type==='Stamp'?'Stamp':record.type==='Text'?'Sticky note':record.type==='FreeText'?'Text comment':'Comment';
  await modal(title,`<div class="comment-meta">Page ${record.page+1}${record.author?' · '+esc(record.author):''}</div><div class="comment-body">${esc(record.contents||'This annotation has no text comment.')}</div>`,{ok:null});
}
function drawOverlays(){directEditor?.close();if(drag)cancelPageDrag();commentPress=null;annotationHits=state.doc?continuousPages.redrawLayers():[]}
function drawPageOverlays(pageIndex,overlay){const hits=[];overlay.innerHTML='';if(!state.doc)return hits;const b=pageInfo(pageIndex).bounds;const add=(rect,cls)=>{const d=document.createElement('div');d.className=cls;Object.assign(d.style,{left:(rect[0]-b[0])*state.zoom+'px',top:(rect[1]-b[1])*state.zoom+'px',width:(rect[2]-rect[0])*state.zoom+'px',height:(rect[3]-rect[1])*state.zoom+'px'});overlay.append(d)};state.marks.filter(r=>r.page===pageIndex).forEach(r=>add(r.rect,'redactmark'));state.hits.filter(r=>r.page===pageIndex).forEach(r=>add(r.rect,'hit'));overlay.style.cursor=['select','directedit'].includes(state.tool)?'default':'crosshair';overlay.style.touchAction=['select','search','directedit'].includes(state.tool)?'pan-x pan-y':'none';if(state.tool==='select'){const p=state.doc.loadPage(pageIndex),st=p.toStructuredText('');try{const data=JSON.parse(st.asJSON());const measure=document.createElement('canvas').getContext('2d');for(const block of data.blocks||[]){if(block.type!=='text')continue;for(const line of block.lines||[]){if(!line.text||!line.bbox||line.wmode)continue;const span=document.createElement('span');span.className='textline';span.textContent=line.text;const box=line.bbox,size=(line.font?.size||box.h*.8)*state.zoom;measure.font=size+'px Arial';const width=measure.measureText(line.text).width;Object.assign(span.style,{left:(box.x-b[0])*state.zoom+'px',top:(box.y-b[1])*state.zoom+'px',fontSize:size+'px',fontFamily:'Arial',height:box.h*state.zoom+'px',transform:'scaleX('+(width?box.w*state.zoom/width:1)+')'});overlay.append(span)}}}finally{st.destroy();p.destroy()}}
  collectDirectTargets(overlay,b,pageIndex);collectLinkTargets(overlay,b,pageIndex);collectAnnotationTargets(overlay,b,pageIndex,hits);return hits;
}
async function go(i){need();cancelPageDrag();state.page=Math.max(0,Math.min(state.doc.countPages()-1,i));await render();continuousPages.scrollToPage(state.page);scheduleLocal()}
async function signedMutation(){need();if(state.marks?.length&&arguments[0]!==true)throw Error('Apply or clear pending redaction marks before changing this PDF. Save workspace to keep them for later.');if(!window.PdfProSigning)throw Error('Certificate inspection is unavailable. Reload pdfpro before editing this document.');const sigs=await window.PdfProSigning.inspectSignatures(state.bytes);if(sigs.length){return confirm('This PDF contains signatures','Editing rewrites the document and invalidates existing certificate signatures. Continue with an edited copy?','Edit copy')}return true}
async function editPDF(label,fn){need();if(!await signedMutation())return;await job(label,async()=>{const doc=await PDFDocument.load(state.bytes,{updateMetadata:false});await fn(doc);await setBytes(await doc.save({useObjectStreams:false}),{label})})}
async function editMu(label,fn){need();if(!await signedMutation())return;await job(label,async()=>{const d=Engine.openPDF(state.bytes);try{await fn(d);const buffer=d.saveToBuffer('garbage=4,compress');let bytes;try{bytes=buffer.asUint8Array().slice()}finally{buffer.destroy()}await setBytes(bytes,{label})}finally{d.destroy()}})}
function requireDocumentTransition(){if(pendingActions>1||documentTransitions||state.abort||$('modalroot').firstChild||drag)throw Error('Finish the current operation before opening another PDF.')}
async function openFiles(files){
  if(!files?.length)return;
  requireDocumentTransition();documentTransitions++;
  const errors=[],images=[];let opened=0;
  try{
    for(const file of files){
      if(/\.(png|jpe?g)$/i.test(file.name)||/^image\/(png|jpeg)$/.test(file.type||'')){images.push(file);continue}
      if(!/\.pdf$/i.test(file.name)&&!(file.type||'').includes('pdf')){errors.push(file.name+': choose a PDF, PNG or JPEG file');continue}
      try{
        let bytes=new Uint8Array(await file.arrayBuffer()),doc;
        try{doc=Engine.openPDF(bytes)}catch(err){
          if(!/password|authenticate|encrypted/i.test(err.message))throw err;
          const value=await modal('Unlock '+file.name,'<p>Enter the document password. Passwords stay on this device.</p><label for="pw">Password</label><input id="pw" name="password" type="password" required>');
          if(!value)continue;
          bytes=Engine.decryptPDF(bytes,value.password);doc=Engine.openPDF(bytes);
          toast('Opened an unlocked working copy. Use Encrypt PDF to protect an export.');
        }
        doc.destroy();await addDocument(bytes,{name:file.name});opened++;
      }catch(err){errors.push(file.name+': '+err.message)}
    }
    // Images selected together become one new PDF tab; PDFs each get their own tab.
    if(images.length)try{
      await job('Creating PDF from images',async()=>{
        const doc=await PDFDocument.create();
        for(const image of images){
          const bytes=new Uint8Array(await image.arrayBuffer());
          const im=image.type==='image/png'||/\.png$/i.test(image.name)?await doc.embedPng(bytes):await doc.embedJpg(bytes);
          const scale=Math.min(1,1600/Math.max(im.width,im.height));
          doc.addPage([im.width*scale,im.height*scale]).drawImage(im,{x:0,y:0,width:im.width*scale,height:im.height*scale});
        }
        await addDocument(await doc.save(),{name:images[0].name.replace(/\.[^.]+$/,'')+'.pdf',dirty:true,label:'Created PDF from '+images.length+' image(s)'});opened++;
      });
    }catch(err){errors.push('Images: '+err.message)}
    if(errors.length)await modal('Some files could not be opened',`<p>${opened} new PDF tab(s) opened.</p><pre>${esc(errors.join('\n'))}</pre>`,{ok:null});
    else if(opened>1)toast(opened+' PDFs opened in separate tabs.');
  }finally{documentTransitions--}
}
async function newDocument(){requireDocumentTransition();documentTransitions++;try{const doc=await PDFDocument.create();doc.addPage([595,842]);return await addDocument(await doc.save(),{name:'Untitled.pdf',dirty:true,label:'Created blank PDF'})}finally{documentTransitions--}}
async function createDemo(){requireDocumentTransition();documentTransitions++;try{const d=await PDFDocument.create();const font=await d.embedFont(StandardFonts.Helvetica),bold=await d.embedFont(StandardFonts.HelveticaBold);const p=d.addPage([595,842]);const brandColour=rgb(.502,0,.125);p.drawRectangle({x:0,y:640,width:595,height:202,color:rgb(.97,.94,.95)});p.drawText('pdfpro',{x:48,y:774,size:22,font:bold,color:brandColour});p.drawText('A little less paperwork.',{x:48,y:711,size:29,font:bold,color:rgb(.063,.114,.227)});p.drawText('A little more possibility.',{x:48,y:674,size:29,font:bold,color:rgb(.063,.114,.227)});const lines=['Welcome to your offline PDF workspace.','Everything you do here stays on your device.','','Try these tools:','01  Add a comment or highlight this paragraph.','02  Rotate, duplicate, or reorder a page.','03  Fill in the sample form below.','04  Add a signature, run OCR, or encrypt an export.','','CONFIDENTIAL SAMPLE: secret-4279','Use Mark redaction, drag over this line, then Apply redactions.'];lines.forEach((t,i)=>p.drawText(t,{x:48,y:593-i*25,size:i===3?15:12,font:i===3?bold:font,color:rgb(0,0,0)}));const f=d.getForm().createTextField('Your name');f.addToPage(p,{x:48,y:205,width:315,height:30,font});p.drawText('Your name',{x:48,y:245,size:11,font:bold,color:brandColour});const c=d.getForm().createCheckBox('Reviewed');c.addToPage(p,{x:48,y:165,width:16,height:16});p.drawText('I have reviewed this sample',{x:75,y:169,size:11,font,color:rgb(0,0,0)});p.drawText('01  /  PDFPRO SAMPLE',{x:48,y:50,size:9,font,color:brandColour});const p2=d.addPage([595,842]);p2.drawText('Room for your next idea.',{x:48,y:744,size:27,font:bold,color:brandColour});p2.drawText('Add an image, text, a watermark, or a visual signature here.',{x:48,y:700,size:12,font});const bytes=await d.save({useObjectStreams:false});await addDocument(bytes,{name:'pdfpro-sample.pdf',label:'Sample document · Try any tool'})}finally{documentTransitions--}}

async function activate(tool){directEditor?.close();cancelPageDrag();if(splitWorkspace?.isOpen){await showDocument('Returned to PDF · '+state.name);if(tool==='split')return}if(tool==='restore'){if(state.doc)deselectTool();await restoreWorkspace();return}need();if(toolSelected(tool)){deselectTool();return}const actions={clearmarks:async()=>{state.marks=[];renderTabs();drawOverlays();status('Pending redaction marks cleared');await persistLocal()},save:save,rotate:()=>rotate(),duplicate:duplicate,moveup:()=>move(-1),movedown:()=>move(1),delete:deletePage,blank:blankPage,merge:merge,extract:extract,split:split,reorder:reorder,resize:resize,watermark:()=>decorate('watermark'),number:()=>decorate('number'),bates:()=>decorate('bates'),header:()=>decorate('header'),metadata:metadata,bookmarks:bookmarks,attachments:attachments,comments:comments,fill:fillForm,flatten:flattenForm,formexport:exportForm,formimport:importForm,ocr:runOCR,compare:compare,textExport:exportText,optimize:optimize,applyredact:applyRedactions,sanitize:sanitize,encrypt:encrypt,signature:visualSignature,certsign:certificateSign,verify:verifySignatures,png:()=>exportImage('png'),jpeg:()=>exportImage('jpeg'),allimages:allImages,project:saveWorkspace,batch:batch,print:print};if(actions[tool]){deselectTool();await actions[tool]();return}state.tool=tool;if(state.paneDocked)state.settingsOpen=['search','text','replace','freetext','stamp','highlight','underline','strikeout','note','ink','rectangle','ellipse','line','arrow'].includes(tool);if(tool!=='search'&&matchMedia('(max-width:900px)').matches)state.paneOpen=false;renderPanel();drawOverlays();if(tool==='search')showSearch();if(tool==='image'){const f=await choose('image/png,image/jpeg');if(!f){deselectTool();return}state.selectedImage={bytes:new Uint8Array(await f.arrayBuffer()),type:f.type};toast('Drag an area on the page to place your image.')}else if(tool==='directedit'){toast('Click an outlined text line to edit it in place. The original PDF font, colour and size are retained. Scanned, outlined and older image-backed text cannot be directly edited.')}else if(tool==='link'){toast('Drag over the text or area to link. Choose Done when finished to follow links.')}else if(tool==='ink'){toast('Press and drag to draw freely. Release to finish each stroke.')}else if(tool==='replace'){toast('Drag tightly around a text line to replace it. Existing glyphs will be removed.')}else toast('Drag on the page to use '+(tools[state.group].find(t=>t[0]===tool)?.[1]||tool))}
function showSearch(focus=true){
  const box=$('tooloptions');
  box.innerHTML='<label class="help" for="searchquery">Search all pages</label><div class="searchbar"><input id="searchquery" placeholder="Find in document" value="'+esc(state.searchQuery)+'"><button id="dosearch" class="small">Find</button></div><div class="results" id="results"></div>';
  $('dosearch').onclick=guard(search);$('searchquery').oninput=event=>{state.searchQuery=event.target.value;scheduleLocal()};
  $('searchquery').onkeydown=event=>{if(event.key==='Enter')guard(search)()};
  showSearchResults();if(focus)$('searchquery').focus();
}
function showSearchResults(){
  const results=$('results');if(!results)return;
  results.innerHTML=state.hits.length?state.hits.slice(0,200).map((hit,index)=>`<button data-hit="${index}">Page ${hit.page+1} · ${esc(state.searchQuery.trim())}</button>`).join(''):(state.searchQuery?'<span class="help">No matches. Scans may need OCR.</span>':'');
  results.querySelectorAll('button').forEach(button=>button.onclick=guard(()=>go(state.hits[+button.dataset.hit].page)));
}
async function search(){const q=$('searchquery').value.trim();if(!q)return;state.searchQuery=q;state.hits=[];await job('Searching document',async(progress,signal)=>{for(let i=0;i<state.doc.countPages();i++){if(signal.aborted)throw new DOMException('Cancelled','AbortError');const p=state.doc.loadPage(i);const matches=p.search(q);matches.forEach(quads=>quads.forEach(quad=>{state.hits.push({page:i,rect:[Math.min(quad[0],quad[2],quad[4],quad[6]),Math.min(quad[1],quad[3],quad[5],quad[7]),Math.max(quad[0],quad[2],quad[4],quad[6]),Math.max(quad[1],quad[3],quad[5],quad[7])]})}));p.destroy();progress((i+1)/state.doc.countPages());await delay()}});showSearchResults();if(state.hits.length)await go(state.hits[0].page);else drawOverlays()}
async function save(){need();if(state.marks.length&&!await confirm('Pending redactions','Pending redaction marks have not removed any content. Save the current PDF without applying them?','Save current PDF'))return;download(state.bytes,outname('-edited'));state.dirty=false;refresh();status('PDF downloaded · '+fmt(state.bytes.length))}
async function undo(){if(state.marks.length)throw Error('Apply or clear pending redaction marks before undoing edits');if(!state.undo.length)return;const v=state.undo.pop();state.redo.push({bytes:state.bytes,page:state.page});state.page=v.page;await setBytes(v.bytes,{record:false,label:'Undo'})}
async function redo(){if(state.marks.length)throw Error('Apply or clear pending redaction marks before redoing edits');if(!state.redo.length)return;const v=state.redo.pop();state.undo.push({bytes:state.bytes,page:state.page});state.page=v.page;await setBytes(v.bytes,{record:false,label:'Redo'})}
async function rotate(){await editPDF('Rotated page',d=>{const p=d.getPage(state.page);p.setRotation(degrees((p.getRotation().angle+90)%360))})}
function hasFormWidgets(doc,indices=doc.getPageIndices()){return indices.some(index=>doc.getPage(index).node.Annots()?.asArray().some(ref=>doc.context.lookup(ref)?.get?.(PDFName.of('Subtype'))?.toString()==='/Widget'))}
async function duplicate(){await editPDF('Duplicated page',async d=>{if(hasFormWidgets(d,[state.page]))throw Error('This page contains form fields. Use Flatten form before duplicating it.');const [p]=await d.copyPages(d,[state.page]);d.insertPage(state.page+1,p);state.page++})}
async function move(dir){const next=state.page+dir;if(next<0||next>=state.doc.countPages())return;await editPDF('Moved page',d=>{const p=d.getPage(state.page);d.removePage(state.page);d.insertPage(next,p);state.page=next})}
async function deletePage(){if(state.doc.countPages()===1)throw Error('A PDF must retain at least one page');if(!await confirm('Delete page '+(state.page+1)+'?','The page will be removed from the working copy. You can undo this change.','Delete page'))return;await editPDF('Deleted page',d=>d.removePage(state.page))}
async function blankPage(){await editPDF('Inserted blank page',d=>{const p=d.getPage(state.page);d.insertPage(state.page+1,p.getSize().width?[p.getWidth(),p.getHeight()]:[595,842]);state.page++})}
async function merge(){const files=await choose('application/pdf',true);if(!files.length)return;await editPDF('Merged '+files.length+' PDF(s)',async d=>{for(const f of files){const bytes=new Uint8Array(await f.arrayBuffer());if((await window.PdfProSigning.inspectSignatures(bytes)).length)throw Error('Merge source contains certificate signatures. Use an unsigned copy.');const src=await PDFDocument.load(bytes,{updateMetadata:false});if(hasFormWidgets(src))throw Error('Merge source '+f.name+' contains form fields. Open it and use Flatten form before merging.');const pages=await d.copyPages(src,src.getPageIndices());pages.forEach(p=>d.addPage(p))}})}
async function extract(){if(!await signedMutation())return;const value=await ask('Extract pages','Pages or ranges',String(state.page+1));if(!value)return;const pages=parsePages(value);await job('Extracting pages',async()=>{const src=await PDFDocument.load(state.bytes);if(hasFormWidgets(src,pages))throw Error('Selected pages contain form fields. Use Flatten form before extracting them.');const d=await PDFDocument.create();(await d.copyPages(src,pages)).forEach(p=>d.addPage(p));download(await d.save(),outname('-pages'))})}
async function split(){
  need();rememberDocument();cancelPageDrag();state.paneOpen=false;state.settingsOpen=false;pageToolbar.openMenu(false);renderPanel();
  $('viewer').classList.add('hidden');$('welcome').classList.add('hidden');$('main').scrollTop=0;$('main').scrollLeft=0;
  await splitWorkspace.open({ownerId:activeTabId,plan:state.splitPlan});renderPanel();
}
async function listSplitSources(){
  rememberDocument();let rows=[];try{rows=await localStore.listDocuments()}catch{}
  const catalogue=new Map(rows.map(row=>[row.id,{id:row.id,name:row.name,pageCount:row.pageCount,open:false}]));
  for(const tab of tabs)catalogue.set(tab.id,{id:tab.id,name:tab.snapshot.name,pageCount:tab.pageCount,open:true});
  return[...catalogue.values()].sort((a,b)=>(b.id===activeTabId)-(a.id===activeTabId)||Number(b.open)-Number(a.open));
}
async function readSplitSource(id){
  rememberDocument();const tab=tabs.find(tab=>tab.id===id),source=tab?.snapshot||(await localStore.getDocument(id))?.snapshot;
  if(!(source?.bytes instanceof Uint8Array))throw Error('The source PDF is unavailable.');
  const doc=Engine.openPDF(source.bytes);try{return{id,name:source.name,bytes:source.bytes,pageCount:doc.countPages(),marks:source.marks||[]}}finally{doc.destroy()}
}
async function importSplitFiles(files){
  requireDocumentTransition();documentTransitions++;const ids=[],errors=[];
  try{
    for(const file of files){
      if(!/\.pdf$/i.test(file.name)&&!String(file.type||'').includes('pdf')){errors.push(file.name+': choose a PDF file');continue}
      try{
        let bytes=new Uint8Array(await file.arrayBuffer()),doc;
        try{doc=Engine.openPDF(bytes)}catch(error){
          if(!/password|authenticate|encrypted/i.test(error.message))throw error;
          const value=await modal('Unlock '+file.name,'<label for="splitpw">Password</label><input id="splitpw" name="password" type="password" required autocomplete="off">');
          if(!value)continue;bytes=Engine.decryptPDF(bytes,value.password);doc=Engine.openPDF(bytes);toast('Added an unlocked working copy. Encrypt an export to protect it.');
        }
        let count;try{count=doc.countPages();if(!count)throw Error('This PDF has no pages.')}finally{doc.destroy()}
        const id=globalThis.crypto?.randomUUID?.()||'pdf-'+Date.now().toString(36)+'-'+nextTabId++;
        tabs.push({id,pageCount:count,snapshot:{...emptyDocument(),bytes,original:bytes.slice(),name:file.name}});ids.push(id);
      }catch(error){errors.push(file.name+': '+error.message)}
    }
    renderTabs();await persistLocal();return{ids,errors};
  }finally{documentTransitions--}
}
async function ensureSplitSourcesSafe(sources){
  const pending=sources.filter(source=>source.marks.length);if(pending.length)throw Error('Apply or clear pending redactions in '+pending.map(source=>source.name).join(', ')+' before export.');
  const signed=[];for(const source of sources)if((await window.PdfProSigning.inspectSignatures(source.bytes)).length)signed.push(source.name);
  if(signed.length&&!await confirm('Signed source PDFs','Export creates new copies and invalidates original certificate signatures in those copies: '+signed.join(', '),'Create exported copies'))throw new DOMException('Cancelled','AbortError');
}

async function reorder(){const value=await ask('Reorder pages','New page order (every page exactly once)',Array.from({length:state.doc.countPages()},(_,i)=>i+1).join(','));if(!value)return;const pages=parsePages(value);if(pages.length!==state.doc.countPages()||new Set(pages).size!==pages.length)throw Error('Include each page exactly once. Use Extract for a subset.');await editMu('Reordered pages',d=>d.rearrangePages(pages));await go(0)}
async function resize(){const v=await modal('Resize page','<p>Scales page dimensions and contents. Measurements are PDF points (72 per inch).</p><div class="flex"><div><label>Width</label><input type="number" name="width" min="72" max="14400" value="595" required></div><div><label>Height</label><input type="number" name="height" min="72" max="14400" value="842" required></div></div>');if(!v)return;await editPDF('Resized page',d=>{const p=d.getPage(state.page),rotation=((p.getRotation().angle%360)+360)%360,swap=rotation===90||rotation===270,crop=p.getCropBox(),sx=(swap?+v.height:+v.width)/crop.width,sy=(swap?+v.width:+v.height)/crop.height;const boxes=['Media','Crop','Bleed','Trim','Art'].map(name=>[name,p['get'+name+'Box']()]);p.scale(sx,sy);scaleSystemTextBoxes(d,p,sx,sy);boxes.forEach(([name,b])=>p['set'+name+'Box'](b.x*sx,b.y*sy,b.width*sx,b.height*sy))})}
async function drawDecorationText(doc,page,text,{size=10,x=36,baseline=22,opacity=1,rotation=0,font=state.font,textColor=state.color}={}){
  if(!text)return;
  const natural=measureSystemText(text,{font,size});
  const width=Math.max(12,Math.min(page.getWidth()-72,natural+14)),height=size*2.1+8;
  const appearance=await renderSystemText(text,{font,size,width,height,color:textColor});
  const y=baseline-(appearance.height-appearance.lines[0].y);
  await drawSystemText(doc,page,appearance,{x,y,opacity,rotation,track:false});
}
function fontChoice(){return '<label for="dialogFont">Font</label><select id="dialogFont" name="font">'+SYSTEM_FONTS.map(name=>'<option value="'+esc(name)+'" '+(name===state.font?'selected':'')+'>'+esc(name)+'</option>').join('')+'</select>'}
function decorationChoices(){return fontChoice()+'<label for="dialogColour">Colour</label><input id="dialogColour" name="textColour" type="color" value="'+state.color+'">'}
async function decorate(kind){
  let html='';
  if(kind==='watermark')html='<label>Watermark text</label><input name="text" value="CONFIDENTIAL" required><label>Opacity (0.05–1)</label><input name="opacity" type="number" min="0.05" max="1" step="0.05" value="0.15">';
  if(kind==='number')html='<label>Prefix</label><input name="prefix" value="Page "><label>Start number</label><input name="start" type="number" value="1">';
  if(kind==='bates')html='<label>Prefix</label><input name="prefix" value="DOC-"><label>Start number</label><input name="start" type="number" min="0" value="1"><label>Digits</label><input name="digits" type="number" min="1" max="12" value="6">';
  if(kind==='header')html='<label>Header</label><input name="header" value=""><label>Footer</label><input name="footer" value="">';
  html+=decorationChoices()+'<label>Page range</label><input name="pages" value="1-'+state.doc.countPages()+'" required>';
  const value=await modal({watermark:'Add watermark',number:'Add page numbers',bates:'Add Bates numbers',header:'Add header and footer'}[kind],html);if(!value)return;
  state.font=value.font;state.color=value.textColour;scheduleLocal();
  const indices=parsePages(value.pages);
  await editPDF('Added '+kind,async doc=>{
    for(const [i,index]of indices.entries()){
      const page=doc.getPage(index),width=page.getWidth(),height=page.getHeight();
      const draw=(text,size,x,baseline,options={})=>drawDecorationText(doc,page,text,{size,x,baseline,...options});
      if(kind==='watermark'){
        const natural=measureSystemText(value.text,{font:state.font,size:60});
        const size=Math.max(4,Math.min(60,60*(width-90)/Math.max(1,natural)));
        await draw(value.text,size,35,height*.48,{opacity:+value.opacity,rotation:28});
      }else if(kind==='header'){
        await draw(value.header,10,36,height-30);await draw(value.footer,10,36,24);
      }else{
        const text=value.prefix+String((+value.start||0)+i).padStart(kind==='bates'?+value.digits:1,'0');
        await draw(text,10,36,22);
      }
    }
  });
}
async function metadata(){const d=await PDFDocument.load(state.bytes,{updateMetadata:false});const v=await modal('Document properties',`<p>${state.doc.countPages()} pages · ${fmt(state.bytes.length)} · PDF version ${esc(state.doc.getVersion?.()/10||'')}</p><label>Title</label><input name="title" value="${esc(d.getTitle()||'')}"><label>Author</label><input name="author" value="${esc(d.getAuthor()||'')}"><label>Subject</label><input name="subject" value="${esc(d.getSubject()||'')}"><label>Keywords (comma separated)</label><input name="keywords" value="${esc(d.getKeywords()||'')}">`);if(!v)return;await editPDF('Updated metadata',d=>{d.setTitle(v.title);d.setAuthor(v.author);d.setSubject(v.subject);d.setKeywords(v.keywords.split(',').map(s=>s.trim()));d.catalog.delete(PDFName.of('Metadata'))})}
async function bookmarks(){const list=state.doc.loadOutline?.()||[];const flatten=(a,level=0)=>a.flatMap(x=>[{title:x.title,page:x.page,level},...flatten(x.down||[],level+1)]);const items=flatten(list);const v=await modal('Bookmarks',`<p>Existing outline entries are shown below. Adding creates a document-level bookmark to the current page.</p>${items.length?'<table>'+items.map(x=>`<tr><td>${'&nbsp;'.repeat(x.level*3)}${esc(x.title)}</td><td>${Number.isInteger(x.page)?`<button class="small" type="button" data-bookmark="${x.page}">Page ${x.page+1}</button>`:'Link'}</td></tr>`).join('')+'</table>':'<p>No bookmarks yet.</p>'}<label>New bookmark title</label><input name="title" placeholder="Bookmark page ${state.page+1}" required>`,{ok:'Add bookmark',setup:()=>{$('modalform').querySelectorAll('[data-bookmark]').forEach(b=>b.onclick=guard(async()=>{$('modalcancel').click();await go(+b.dataset.bookmark)}))}});if(!v)return;await editPDF('Added bookmark',d=>{const ctx=d.context,root=d.catalog;let outlines=root.lookupMaybe(PDFName.of('Outlines'),PDFDict);let ref=root.get(PDFName.of('Outlines'));if(!outlines){outlines=ctx.obj({Type:'Outlines',Count:0});ref=ctx.register(outlines);root.set(PDFName.of('Outlines'),ref)}const item=ctx.obj({Title:PDFLib.PDFHexString.fromText(v.title),Parent:ref,Dest:[d.getPage(state.page).ref,'Fit']});const ir=ctx.register(item),last=outlines.get(PDFName.of('Last'));if(last){item.set(PDFName.of('Prev'),last);ctx.lookup(last,PDFDict).set(PDFName.of('Next'),ir)}else outlines.set(PDFName.of('First'),ir);outlines.set(PDFName.of('Last'),ir);outlines.set(PDFName.of('Count'),ctx.obj((outlines.lookupMaybe(PDFName.of('Count'),PDFLib.PDFNumber)?.asNumber()||0)+1))})}
async function attachments(){const files=state.doc.getEmbeddedFiles?.()||{};const entries=Object.entries(files);const v=await modal('Document attachments',`<p>Attachments are never opened automatically.</p>${entries.length?entries.map(([name],i)=>`<button type="button" class="full" id="att${i}">Download ${esc(name)}</button>`).join(''):'<p>No embedded files.</p>'}<label>Add attachment</label><input id="newattachment" type="file">`,{ok:'Attach file',setup:()=>{entries.forEach(([name,ref],i)=>$('att'+i).onclick=guard(()=>{const buf=state.doc.getEmbeddedFileContents(ref);download(buf.asUint8Array().slice(),name,'application/octet-stream');buf.destroy()}))},read:()=>{const f=$('newattachment').files[0];if(!f)throw Error('Choose a file to attach');return f}});if(!v)return;await editPDF('Attached '+v.name,async d=>d.attach(await v.arrayBuffer(),v.name,{mimeType:v.type||'application/octet-stream'}))}

async function comments(){const p=state.doc.loadPage(state.page);const a=p.getAnnotations();const rows=a.map((x,i)=>({i,type:x.getType(),text:x.getContents()||''}));const v=await modal('Comments on page '+(state.page+1),rows.length?'<table><tr><th>Type</th><th>Comment</th><th>Remove</th></tr>'+rows.map(x=>`<tr><td>${esc(x.type)}</td><td>${esc(x.text)}</td><td><input aria-label="Remove comment ${x.i+1}" type="checkbox" name="remove" value="${x.i}"></td></tr>`).join('')+'</table>':'<p>No comments on this page.</p>',{ok:rows.length?'Remove selected':null,read:()=>[...$('modalform').querySelectorAll('[name=remove]:checked')].map(x=>+x.value)});a.forEach(x=>x.destroy());p.destroy();if(!v?.length)return;await editMu('Removed comments',d=>{const page=d.loadPage(state.page);const a=[...page.getAnnotations()];v.forEach(i=>page.deleteAnnotation(a[i]));a.forEach(x=>x.destroy());page.destroy()})}
async function fillForm(){const d=await PDFDocument.load(state.bytes,{updateMetadata:false}),form=d.getForm();if(form.hasXFA())throw Error('Dynamic XFA forms are unsupported. Use a standard AcroForm PDF.');const fields=form.getFields().filter(f=>!(f instanceof PDFLib.PDFSignature));if(!fields.length){toast('No supported form fields. Use the field tools to create some.');return}const html=fields.map((f,i)=>{const label=esc(f.getName());if(f instanceof PDFLib.PDFCheckBox)return`<div class="formrow"><label><input type="checkbox" id="fld${i}" ${f.isChecked()?'checked':''}>${label}</label></div>`;if(f instanceof PDFLib.PDFDropdown||f instanceof PDFLib.PDFOptionList||f instanceof PDFLib.PDFRadioGroup){const sel=f.getSelected();return`<label for="fld${i}">${label}</label><select id="fld${i}"><option value="">—</option>${f.getOptions().map(o=>`<option ${Array.isArray(sel)?sel.includes(o)?'selected':'':sel===o?'selected':''} value="${esc(o)}">${esc(o)}</option>`).join('')}</select>`}if(f instanceof PDFLib.PDFTextField)return`<label for="fld${i}">${label}</label><input id="fld${i}" value="${esc(f.getText()||'')}">`;return`<p>${label}: unsupported field type</p>`}).join('');const values=await modal('Fill form',html,{read:()=>fields.map((f,i)=>({name:f.getName(),value:$('fld'+i)?.type==='checkbox'?$('fld'+i).checked:$('fld'+i)?.value}))});if(!values)return;await editPDF('Saved form values',d=>{const f=d.getForm();for(const v of values){if(v.value===undefined)continue;const field=f.getField(v.name);if(field instanceof PDFLib.PDFCheckBox)v.value?field.check():field.uncheck();else if(field instanceof PDFLib.PDFTextField)field.setText(v.value);else if(v.value)field.select(v.value);else if(field.clear)field.clear()}f.updateFieldAppearances()})}
async function flattenForm(){if(!await confirm('Flatten form?','Values will become page content and fields will stop being editable. You can undo in this session.','Flatten form'))return;await editMu('Flattened form',d=>d.bake(false,true))}
async function exportForm(){const d=await PDFDocument.load(state.bytes),values={};d.getForm().getFields().forEach(f=>values[f.getName()]=f instanceof PDFLib.PDFCheckBox?f.isChecked():f instanceof PDFLib.PDFTextField?f.getText():f.getSelected?.()??null);download(JSON.stringify(values,null,2),outname('-form','json'),'application/json')}
async function importForm(){const f=await choose('.json,application/json');if(!f)return;const v=JSON.parse(await f.text());await editPDF('Imported form values',d=>{for(const[name,value]of Object.entries(v)){const field=d.getForm().getFieldMaybe(name);if(!field)continue;if(field instanceof PDFLib.PDFCheckBox)value?field.check():field.uncheck();else if(field instanceof PDFLib.PDFTextField)field.setText(String(value??''));else if(value!==null)field.select(value)}})}

let drag=null;
function onPageEvent(type,handler){$('viewer').addEventListener(type,event=>{if(event.composedPath().some(node=>node?.classList?.contains('pdf-page-overlay')||node?.id==='overlay'))return handler(event)})}
function eventPoint(e){const r=$('overlay').getBoundingClientRect(),b=pageInfo().bounds;return[(e.clientX-r.left)/state.zoom+b[0],(e.clientY-r.top)/state.zoom+b[1]]}
onPageEvent('pointerdown',event=>{
  if(state.doc&&state.tool==='select'&&!event.target.closest('.annotation-badge,.pdf-link,.pdf-link-badge'))commentPress={x:event.clientX,y:event.clientY,page:state.page,revision:state.bytes};
});
onPageEvent('pointerup',guard(async event=>{
  const press=commentPress;commentPress=null;
  if(!press||state.tool!=='select'||press.page!==state.page||press.revision!==state.bytes||event.target.closest('.annotation-badge,.pdf-link,.pdf-link-badge'))return;
  if(Math.hypot(event.clientX-press.x,event.clientY-press.y)>4||!window.getSelection()?.isCollapsed)return;
  const point=eventPoint(event);
  const record=[...annotationHits].reverse().find(item=>point[0]>=item.rect[0]&&point[0]<=item.rect[2]&&point[1]>=item.rect[1]&&point[1]<=item.rect[3]);
  if(record)await viewAnnotation(record);
}));
function cancelPageDrag(){
  directEditor?.close();const current=drag;drag=null;commentPress=null;$('dragrect')?.remove();$('inkPreview')?.remove();
  if(current)try{$('overlay').releasePointerCapture?.(current.pointer)}catch{}
}
function startInkPreview(stroke){
  const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),line=document.createElementNS(ns,'polyline'),dot=document.createElementNS(ns,'circle');
  svg.id='inkPreview';svg.classList.add('ink-preview');svg.setAttribute('aria-hidden','true');
  svg.setAttribute('viewBox',stroke.bounds[0]+' '+stroke.bounds[1]+' '+(stroke.bounds[2]-stroke.bounds[0])+' '+(stroke.bounds[3]-stroke.bounds[1]));
  svg.setAttribute('preserveAspectRatio','none');
  for(const[key,value]of Object.entries({fill:'none',stroke:stroke.color,'stroke-width':stroke.width,'stroke-linecap':'round','stroke-linejoin':'round'}))line.setAttribute(key,String(value));
  dot.setAttribute('fill',stroke.color);dot.setAttribute('r',stroke.width/2);svg.append(line,dot);$('overlay').append(svg);
  stroke.preview={svg,line,dot};updateInkPreview(stroke);
}
function updateInkPreview(stroke){
  const {line,dot}=stroke.preview;
  line.setAttribute('points',stroke.points.map(point=>point.join(',')).join(' '));
  dot.setAttribute('cx',stroke.points[0][0]);dot.setAttribute('cy',stroke.points[0][1]);dot.style.display=stroke.points.length===1?'':'none';
}
async function saveInkStroke(stroke){
  const points=savedInkPoints(stroke);
  await editMu('Added freehand drawing',doc=>{
    const page=doc.loadPage(stroke.page);let annotation;
    try{
      annotation=page.createAnnotation('Ink');annotation.setAuthor('pdfpro');
      annotation.setColor(color(stroke.color));annotation.setBorderWidth(stroke.width);
      annotation.setInkList([points]);annotation.update();
    }finally{annotation?.destroy();page.destroy()}
  });
}
onPageEvent('pointerdown',event=>{
  if(!state.doc||['select','search','directedit'].includes(state.tool)||drag||event.button!==0||event.isPrimary===false||state.abort||(state.tool==='ink'&&pendingActions)||documentTransitions||$('modalroot').firstChild)return;
  event.preventDefault();
  const bounds=pageInfo().bounds,origin=$('overlay').getBoundingClientRect();
  const current={kind:state.tool,page:state.page,revision:state.bytes,pointer:event.pointerId,bounds:[...bounds],origin:{left:origin.left,top:origin.top},zoom:state.zoom,points:[],color:state.color,width:Math.max(1,state.size/7)};
  const point=inkPoint(event,current);if(!point)return;
  current.start=point;current.points.push(point);drag=current;
  try{$('overlay').setPointerCapture?.(event.pointerId)}catch{}
  if(current.kind==='ink')startInkPreview(current);
  else{const box=document.createElement('div');box.className='selection';box.id='dragrect';$('overlay').append(box)}
});
onPageEvent('pointermove',event=>{
  const current=drag;if(!current||event.pointerId!==current.pointer)return;
  if(current.revision!==state.bytes||current.page!==state.page||current.kind!==state.tool||current.zoom!==state.zoom){cancelPageDrag();return}
  event.preventDefault();
  if(current.kind==='ink'){appendInkSamples(current,event);updateInkPreview(current);return}
  const point=eventPoint(event);current.points.push(point);
  const b=pageInfo().bounds,r=[Math.min(point[0],current.start[0]),Math.min(point[1],current.start[1]),Math.max(point[0],current.start[0]),Math.max(point[1],current.start[1])],el=$('dragrect');
  if(el)Object.assign(el.style,{left:(r[0]-b[0])*state.zoom+'px',top:(r[1]-b[1])*state.zoom+'px',width:(r[2]-r[0])*state.zoom+'px',height:(r[3]-r[1])*state.zoom+'px'});
});
onPageEvent('pointerup',guard(async event=>{
  const current=drag;if(!current||event.pointerId!==current.pointer)return;
  if(current.revision!==state.bytes||current.page!==state.page||current.kind!==state.tool||current.zoom!==state.zoom){cancelPageDrag();return}
  if(current.kind==='ink'){
    appendInkSamples(current,event);cancelPageDrag();await saveInkStroke(current);return;
  }
  const end=eventPoint(event);current.points.push(end);cancelPageDrag();
  const b=pageInfo().bounds;let rect=[Math.min(end[0],current.start[0]),Math.min(end[1],current.start[1]),Math.max(end[0],current.start[0]),Math.max(end[1],current.start[1])];
  if(rect[2]-rect[0]<5)rect[2]=Math.min(b[2],rect[0]+160);
  if(rect[3]-rect[1]<5)rect[3]=Math.min(b[3],rect[1]+Math.max(24,state.size*1.8));
  rect=[Math.max(b[0],rect[0]),Math.max(b[1],rect[1]),Math.min(b[2],rect[2]),Math.min(b[3],rect[3])];await onRegion(rect,current.points);
}));
for(const type of ['pointercancel','lostpointercapture'])onPageEvent(type,event=>{if(drag?.pointer===event.pointerId)cancelPageDrag()});

async function onRegion(rect,points){const tool=state.tool;if(tool==='redact'){state.marks.push({page:state.page,rect});renderTabs();drawOverlays();status(state.marks.length+' pending redaction(s) · Apply redactions to remove content');await persistLocal();return}if(tool==='replace'){
  const page=state.doc.loadPage(state.page),structured=page.toStructuredText('');
  const original=structured.copy([rect[0],rect[1]],[rect[2],rect[3]]);structured.destroy();page.destroy();
  const value=await ask('Replace selected text','Replacement text',original.trim(),'<p class="help">Font: '+esc(state.font)+'. The selected text is permanently removed before replacement. Graphics remain. Select a complete added text box to replace it; text does not reflow beyond the selected area.</p>');
  if(value===null)return;
  const appearance=await renderSystemText(value,{font:state.font,size:state.size,width:rect[2]-rect[0],height:rect[3]-rect[1],color:state.color});
  if(!await signedMutation())return;
  await job('Replacing text',async()=>{
    const source=await PDFDocument.load(state.bytes,{updateMetadata:false}),region=pdfRect(rect);
    const removed=removeSystemTextBoxes(source,source.getPage(state.page),[region.x,region.y,region.x+region.width,region.y+region.height]);
    const input=removed?await source.save({useObjectStreams:false}):state.bytes;
    const cleaned=await backgroundEngine('replaceTextPDF',[input,[{page:state.page,rect,text:'',size:4,padding:0}]]);
    const doc=await PDFDocument.load(cleaned,{updateMetadata:false}),page=doc.getPage(state.page);
    const inv=mupdf.Matrix.invert(pageInfo().transform),unit=Math.hypot(inv[0],inv[1]),anchor=toPdf([rect[0],rect[3]]);
    await drawSystemText(doc,page,appearance,{x:anchor[0],y:anchor[1],rotation:page.getRotation().angle,scale:unit});
    await setBytes(await doc.save({useObjectStreams:false}),{label:'Replaced selected text'});
  });return;
}if(tool==='crop'){await editMu('Cropped page',d=>{const p=d.loadPage(state.page);p.setPageBox('CropBox',rect);p.destroy()});return}
if(tool.startsWith('field')){const name=await ask('Create form field','Unique field name','Field_'+Date.now().toString(36));if(!name)return;let choices;if(tool==='fieldRadio'||tool==='fieldDropdown'){const s=await ask('Field choices','Choices, separated by commas','Yes,No');if(!s)return;choices=s.split(',').map(s=>s.trim()).filter(Boolean);if(!choices.length)throw Error('Add at least one choice')}const r=pdfRect(rect);await editPDF('Created form field',d=>{const f=d.getForm();if(f.getFieldMaybe(name))throw Error('A field with this name already exists');const p=d.getPage(state.page);const opts={...r,borderWidth:1,borderColor:rgb(.063,.114,.227),backgroundColor:rgb(1,1,1)};if(tool==='fieldText')f.createTextField(name).addToPage(p,opts);if(tool==='fieldCheck')f.createCheckBox(name).addToPage(p,{...opts,width:Math.min(r.width,r.height),height:Math.min(r.width,r.height)});if(tool==='fieldDropdown'){const c=f.createDropdown(name);c.addOptions(choices);c.addToPage(p,opts)}if(tool==='fieldRadio'){const c=f.createRadioGroup(name);choices.forEach((o,i)=>c.addOptionToPage(o,p,{x:r.x+i*(r.width/choices.length),y:r.y,width:Math.min(18,r.width/choices.length),height:18}));choices.forEach((o,i)=>p.drawText(o,{x:r.x+i*(r.width/choices.length),y:r.y-14,size:10}))}});return}
if(tool==='link'){const page=state.page,value=await linkSettings();if(!value)return;await editMu('Added link',doc=>writeLink(doc,page,rect,value.uri));toast('Link added. Choose Done or click Add link again to follow links.');return}
if(['text','image','signatureImage'].includes(tool)){const r=pdfRect(rect);let value;if(tool==='text'){value=await ask('Add text','Text to add','Your text');if(value===null)return}await editPDF('Added '+tool,async d=>{const p=d.getPage(state.page);if(tool==='text'){
  const appearance=await renderSystemText(value,{font:state.font,size:state.size,width:rect[2]-rect[0],height:rect[3]-rect[1],color:state.color});
  const inv=mupdf.Matrix.invert(pageInfo().transform),unit=Math.hypot(inv[0],inv[1]),anchor=toPdf([rect[0],rect[3]]);
  await drawSystemText(d,p,appearance,{x:anchor[0],y:anchor[1],rotation:p.getRotation().angle,scale:unit});
}if(tool==='image'||tool==='signatureImage'){const data=state.selectedImage;if(!data)throw Error('Choose an image first');const im=data.type==='image/png'?await d.embedPng(data.bytes):await d.embedJpg(data.bytes);const inv=mupdf.Matrix.invert(pageInfo().transform),unit=Math.hypot(inv[0],inv[1]),s=Math.min((rect[2]-rect[0])/im.width,(rect[3]-rect[1])/im.height),anchor=toPdf([rect[0],rect[1]+im.height*s]);p.drawImage(im,{x:anchor[0],y:anchor[1],width:im.width*s*unit,height:im.height*s*unit,rotate:degrees(p.getRotation().angle)})}});return}
let contents='';
if(['note','freetext','stamp'].includes(tool)){
  const title=tool==='stamp'?'Add stamp':tool==='freetext'?'Add text comment':'Add sticky note';
  const result=await modal(title,`<label for="annotationText">${tool==='stamp'?'Stamp label':'Comment text'}</label><textarea id="annotationText" name="text" rows="4" maxlength="10000" required>${tool==='stamp'?'APPROVED':''}</textarea>${tool!=='note'?'<p class="help">The background stays transparent. Text wraps within the selected area and fits down to 4 pt. Select a larger area for long comments.</p>':''}`);
  if(!result)return;contents=result.text;
}
let annotationLayout;
const appearance=(tool==='freetext'||tool==='stamp')?await renderSystemText(contents,{font:state.font,size:state.size,width:rect[2]-rect[0],height:rect[3]-rect[1],kind:tool,color:state.color}):null;
await editMu('Added annotation',d=>{
  const page=d.loadPage(state.page);
  let annotation;
  try{
    if(tool==='freetext'||tool==='stamp'){
      annotation=createTextAnnotation(d,page,{kind:tool,rect,text:contents,size:state.size,color:color(),author:'pdfpro',appearance});
      annotationLayout=annotation.pdfproLayout;
      return;
    }
    const types={highlight:'Highlight',underline:'Underline',strikeout:'StrikeOut',note:'Text',rectangle:'Square',ellipse:'Circle',line:'Line',arrow:'Line'};
    const type=types[tool];if(!type)throw Error('Select a tool first');
    annotation=page.createAnnotation(type);annotation.setAuthor('pdfpro');annotation.setContents(contents);annotation.setColor(color());
    if(['highlight','underline','strikeout'].includes(tool)){
      annotation.setQuadPoints([[rect[0],rect[1],rect[2],rect[1],rect[0],rect[3],rect[2],rect[3]]]);annotation.setOpacity(.45);
    }else if(tool==='line'||tool==='arrow'){
      annotation.setLine(points[0],points.at(-1));annotation.setBorderWidth(Math.max(1,state.size/7));
      if(tool==='arrow')annotation.setLineEndingStyles('None','OpenArrow');
    }else{
      annotation.setRect(rect);
      if(tool==='note')annotation.setIcon('Comment');
      if(tool==='rectangle'||tool==='ellipse')annotation.setBorderWidth(Math.max(1,state.size/7));
    }
    annotation.update();
  }finally{annotation?.destroy();page.destroy()}
});
if(annotationLayout?.shrunk)toast('Annotation text fitted at '+annotationLayout.size.toFixed(1)+' pt.');
}

async function applyRedactions(){if(!state.marks.length){toast('Choose Mark redaction and drag over the content first.');return}const v=await modal('Apply '+state.marks.length+' redaction(s)',`<p>Content removal cannot be reversed in the exported PDF. Your source file stays unchanged.</p><label>Export method</label><select name="method"><option value="raster">Secure rebuild — every page becomes an image</option><option value="native">Native content removal — preserve remaining text</option></select><p class="help">Secure rebuild removes all hidden text, metadata, attachments, comments, forms, links, and earlier revisions from the result. Searchability and vector quality are lost. Native removal keeps remaining page content and needs document-specific review.</p><label>Rebuild resolution</label><select name="dpi"><option>150</option><option selected>200</option><option>300</option></select>`,{ok:'Apply & create copy'});if(!v)return;if(!await signedMutation(true))return;await job('Applying redactions',async()=>{const result=await backgroundEngine('redactPDF',[state.bytes,state.marks,{rasterize:v.method==='raster',dpi:+v.dpi,sanitize:true,blackBoxes:true}]);const bytes=result.bytes||result;await setBytes(bytes,{label:'Redactions applied · '+(v.method==='raster'?'secure raster rebuild':'native removal')});download(bytes,outname('-redacted'));toast('Redacted copy downloaded. Review the result before sharing.')})}
async function sanitize(){if(!await confirm('Sanitise document?','Rebuild all pages as images and remove hidden content, metadata, forms, annotations, links, attachments, and previous revisions. Searchable text and vector content will be lost.','Rebuild PDF'))return;if(!await signedMutation())return;await job('Sanitising document',async()=>{const result=await backgroundEngine('sanitizePDF',[state.bytes,{rasterize:true,dpi:200}]);await setBytes(result.bytes||result,{label:'Sanitised with full-page raster reconstruction'})})}
async function encrypt(){if(!await signedMutation())return;const v=await modal('Encrypt PDF','<p>Creates a separate AES-256 protected export. Your open working copy remains unlocked.</p><label>Open password</label><input name="password" id="encpw" type="password" minlength="6" required autocomplete="new-password"><label>Confirm password</label><input id="encpw2" type="password" required><label>Owner password (optional; use a different password)</label><input name="ownerPassword" type="password"><label><input type="checkbox" id="allowprint" checked>Allow printing</label><label><input type="checkbox" id="allowcopy" checked>Allow copying</label><p class="help">PDF permission flags depend on the reader. Protect confidentiality with the open password.</p>',{ok:'Download encrypted PDF',read:()=>{if($('encpw').value!==$('encpw2').value)throw Error('Passwords do not match');const v=Object.fromEntries(new FormData($('modalform')));const permissions=-4 & ~((!$('allowprint').checked?(4|2048):0)|(!$('allowcopy').checked?16:0));return{...v,permissions}}});if(!v)return;await job('Encrypting PDF',async()=>download(await backgroundEngine('protectPDF',[state.bytes,v]),outname('-encrypted')))}
async function optimize(){if(!await signedMutation())return;await job('Optimising PDF',async()=>{const before=state.bytes.length,result=await backgroundEngine('optimizePDF',[state.bytes]);const bytes=result.bytes||result;if(bytes.length>=before){toast('No size reduction with lossless optimisation. Original retained.');return}await setBytes(bytes,{label:'Optimised · '+fmt(before)+' → '+fmt(bytes.length)});toast('Reduced file size by '+Math.round((1-bytes.length/before)*100)+'%')})}
async function visualSignature(){
  const v=await modal('Add a visual signature','<p>This places a signature image. Use Certificate sign for a cryptographic signature.</p>'+fontChoice()+'<label for="sigtext">Type your name (optional)</label><input id="sigtext" placeholder="Your name" maxlength="200"><label for="drawcanvas">Draw your signature (optional)</label><canvas id="drawcanvas" width="900" height="300" aria-label="Draw your signature"></canvas><button type="button" id="clearsig" class="small" style="margin-top:8px">Clear drawing</button><p class="help">Type, draw, or use both. When both are provided, your name appears below the drawing.</p><label for="sigfile">Or import a signature image</label><input type="file" id="sigfile" accept="image/png,image/jpeg"><p class="help">An imported PNG or JPEG is used by itself.</p>',{
    ok:'Use signature',setup:()=>{
      const c=$('drawcanvas'),ctx=c.getContext('2d');ctx.strokeStyle=ctx.fillStyle='#101d3a';ctx.lineWidth=4;ctx.lineCap=ctx.lineJoin='round';let pointer=null;
      const point=event=>{const r=c.getBoundingClientRect();return r.width>0&&r.height>0?[(event.clientX-r.left)*c.width/r.width,(event.clientY-r.top)*c.height/r.height]:null};
      c.onpointerdown=event=>{if(pointer!==null||event.button!==0||event.isPrimary===false)return;const p=point(event);if(!p)return;event.preventDefault();pointer=event.pointerId;c.setPointerCapture?.(pointer);ctx.beginPath();ctx.arc(p[0],p[1],2,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.moveTo(...p);c.dataset.drawn='1'};
      c.onpointermove=event=>{if(event.pointerId!==pointer||pointer===null)return;const p=point(event);if(!p)return;event.preventDefault();ctx.lineTo(...p);ctx.stroke()};
      c.onpointerup=event=>{if(event.pointerId!==pointer||pointer===null)return;const p=point(event);if(p){ctx.lineTo(...p);ctx.stroke()}const id=pointer;pointer=null;try{c.releasePointerCapture?.(id)}catch{}};
      for(const type of ['pointercancel','lostpointercapture'])c.addEventListener(type,event=>{if(event.pointerId===pointer)pointer=null});
      $('clearsig').onclick=()=>{const id=pointer;pointer=null;if(id!==null)try{c.releasePointerCapture?.(id)}catch{}ctx.clearRect(0,0,c.width,c.height);delete c.dataset.drawn};
    },read:async()=>{
      const file=$('sigfile').files[0];if(file){const type=file.type==='image/png'||/\.png$/i.test(file.name)?'image/png':file.type==='image/jpeg'||/\.jpe?g$/i.test(file.name)?'image/jpeg':null;if(!type)throw Error('Import a PNG or JPEG signature image.');return{bytes:new Uint8Array(await file.arrayBuffer()),type}}
      const text=$('sigtext').value.trim(),font=$('dialogFont').value;
      const image=await composeVisualSignature($('drawcanvas'),{text,font,hasDrawing:$('drawcanvas').dataset.drawn==='1'});
      if(text){state.font=font;scheduleLocal()}return image;
    }
  });
  if(!v)return;state.selectedImage=v;state.tool='signatureImage';renderPanel();drawOverlays();toast('Drag an area on the page to place the signature.');
}
async function certificateSign(){need();if(state.marks.length)throw Error('Apply the pending redactions before certificate signing. Marked areas have not yet been removed from the PDF.');const v=await modal('Sign with a certificate','<p>Import your own RSA PKCS#12 certificate and private key (2048 bits or larger). Signing takes place offline and preserves earlier approval revisions. The certificate field is invisible; use Visual signature separately for a visible image.</p><p class="help">CA trust, live revocation, and trusted timestamps are unavailable.</p><label>Certificate file (.p12 / .pfx)</label><input id="p12file" type="file" accept=".p12,.pfx" required><label>Certificate password</label><input id="p12pw" type="password" autocomplete="off"><label>Reason</label><input id="signreason" value="Document approval"><label>Location (optional)</label><input id="signlocation">',{ok:'Sign & download',read:async()=>{const f=$('p12file').files[0];if(!f)throw Error('Choose a certificate file');const value={bytes:new Uint8Array(await f.arrayBuffer()),password:$('p12pw').value,reason:$('signreason').value,location:$('signlocation').value};$('p12pw').value='';return value}});if(!v)return;let credential;try{await job('Signing document',async()=>{try{credential=await window.PdfProSigning.importP12(v.bytes,v.password)}finally{v.password='';v.bytes.fill(0)}const bytes=await window.PdfProSigning.signPdf(state.bytes,credential,{reason:v.reason,location:v.location});await setBytes(bytes,{label:'Certificate signature applied'});download(bytes,outname('-signed'))})}finally{credential=null;v.password='';v.bytes.fill(0)}await verifySignatures()}
async function verifySignatures(){need();const result=await window.PdfProSigning.verifyPdf(state.bytes);const entries=result.signatures||[];await modal('Offline signature inspection',`<p>Cryptographic byte integrity is separate from certificate identity and trust. CA trust, certificate chains, revocation, permission policies, and trusted timestamps are not validated.</p>${entries.length?`<table><tr><th>Signature</th><th>Byte integrity</th><th>Coverage</th><th>Certificate</th></tr>${entries.map((entry,i)=>`<tr><td>${esc(entry.name||entry.field||'Signature '+(i+1))}</td><td>${esc(entry.integrity)}</td><td>${esc(entry.coversCurrentFile?'Current file':entry.integrity==='valid'?'Earlier revision · '+entry.laterBytes+' later byte(s)':'Unverified')}</td><td>${esc(entry.signers?.[0]?.certificate?.subject||'Unavailable')}<br>Trust not established</td></tr>`).join('')}</table><details><summary>Verification details and certificate fingerprints</summary><pre class="mono">${esc(JSON.stringify(result,null,2))}</pre></details>`:'<p>No certificate signature fields were found.</p>'}`,{ok:null,wide:true})}

function canvasForPage(index,scale=2){const testPage=state.doc.loadPage(index),testBounds=testPage.getBounds();testPage.destroy();if((testBounds[2]-testBounds[0])*(testBounds[3]-testBounds[1])*scale*scale>30000000)throw Error('Page exceeds render memory limit. Use a smaller page size or lower resolution.');const p=state.doc.loadPage(index),bounds=p.getBounds(),pix=p.toPixmap([scale,0,0,scale,-bounds[0]*scale,-bounds[1]*scale],mupdf.ColorSpace.DeviceRGB,true,true);const c=document.createElement('canvas');c.width=pix.getWidth();c.height=pix.getHeight();c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(pix.getPixels()),c.width,c.height),0,0);pix.destroy();p.destroy();return c}
async function runOCR(){
  const v=await modal('Recognise scanned text','<p>English recognition is embedded and works offline. Existing page appearance stays unchanged; a searchable, invisible text layer is added.</p><label>Pages</label><input name="pages" value="'+(state.page+1)+'" required><label>Resolution</label><select name="dpi"><option>150</option><option selected>200</option><option>300</option></select><label><input name="skip" type="checkbox" checked>Skip pages that already contain text</label><p class="help">Recognition can make mistakes. Review the extracted text before relying on it. Output text uses the standard Latin font character set.</p>',{ok:'Run OCR'});
  if(!v)return;
  const pages=[...new Set(parsePages(v.pages))];
  if(!await signedMutation())return;
  const uncertain=[];let totalWords=0,skipped=0;
  await job('Recognising text',async(progress,signal)=>{
    const d=await PDFDocument.load(state.bytes,{updateMetadata:false});
    const font=await d.embedFont(StandardFonts.Helvetica);
    for(const[i,index]of pages.entries()){
      if(signal.aborted)throw new DOMException('Cancelled','AbortError');
      const p=state.doc.loadPage(index);
      let text,bounds,inv;
      try{
        const st=p.toStructuredText('');
        try{text=st.asText().trim()}finally{st.destroy()}
        bounds=p.getBounds();inv=mupdf.Matrix.invert(p.getTransform());
      }finally{p.destroy()}
      if(v.skip&&text){skipped++;progress((i+1)/pages.length,'Skipped page '+(index+1)+' (already contains text)');continue}
      const scale=+v.dpi/72,c=canvasForPage(index,scale);
      let result;
      try{result=await OCR.recognizeImage(c,{dpi:+v.dpi,signal,onProgress:p=>progress((i+(p.progress||0))/pages.length,'Page '+(index+1)+' · '+p.status)})}
      finally{c.width=0;c.height=0}
      const page=d.getPage(index);
      const key=result.words.length?page.node.newFontDictionary(font.name,font.ref):null;
      const lineBoxes=new Map();for(const line of result.lines)for(const word of line.words)lineBoxes.set(word,line.bbox);
      let words=0;
      for(const word of result.words){
        const t=word.text.replace(/[^\x20-\x7e\xa0-\xff]/g,'?');
        if(!t.trim())continue;
        let encoded;try{encoded=font.encodeText(t)}catch{continue}
        const b=word.bbox,line=lineBoxes.get(word)||b,x=b.x0/scale+bounds[0],y=line.y1/scale+bounds[1];
        const size=Math.max(3,(line.y1-line.y0)/scale*.9),width=(b.x1-b.x0)/scale;
        const natural=font.widthOfTextAtSize(t,size),sx=natural>0?width/natural:1;
        const px=inv[0]*x+inv[2]*y+inv[4],py=inv[1]*x+inv[3]*y+inv[5];
        page.pushOperators(pushGraphicsState(),beginText(),setFontAndSize(key,size),setTextRenderingMode(TextRenderingMode.Invisible),setTextMatrix(inv[0]*sx,inv[1]*sx,-inv[2],-inv[3],px,py),showText(encoded),endText(),popGraphicsState());words++;
      }
      totalWords+=words;
      uncertain.push(...result.uncertainWords.map(w=>({page:index+1,text:w.text,confidence:w.confidence})));
      progress((i+1)/pages.length,'Page '+(index+1)+' · '+words+' words');await delay();
    }
    if(signal.aborted)throw new DOMException('Cancelled','AbortError');
    if(totalWords){const bytes=await d.save({useObjectStreams:false});if(signal.aborted)throw new DOMException('Cancelled','AbortError');await setBytes(bytes,{label:'OCR complete · '+totalWords+' words added'})}
  });
  if(!totalWords){toast(skipped===pages.length?'All selected pages already contain text.':'No recognisable text was found. Try 300 DPI or a clearer scan.');return}
  if(uncertain.length)await modal('OCR review','<p>'+totalWords+' words added. '+uncertain.length+' words had low recognition confidence. Check the source before using extracted text.</p><pre>'+esc(uncertain.slice(0,150).map(w=>'Page '+w.page+': '+w.text+' ('+Math.round(w.confidence)+'%)').join('\n'))+'</pre>'+(uncertain.length>150?'<p class="help">Showing the first 150 uncertain words.</p>':''),{ok:null});
  else toast('OCR complete · '+totalWords+' searchable words added');
}
async function compare(){
  const f=await choose('application/pdf');if(!f)return;
  const before=Engine.openPDF(state.bytes);let other,previewController;
  try{
    other=Engine.openPDF(new Uint8Array(await f.arrayBuffer()));
    const beforeCount=before.countPages(),otherCount=other.countPages(),max=Math.max(beforeCount,otherCount),results=[];
    function renderPair(index){
      const p1=before.loadPage(index),p2=other.loadPage(index);let pix;
      try{
        const b1=p1.getBounds(),b2=p2.getBounds();
        const area=Math.max(b1[2]-b1[0],b2[2]-b2[0])*Math.max(b1[3]-b1[1],b2[3]-b2[1]);
        const scale=Math.min(1,Math.sqrt(4000000/Math.max(1,area)));
        const canvases=[],texts=[];
        for(const[p,b]of [[p1,b1],[p2,b2]]){
          const st=p.toStructuredText('');try{texts.push(st.asText())}finally{st.destroy()}
          pix=p.toPixmap([scale,0,0,scale,-b[0]*scale,-b[1]*scale],mupdf.ColorSpace.DeviceRGB,true,true);
          const c=document.createElement('canvas');c.width=pix.getWidth();c.height=pix.getHeight();
          c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(pix.getPixels()),c.width,c.height),0,0);
          pix.destroy();pix=null;canvases.push(c);
        }
        return{canvases,texts,scale};
      }finally{pix?.destroy();p1.destroy();p2.destroy()}
    }
    await job('Comparing documents',async(progress,signal)=>{
      for(let i=0;i<max;i++){
        if(signal.aborted)throw new DOMException('Cancelled','AbortError');
        if(i>=beforeCount||i>=otherCount){results.push({page:i+1,change:i>=beforeCount?'Only in comparison file':'Only in current file'});progress((i+1)/max);continue}
        const pair=renderPair(i);let diff;
        try{
          diff=await OCR.compareCanvases(...pair.canvases,{signal,onProgress:p=>progress((i+p.progress)/max,'Comparing page '+(i+1))});
          results.push({page:i+1,visual:diff.changedPercent,sameDimensions:diff.sameDimensions,text:pair.texts[0]===pair.texts[1]?'Same text':'Text changed',before:pair.texts[0].slice(0,3000),after:pair.texts[1].slice(0,3000)});
        }finally{for(const c of pair.canvases){c.width=0;c.height=0}if(diff){diff.canvas.width=0;diff.canvas.height=0}}
        progress((i+1)/max);await delay();
      }
    });
    const comparable=results.filter(r=>!r.change);
    await modal('Compare with '+f.name,
      '<p>Red areas show visual changes. Pages are aligned at the top-left and compared at up to 72 DPI; very large pages use a lower resolution. Text changes are checked separately.</p>'+
      '<table><tr><th>Page</th><th>Visual difference</th><th>Text</th></tr>'+results.map(r=>'<tr><td>'+r.page+'</td><td>'+(r.change||r.visual.toFixed(2)+'%'+(r.sameDimensions?'':' · size changed'))+'</td><td>'+(r.text||'')+'</td></tr>').join('')+'</table>'+
      (comparable.length?'<label for="comparepage">Inspect visual differences</label><select id="comparepage">'+comparable.map(r=>'<option value="'+(r.page-1)+'">Page '+r.page+' · '+r.visual.toFixed(2)+'%</option>').join('')+'</select><p id="compareinfo" class="help" role="status"></p><div id="compareheatmap" style="max-height:50vh;overflow:auto;background:#f2f4f8;border:1px solid var(--line);margin-top:10px"></div>':'')+
      '<details style="margin-top:18px"><summary>Extracted text changes</summary><p class="help">Current file is on the left; comparison file is on the right. Showing up to 3,000 characters per page.</p>'+results.filter(r=>r.text==='Text changed').map(r=>'<h3>Page '+r.page+'</h3><div class="flex" style="align-items:flex-start"><pre>'+esc(r.before)+'</pre><pre>'+esc(r.after)+'</pre></div>').join('')+'</details>',
      {ok:null,wide:true,setup:()=>{
        if(!comparable.length)return;
        async function preview(index){
          previewController?.abort();const controller=new AbortController();previewController=controller;
          const info=$('compareinfo'),host=$('compareheatmap');info.textContent='Rendering visual differences…';
          let pair;
          try{
            pair=renderPair(index);
            const diff=await OCR.compareCanvases(...pair.canvases,{signal:controller.signal});
            if(controller.signal.aborted)return;
            diff.canvas.style.width='100%';diff.canvas.style.height='auto';diff.canvas.style.display='block';
            diff.canvas.setAttribute('role','img');diff.canvas.setAttribute('aria-label','Page '+(index+1)+' visual differences highlighted in red');
            host.replaceChildren(diff.canvas);info.textContent=diff.changedPercent.toFixed(2)+'% of pixels differ'+(diff.sameDimensions?'':' · page dimensions changed')+'.';
          }catch(error){if(error.name!=='AbortError'&&!controller.signal.aborted)info.textContent=error.message}
          finally{if(pair)for(const c of pair.canvases){c.width=0;c.height=0}}
        }
        $('comparepage').onchange=e=>{void preview(+e.target.value)};
        void preview(comparable[0].page-1);
      }});
  }finally{previewController?.abort();other?.destroy();before.destroy()}
}
async function exportText(){await job('Extracting text',async()=>{const result=await backgroundEngine('extractTextPDF',[state.bytes]);const text=result.map(page=>page.text).join('\n\n');download(text,outname('-text','txt'),'text/plain;charset=utf-8')})}
async function exportImage(type){const c=canvasForPage(state.page,2);const blob=await new Promise(r=>c.toBlob(r,'image/'+type,.92));download(blob,outname('-page-'+(state.page+1),type==='jpeg'?'jpg':'png'))}
async function allImages(){await job('Exporting page images',async progress=>{const entries=[];for(let i=0;i<state.doc.countPages();i++){const c=canvasForPage(i,2),blob=await new Promise(r=>c.toBlob(r,'image/png'));entries.push({name:'page-'+String(i+1).padStart(3,'0')+'.png',bytes:new Uint8Array(await blob.arrayBuffer())});progress((i+1)/state.doc.countPages());await delay()}download(zip(entries),outname('-images','zip'),'application/zip')})}
async function print(){need();const win=window.open('','_blank');if(!win){toast('Allow pop-ups to open the print view.');return}win.document.write('<!doctype html><html><head><title>'+esc(state.name)+'</title><style>body{margin:0}img{display:block;width:100%;height:auto;break-after:page}@media print{img{max-height:100vh;object-fit:contain}}@page{margin:0}</style></head><body><p>Preparing local print preview…</p></body></html>');await job('Preparing print view',async progress=>{const images=[];for(let i=0;i<state.doc.countPages();i++){images.push(canvasForPage(i,1.5).toDataURL('image/png'));progress((i+1)/state.doc.countPages());await delay()}win.document.body.innerHTML='';for(const src of images){const im=win.document.createElement('img');im.src=src;win.document.body.append(im);await im.decode()}win.focus();win.print()})}
async function saveWorkspace(){download(JSON.stringify({format:'pdfpro-workspace',version:1,name:state.name,page:state.page,marks:state.marks,font:state.font,pdf:toBase64(state.bytes)}),outname('-workspace','pdfpro'),'application/json')}
async function restoreWorkspace(){
  requireDocumentTransition();documentTransitions++;try{
  const file=await choose('.pdfpro,application/json');if(!file)return;
  const value=JSON.parse(await file.text());
  if(value.format!=='pdfpro-workspace'||value.version!==1)throw Error('Unsupported workspace format');
  const bytes=fromBase64(value.pdf),doc=Engine.openPDF(bytes);let count;
  try{count=doc.countPages()}finally{doc.destroy()}
  const marks=(Array.isArray(value.marks)?value.marks:[]).filter(mark=>Number.isInteger(mark.page)&&mark.page>=0&&mark.page<count&&Array.isArray(mark.rect)&&mark.rect.length===4&&mark.rect.every(Number.isFinite));
  await addDocument(bytes,{name:String(value.name||'Restored.pdf'),page:Math.max(0,Math.floor(+value.page)||0),dirty:true,marks,font:value.font,label:'Restored workspace in a new tab'});
  }finally{documentTransitions--}
}
function toBase64(bytes){let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s)}
function fromBase64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
async function batch(){
  const files=await choose('application/pdf',true);if(!files.length)return;
  const value=await modal('Batch process '+files.length+' PDF(s)','<label>Operation</label><select name="operation"><option value="optimize">Lossless optimisation</option><option value="watermark">Text watermark</option><option value="number">Page numbering</option><option value="bates">Bates numbering across files</option><option value="rotate">Rotate all pages 90°</option><option value="text">Extract text</option></select><label>Watermark text / numbering prefix</label><input name="text" value="CONFIDENTIAL"><label>Starting number</label><input name="start" type="number" value="1">'+decorationChoices(),{ok:'Process & download ZIP'});
  if(!value)return;state.font=value.font;state.color=value.textColour;scheduleLocal();
  await job('Batch processing',async(progress,signal)=>{
    const entries=[],errors=[];let counter=+value.start||1;
    for(const[index,file]of files.entries()){
      if(signal.aborted)throw new DOMException('Cancelled','AbortError');
      try{
        let bytes=new Uint8Array(await file.arrayBuffer()),ext='pdf';
        if(value.operation!=='text'&&(await window.PdfProSigning.inspectSignatures(bytes)).length)throw Error('Signed PDF skipped: rewriting invalidates its signature');
        if(value.operation==='optimize'){const result=await backgroundEngine('optimizePDF',[bytes]);bytes=result.bytes||result}
        else if(value.operation==='text'){
          const result=await backgroundEngine('extractTextPDF',[bytes]);bytes=new TextEncoder().encode(result.map(page=>page.text).join('\n\n'));ext='txt';
        }else{
          const doc=await PDFDocument.load(bytes);
          for(const[i,page]of doc.getPages().entries()){
            if(value.operation==='rotate')page.setRotation(degrees((page.getRotation().angle+90)%360));
            if(value.operation==='watermark'){
              const natural=measureSystemText(value.text,{font:state.font,size:50});
              const size=Math.max(4,Math.min(50,50*(page.getWidth()-90)/Math.max(1,natural)));
              await drawDecorationText(doc,page,value.text,{size,x:35,baseline:page.getHeight()*.5,opacity:.16,rotation:25});
            }
            if(value.operation==='number'||value.operation==='bates'){
              const text=value.text+String(value.operation==='bates'?counter++:(+value.start||1)+i).padStart(value.operation==='bates'?6:1,'0');
              await drawDecorationText(doc,page,text);
            }
          }
          bytes=await doc.save({useObjectStreams:false});
        }
        entries.push({name:String(index+1).padStart(3,'0')+'-'+file.name.replace(/\.pdf$/i,'')+'-processed.'+ext,bytes});
      }catch(error){errors.push(file.name+': '+error.message)}
      progress((index+1)/files.length,file.name);await delay();
    }
    if(errors.length)entries.push({name:'errors.txt',bytes:new TextEncoder().encode(errors.join('\n'))});
    download(zip(entries),'pdfpro-batch.zip','application/zip');toast(entries.length+' output(s), '+errors.length+' error(s)');
  });
}

const crcTable=Uint32Array.from({length:256},(_,i)=>{let c=i;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0});
function crc32(bytes){let c=0xffffffff;for(const x of bytes)c=crcTable[(c^x)&255]^(c>>>8);return(c^0xffffffff)>>>0}
function zip(entries){const parts=[],central=[];let offset=0;const enc=new TextEncoder();const header=(n)=>new DataView(new ArrayBuffer(n));for(const e of entries){const name=enc.encode(e.name.replace(/[\\/]/g,'_')),bytes=e.bytes instanceof Uint8Array?e.bytes:new Uint8Array(e.bytes),crc=crc32(bytes),h=header(30);h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint32(14,crc,true);h.setUint32(18,bytes.length,true);h.setUint32(22,bytes.length,true);h.setUint16(26,name.length,true);parts.push(new Uint8Array(h.buffer),name,bytes);const c=header(46);c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint32(16,crc,true);c.setUint32(20,bytes.length,true);c.setUint32(24,bytes.length,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);central.push(new Uint8Array(c.buffer),name);offset+=30+name.length+bytes.length}const size=central.reduce((n,b)=>n+b.length,0),end=header(22);end.setUint32(0,0x06054b50,true);end.setUint16(8,entries.length,true);end.setUint16(10,entries.length,true);end.setUint32(12,size,true);end.setUint32(16,offset,true);return new Blob([...parts,...central,end.buffer],{type:'application/zip'})}

async function exportSourceBundle(){
  const button=$('getsource');if(!button||button.disabled)return;
  button.disabled=true;button.textContent='Preparing source…';
  try{
    const fontBase64=document.querySelector('style')?.textContent.match(/data:font\/woff2;base64,([^\s)]+)/)?.[1];
    const blob=await rebuildSourceZip(window.PDFPRO_ASSETS,{fontBase64});
    download(blob,'pdfpro-3.0-source.zip','application/zip');
  }finally{if(button.isConnected){button.disabled=false;button.textContent='Download source bundle'}}
}
async function about(){await modal('pdfpro 3.0',`<span class="tag">Private PDF workspace · Offline edition</span><p>Built for local document work. No accounts, telemetry, or network processing. English OCR is bundled.</p><p><strong>Supported:</strong> page organisation, markup, added content, standard forms, OCR, comparison, batch exports, bounded text replacement, raster redaction, AES encryption, and RSA certificate signatures.</p><p><strong>Limits:</strong> no Office conversion, dynamic XFA, live collaboration, certificate trust service, trusted timestamps, PDF/A or PDF/UA certification, professional colour preflight, or automatic text reflow. Advanced PDF structures may not survive rewrites. Use a copy and review exports.</p><p>Certificate edits can invalidate earlier signatures. Secure redaction rebuilds every page as an image; native removal needs review.</p><p><strong>Licensing:</strong> pdfpro is distributed under AGPL-3.0-or-later with MuPDF. Other components retain their licences. Source, dependency versions, notices, and reproducible build instructions are included with the delivery.</p><div class="flex"><button type="button" id="getsource">Download source bundle</button><button type="button" id="getlicenses">Third-party notices</button></div><p class="help">The complete source ZIP is assembled locally from shared embedded assets. Local autosave uses IndexedDB when the browser permits it. Reopen closed documents or remove stored copies in the Local library. Local working copies may be unlocked; downloaded backups are still recommended. Browser printing opens a local image preview.</p>`,{ok:null,setup:()=>{$('getsource').onclick=guard(exportSourceBundle);$('getlicenses').onclick=()=>{download(window.PDFPRO_ASSETS.notices,'pdfpro-LICENSES.txt','text/plain')}}})}

function requestOpenFiles(){
  if(transitionBlocked()){toast('Finish the current operation before opening another PDF.');return}
  $('fileinput').value='';$('fileinput').click();
}
$('openBtn').onclick=$('browseBtn').onclick=$('addDocument').onclick=requestOpenFiles;
$('fileinput').onchange=guard(event=>openFiles([...event.target.files]));
$('dropzone').onclick=event=>{if(event.target.id!=='browseBtn')requestOpenFiles()};
$('dropzone').onkeydown=event=>{if(event.target===$('dropzone')&&(event.key==='Enter'||event.key===' ')){event.preventDefault();requestOpenFiles()}};
document.addEventListener('dragover',event=>event.preventDefault());
document.addEventListener('drop',guard(async event=>{event.preventDefault();await openFiles([...event.dataTransfer.files])}));
$('demoBtn').onclick=guard(createDemo);$('newBtn').onclick=guard(newDocument);
$('saveBtn').onclick=guard(save);$('undo').onclick=guard(undo);$('redo').onclick=guard(redo);
$('prev').onclick=guard(()=>go(state.page-1));$('next').onclick=guard(()=>go(state.page+1));
$('pageinput').onchange=guard(event=>go(+event.target.value-1));
$('zoomIn').onclick=guard(async()=>{need();state.fit=false;state.zoom=Math.min(4,state.zoom*1.2);await render()});
$('zoomOut').onclick=guard(async()=>{need();state.fit=false;state.zoom=Math.max(.2,state.zoom/1.2);await render()});
$('fit').onclick=guard(async()=>{need();state.fit=true;await render()});
$('printBtn').onclick=guard(print);$('fullscreen').onclick=guard(()=>document.fullscreenElement?document.exitFullscreen():$('documentStage').requestFullscreen());
$('about').onclick=guard(about);$('theme').onclick=()=>{document.body.classList.toggle('dark');scheduleLocal()};
window.addEventListener('resize',()=>{if(!homeVisible&&state.fit&&state.doc)guard(render)()});
window.addEventListener('beforeunload',event=>{const current=localAutosave.isCurrent();void persistLocal();if(hasUnsavedDocuments()&&!current){event.preventDefault();event.returnValue=''}});
window.addEventListener('pagehide',()=>{void persistLocal()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)void persistLocal()});
$('main').addEventListener('scroll',()=>{if(drag?.kind==='ink')cancelPageDrag();scheduleLocal()},{passive:true});
document.addEventListener('keydown',event=>{
  if(event.target.matches('input,textarea,select')||event.target.closest('[role="tablist"]')||$('modalroot').firstChild)return;
  if(splitWorkspace?.isOpen)return;
  if(homeVisible&&(event.ctrlKey||event.metaKey)&&['s','z','f'].includes(event.key.toLowerCase())){event.preventDefault();toast('Select a document tab or choose Resume to continue.');return}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();guard(save)()}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='z'){event.preventDefault();guard(event.shiftKey?redo:undo)()}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='f'){
    event.preventDefault();if(state.doc){state.group='View';state.paneOpen=true;state.settingsOpen=state.paneDocked;state.tool='search';renderPanel();showSearch()}
  }
  if(event.key==='Escape'){state.paneOpen=false;deselectTool();scheduleLocal()}
  if(event.key==='ArrowRight'&&state.doc&&!homeVisible)guard(()=>go(state.page+1))();
  if(event.key==='ArrowLeft'&&state.doc&&!homeVisible)guard(()=>go(state.page-1))();
});
function setActionMenu(open,{focus=false}={}){
  $('actionMenu').hidden=!open;$('moreActions').setAttribute('aria-expanded',String(open));
  if(open&&focus)$('actionMenu').querySelector('button:not(:disabled)')?.focus();
}
$('moreActions').onclick=()=>setActionMenu($('actionMenu').hidden);
$('moreActions').onkeydown=event=>{if(event.key==='ArrowDown'){event.preventDefault();setActionMenu(true,{focus:true})}};
$('actionMenu').addEventListener('click',event=>{if(event.target.closest('button'))setActionMenu(false)});
$('actionMenu').addEventListener('keydown',event=>{
  if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
  event.preventDefault();event.stopPropagation();
  const buttons=[...$('actionMenu').querySelectorAll('button:not(:disabled)')],index=buttons.indexOf(document.activeElement);
  buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowUp'?-1:1)+buttons.length)%buttons.length]?.focus();
});
document.addEventListener('pointerdown',event=>{if(!event.composedPath().some(node=>node.classList?.contains('more-actions')))setActionMenu(false)});
document.addEventListener('click',event=>{if(!event.composedPath().some(node=>node.classList?.contains('more-actions')))setActionMenu(false)});
document.addEventListener('focusin',event=>{if(!event.target.closest('.more-actions'))setActionMenu(false)});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('actionMenu').hidden){setActionMenu(false);$('moreActions').focus()}});
function dismissOutside(event){
  if(!state.paneOpen&&!state.settingsOpen)return;
  // A tool action can rebuild its button before this event bubbles to document.
  // The original event path still identifies clicks inside that pane/navigation.
  if(event.composedPath().some(node=>['toolpane','nav','modalroot','busy'].includes(node.id)))return;
  if(state.paneDocked){if(!state.settingsOpen)return;state.settingsOpen=false}
  else{state.paneOpen=false;state.settingsOpen=false}
  // The unpinned pane overlays the page. Dismiss without rebuilding the page targets
  // so this same click can select text, open a comment or begin a placement drag.
  renderPanel();
}
document.addEventListener('pointerdown',dismissOutside);
document.addEventListener('click',dismissOutside);
$('closeTools').onclick=guard(async()=>{state.paneDocked=false;state.settingsOpen=false;await setPane(false);[...$('nav').querySelectorAll('[data-group]')].find(button=>button.dataset.group===state.group)?.focus()});
$('dockTools').onclick=guard(async()=>{state.paneDocked=!state.paneDocked;state.paneOpen=!state.paneDocked;state.settingsOpen=false;renderPanel();if(state.doc&&state.fit)await render()});
$('togglePages').onclick=()=>{state.pagesCompact=!state.pagesCompact;document.body.classList.toggle('pages-compact',state.pagesCompact);const label=state.pagesCompact?'Expand page previews':'Compact page previews';$('togglePages').setAttribute('aria-expanded',String(!state.pagesCompact));$('togglePages').setAttribute('aria-label',label);$('togglePages').title=label;if(state.doc)refreshNavigation();scheduleLocal()};
$('toolSettings').onclick=()=>{state.settingsOpen=!state.settingsOpen;$('toolpane').classList.toggle('settings-open',state.settingsOpen);$('toolSettings').setAttribute('aria-expanded',String(state.settingsOpen));if(state.settingsOpen)[...$('toolsettingsbody').querySelectorAll('input,select,button')].find(control=>!control.closest('[hidden]'))?.focus()};

$('toggleNav').onclick=guard(async()=>{state.navCollapsed=!state.navCollapsed;document.body.classList.toggle('nav-compact',state.navCollapsed);const label=state.navCollapsed?'Expand navigation':'Collapse navigation';$('toggleNav').setAttribute('aria-expanded',String(!state.navCollapsed));$('toggleNav').setAttribute('aria-label',label);$('toggleNav').title=label;if(state.doc&&state.fit)await render();await persistLocal()});
$('libraryBtn').onclick=$('storageStatus').onclick=guard(showLocalLibrary);
$('homeBtn').onclick=guard(showHome);$('viewLibrary').onclick=guard(showLocalLibrary);
OCR.configureOCR(window.PDFPRO_ASSETS.ocr);
window.PdfPro={state,tabs,local:{store:localStore,autosave:localAutosave,flush:persistLocal,open:guard(openStoredDocument),library:guard(showLocalLibrary),close:()=>{directEditor?.close();splitWorkspace?.close();continuousPages.destroy();pageToolbar.destroy();appClosed=true;recentGeneration++;catalogueRead++;recentPreviews.clear();return localAutosave.close()}},get continuousPages(){return continuousPages},get mergeSplit(){return splitWorkspace},get activeTabId(){return activeTabId},switchTab:guard(switchTab),closeTab:guard(closeTab),newDocument:guard(newDocument),Engine,OCR,PDFLib,backgroundEngine,openFiles:guard(openFiles),setBytes,createDemo:guard(createDemo),activate:guard(activate),parsePages,zip,canvasForPage,editPDF:guard(editPDF),render,toPdf,pdfRect,job,version:'3.0.0'};
refresh();$('bootmsg').textContent='Opening local workspace…';await initialiseLocalWorkspace();$('boot').remove();
