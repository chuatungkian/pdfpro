/* Workspace refresh integration with fake-indexeddb + real PDF bytes in a test DOM.
 * No browser profile, browser layout engine or user PDFs are used.
 */
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {readTestZip} from './source-zip-test-utils.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {LocalWorkspaceStore} from './local-store.js';
const require=createRequire(import.meta.url);
let JSDOM,canvas,idb;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
try{idb=require('fake-indexeddb')}catch{idb=require(process.env.PDFPRO_IDB_MODULES||'../pdfpro-testdeps/node_modules/fake-indexeddb')}
const {IDBFactory}=idb;
globalThis.indexedDB=new IDBFactory();
let signingAPI,bootNumber=0;
async function boot(){
const releasedHTML=fs.readFileSync('../../outputs/pdfpro.html','utf8');
const font=releasedHTML.match(/data:font\/woff2;base64,([^\s)]+)/)[1];
const releasedAssets=JSON.parse(gunzipSync(Buffer.from(releasedHTML.match(/<script id="pdfpro-payload"[^>]*>([\s\S]*?)<\/script>/)[1],'base64')).toString());
const dom=new JSDOM(fs.readFileSync('shell.html','utf8').replace('/* PDFPRO_FONT */','@font-face{font-family:Inter;src:url(data:font/woff2;base64,'+font+') format("woff2")}').replace('/* PDFPRO_LAYOUT */',fs.readFileSync('layout.css','utf8')).replace('/* PDFPRO_REFRESH */',fs.readFileSync('refresh.css','utf8')),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS=releasedAssets;
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
if(signingAPI)window.PdfProSigning=signingAPI;
await import('./app.mjs?local-recovery='+bootNumber++);signingAPI=window.PdfProSigning;
const app=window.PdfPro,$=id=>window.document.getElementById(id);
return {app,$,window,dom,downloads,fileSelections,close:async()=>{await app.local.close();app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;await new Promise(r=>nativeSetTimeout(r,20))}};
}

let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>setTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
async function fixture(app,text){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<2;i++)doc.addPage([595,842]).drawText(text+' '+(i+1),{x:40,y:760,size:15});return new Uint8Array(await doc.save({useObjectStreams:false}))}
const file=(name,bytes)=>({name,type:'application/pdf',arrayBuffer:async()=>bytes.slice().buffer});
const text=(app)=>app.Engine.extractTextPDF(app.state.bytes).map(page=>page.text).join('\n');
let context;
const originalError=console.error,errors=[];console.error=error=>errors.push(error);
try{
 context=await boot();const {app,$,window,downloads}=context;
 await app.newDocument();const bytes=app.state.bytes,history=app.state.undo.length;
 $('about').click();await until(()=>$('getsource'),'About dialog');
 const button=$('getsource');button.click();check(button.disabled,'source export disables duplicate requests');
 equal(button.textContent,'Preparing source…','source export reports progress');button.click();
 await until(()=>downloads.length===1&&!button.disabled,'complete source download');
 equal(downloads[0].name,'pdfpro-3.0-source.zip','source download keeps its name');
 const exported=readTestZip(Buffer.from(await(await fetch(downloads[0].href)).arrayBuffer()));
 const standalone=readTestZip(fs.readFileSync('../../outputs/pdfpro-3.0-app-source.zip'));
 equal(exported.size,standalone.size,'button exports every source file');
 check([...standalone].every(([name,entry])=>entry.bytes.equals(exported.get(name)?.bytes)),'every file exported through the UI matches the release source');
 check(exported.has('source/fonts/InterVariable.woff2')&&exported.has('source/vendor/mupdf/dist/mupdf-wasm.wasm'),'font and engine paths are retained');
 check(exported.has('source/LICENSE.txt')&&exported.has('source/THIRD-PARTY-NOTICES.txt'),'licence and notice files are retained');
 equal(downloads.length,1,'double click produces one download');check(!button.disabled,'source button becomes available again');
 check(app.state.bytes===bytes&&app.state.undo.length===history,'source export does not alter the working PDF or history');
 $('getlicenses').click();await until(()=>downloads.length===2,'notice download');
 equal(await(await fetch(downloads[1].href)).text(),window.PDFPRO_ASSETS.notices,'notice download is unchanged');

 // A damaged shared asset is reported without losing the working PDF; retry works.
 const archive=window.PDFPRO_ASSETS.sourceArchive,record=archive.entries.find(entry=>entry.asset==='mupdf'),crc=record.crc;record.crc=(crc+1)>>>0;
 button.click();await until(()=>!button.disabled&&errors.length,'source failure');
 equal(downloads.length,2,'failed source integrity check produces no corrupt download');
 check($('toast').textContent.includes('integrity check'),'source failure is explained');
 check(app.state.bytes===bytes,'failed source export preserves the PDF');
 equal(button.textContent,'Download source bundle','failed source export restores button text');
 record.crc=crc;button.click();await until(()=>downloads.length===3&&!button.disabled,'source retry');
 equal(readTestZip(Buffer.from(await(await fetch(downloads[2].href)).arrayBuffer())).size,standalone.size,'retry recreates the complete source');
 $('modalcancel').click();await pause();await app.local.flush();
 check(app.state.doc&&app.state.bytes===bytes,'document remains usable after closing source dialog');
 console.log('pdfpro source export UI: '+assertions+' assertions passed in test DOM using the actual release assets.');
}finally{console.error=originalError;if(context)await context.close()}
