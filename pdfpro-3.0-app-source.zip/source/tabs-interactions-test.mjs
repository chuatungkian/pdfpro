/* Session-tab integration regression in a controlled test DOM with real PDF bytes.
 * This is not a browser/layout-engine test and does not open user documents.
 * Requires jsdom and @napi-rs/canvas (test-only dependencies).
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
let JSDOM,canvas;
try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require(process.env.PDFPRO_DOM_MODULES||'../pdfpro-testdeps/node_modules/jsdom'))}
try{canvas=require('@napi-rs/canvas')}catch{canvas=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas'))}
const dom=new JSDOM(fs.readFileSync('shell.html','utf8'),{url:'https://pdfpro.test/',pretendToBeVisual:true});
const {window}=dom;
globalThis.window=window;globalThis.document=window.document;globalThis.FormData=window.FormData;globalThis.ImageData=canvas.ImageData;globalThis.devicePixelRatio=1;
let narrow=false;
globalThis.matchMedia=window.matchMedia=()=>({get matches(){return narrow},addEventListener(){},removeEventListener(){}});
const nativeSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>{const timer=nativeSetTimeout(fn,ms,...args);if(ms>=1000)timer.unref?.();return timer};
const backings=new WeakMap();
window.HTMLCanvasElement.prototype.getContext=function(kind){let current=backings.get(this);if(!current||current.width!==this.width||current.height!==this.height){current=canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));backings.set(this,current)}return current.getContext(kind)};
window.HTMLCanvasElement.prototype.toBlob=function(callback,type='image/png'){const backing=backings.get(this)||canvas.createCanvas(Math.max(1,this.width),Math.max(1,this.height));callback(new Blob([backing.toBuffer(type)],{type}))};
window.HTMLElement.prototype.scrollIntoView=function(){};
window.HTMLElement.prototype.setPointerCapture=function(){};
globalThis.IntersectionObserver=class{constructor(callback){this.callback=callback}observe(element){setTimeout(()=>this.callback([{target:element,isIntersecting:true}]),0)}unobserve(){}disconnect(){}};
window.PDFPRO_ASSETS={ocr:{workerSource:'/* test fixture; no worker starts */',coreSource:'/* test fixture */',languageDataBase64:'AA=='}};
Object.defineProperty(document.getElementById('main'),'clientWidth',{get:()=>900});
const overlay=document.getElementById('overlay');overlay.getBoundingClientRect=()=>({left:0,top:0,width:595,height:842,right:595,bottom:842});Object.defineProperty(overlay,'clientWidth',{get:()=>595});
const downloads=[];
window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,href:this.href})};
const fileSelections=[];
window.HTMLInputElement.prototype.click=function(){if(this.type!=='file')return;const next=fileSelections.shift();if(!next)throw Error('Unexpected test file chooser: '+this.accept);Object.defineProperty(this,'files',{configurable:true,value:next});this.dispatchEvent(new window.Event('change',{bubbles:true}))};
await import('./app.mjs');
const app=window.PdfPro,$=id=>document.getElementById(id);
let assertions=0;
const check=(condition,label)=>{assertions++;assert.ok(condition,label)};
const equal=(actual,expected,label)=>{assertions++;assert.deepEqual(actual,expected,label)};
const pause=(ms=15)=>new Promise(r=>nativeSetTimeout(r,ms));
async function until(predicate,label){const end=Date.now()+7000;while(!predicate()){if(Date.now()>end)throw Error('Timed out: '+label);await pause(5)}}
function tabButton(id){return [...document.querySelectorAll('#documenttabs [data-tab-id]')].find(x=>x.dataset.tabId===id)?.querySelector('.document-tab-select')}
function tabSnapshot(id){return app.tabs.find(t=>t.id===id)?.snapshot}
function outside(){const main=$('main');main.dispatchEvent(new window.MouseEvent('pointerdown',{bubbles:true,button:0}));main.dispatchEvent(new window.MouseEvent('click',{bubbles:true,button:0}))}
function press(type,x,y){const event=new window.MouseEvent(type,{bubbles:true,clientX:x,clientY:y,button:0});Object.defineProperty(event,'pointerId',{value:1});overlay.dispatchEvent(event)}
async function group(name){document.querySelector(`[data-group="${name}"]`).click();await until(()=>app.state.group===name&&app.state.paneOpen,'open tool group '+name);await pause()}
async function fixture(label,pages=2){const doc=await app.PDFLib.PDFDocument.create();for(let i=0;i<pages;i++)doc.addPage([595,842]).drawText(label+' page '+(i+1),{x:40,y:760,size:16});return new Uint8Array(await doc.save({useObjectStreams:false}))}
function file(name,bytes,type='application/pdf'){return{name,type,arrayBuffer:async()=>Uint8Array.from(bytes).buffer}}
function submitModal(){const form=$('modalform');assert.ok(form,'test expected a modal form');form.dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}))}
async function switchTo(id){await app.switchTab(id);await pause()}
async function saveActive(){const prior=downloads.length;$('saveBtn').click();await until(()=>downloads.length>prior&&!app.state.dirty,'save active document');await pause()}
async function closeAccept(id){const pending=app.closeTab(id);await pause();if($('modalform'))submitModal();await pending;await pause()}
let originalInspect;
try{
 const firstName='Alpha <img src=x onerror=alert(1)>.pdf',secondName='Beta.pdf';
 const alpha=await fixture('ALPHA'),beta=await fixture('BETA',3);
 await app.openFiles([file(firstName,alpha),file(secondName,beta)]);
 equal(app.tabs.length,2,'one tab is created for every uploaded PDF');
 equal(document.querySelectorAll('#documenttabs .document-tab').length,2,'both document tabs are shown');
 check([...document.querySelectorAll('.document-tab-select')].every(x=>x.getAttribute('role')==='tab'),'document selectors use tab semantics');
 const alphaId=app.tabs.find(t=>t.snapshot.name===firstName)?.id,betaId=app.tabs.find(t=>t.snapshot.name===secondName)?.id;
 check(alphaId&&betaId&&alphaId!==betaId,'each uploaded PDF has a distinct stable ID');
 check(!$('documenttabs').querySelector('img'),'file names are escaped in tab markup');
 check($('documenttabs').textContent.includes(firstName),'literal file name remains readable');
 tabButton(betaId).dispatchEvent(new window.KeyboardEvent('keydown',{key:'ArrowLeft',bubbles:true,cancelable:true}));
 await until(()=>app.activeTabId===alphaId,'keyboard previous tab');await pause();
 equal(app.state.name,firstName,'Left Arrow activates the previous document tab');
 equal(app.state.page,0,'tab keyboard navigation does not navigate document pages');
 tabButton(alphaId).dispatchEvent(new window.KeyboardEvent('keydown',{key:'End',bubbles:true,cancelable:true}));
 await until(()=>app.activeTabId===betaId,'keyboard last tab');await pause();
 check(tabButton(betaId).getAttribute('aria-selected')==='true'&&tabButton(alphaId).getAttribute('aria-selected')==='false','keyboard selection updates accessible tab state');
 tabButton(betaId).dispatchEvent(new window.KeyboardEvent('keydown',{key:'Home',bubbles:true,cancelable:true}));
 await until(()=>app.activeTabId===alphaId,'keyboard first tab');await pause();
 equal(document.activeElement.id,'tab-'+alphaId,'tab keyboard navigation moves focus to the activated tab');
 // Loading an invalid PDF reports the issue without replacing any open document.
 const beforeInvalid=app.state.bytes,invalidCount=app.tabs.length;
 const invalidOpen=app.openFiles([file('Broken.pdf',new Uint8Array([0,1,2,3,4]))]);
 await until(()=>$('modalform'),'invalid PDF error report');
 equal(app.tabs.length,invalidCount,'invalid PDF creates no empty tab');check(app.state.bytes===beforeInvalid,'invalid PDF leaves the selected document untouched');
 $('modalcancel').click();await invalidOpen;
 // A pending upload must also stop edits starting against the previous document.
 await group('Organize');const beforeUpload=app.state.bytes,undoBeforeUpload=app.state.undo.length;
 let releaseUpload;
 const deferredUpload=app.openFiles([{name:'Slow upload.pdf',type:'application/pdf',arrayBuffer:()=>new Promise(resolve=>{releaseUpload=()=>resolve(beta.slice().buffer)})}]);
 await until(()=>!!releaseUpload,'deferred upload read starts');
 document.querySelector('[data-tool="rotate"]').click();await pause(35);
 check(app.state.bytes===beforeUpload,'an edit cannot start while another PDF is being uploaded');
 equal(app.state.undo.length,undoBeforeUpload,'blocked edit creates no history entry during upload');
 releaseUpload();await deferredUpload;
 equal(app.tabs.length,3,'deferred upload adds its new tab after reading completes');
 equal(app.state.name,'Slow upload.pdf','deferred upload selects its own tab');
 await app.closeTab(app.activeTabId);equal(app.tabs.length,2,'closing a clean uploaded tab leaves the earlier tabs available');
 await switchTo(alphaId);
 // Identical file names still identify independent uploaded documents.
 await app.openFiles([file('Same name.pdf',alpha),file('Same name.pdf',beta)]);
 const duplicates=app.tabs.filter(tab=>tab.snapshot.name==='Same name.pdf');
 equal(duplicates.length,2,'repeated file names create separate tabs');check(duplicates[0].id!==duplicates[1].id,'same-name tabs retain different IDs');
 equal(app.state.doc.countPages(),3,'last same-name tab has its own page tree');
 await switchTo(duplicates[0].id);equal(app.state.doc.countPages(),2,'first same-name tab restores its different page tree');
 await app.closeTab(duplicates[1].id);await app.closeTab(duplicates[0].id);await switchTo(alphaId);
 // Mixed input keeps each PDF separate and groups image pages into one additional tab.
 const bitmap=canvas.createCanvas(96,64),paint=bitmap.getContext('2d');paint.fillStyle='#800020';paint.fillRect(0,0,96,64);paint.fillStyle='#ffffff';paint.fillRect(15,15,45,25);
 const mixedCount=app.tabs.length;
 await app.openFiles([file('Mixed PDF.pdf',beta),file('Photo one.png',bitmap.toBuffer('image/png'),'image/png'),file('Photo two.jpg',bitmap.toBuffer('image/jpeg'),'image/jpeg')]);
 equal(app.tabs.length,mixedCount+2,'mixed PDF and two images create one PDF tab and one grouped image tab');
 equal(app.state.name,'Photo one.pdf','image group has its own converted PDF name');equal(app.state.doc.countPages(),2,'PNG and JPEG each become one page in the image document');
 check(app.state.dirty,'image conversion marks only its created document unsaved');
 const imageId=app.activeTabId,mixedId=app.tabs.find(tab=>tab.snapshot.name==='Mixed PDF.pdf').id;
 await switchTo(mixedId);equal(app.state.bytes,beta,'mixed selection preserves the uploaded PDF bytes');equal(app.state.doc.countPages(),3,'mixed PDF retains its original page count');
 check(!app.state.dirty,'the uploaded PDF stays clean beside the converted images');
 await closeAccept(imageId);await app.closeTab(mixedId);await switchTo(alphaId);
 // Cancelling a password dialogue must leave every earlier document untouched.
 const beforeEncrypted=app.state.bytes,encryptedCount=app.tabs.length;
 const protectedBytes=app.Engine.protectPDF(alpha,{password:'test-password-123',ownerPassword:'test-owner-456',permissions:-4});
 const cancelledEncrypted=app.openFiles([file('Locked.pdf',protectedBytes)]);
 await until(()=>$('pw'),'encrypted PDF password dialogue');$('modalcancel').click();await cancelledEncrypted;
 equal(app.tabs.length,encryptedCount,'cancelled encrypted upload creates no empty tab');check(app.state.bytes===beforeEncrypted,'cancelled password dialogue preserves the selected PDF');
 const unlocked=app.openFiles([file('Locked.pdf',protectedBytes)]);
 await until(()=>$('pw'),'encrypted PDF password dialogue again');$('pw').value='test-password-123';submitModal();await unlocked;
 equal(app.tabs.length,encryptedCount+1,'unlocking an encrypted PDF creates its own tab');equal(app.state.name,'Locked.pdf','unlocked tab keeps the uploaded name');
 equal(app.state.doc.countPages(),2,'unlocked tab contains the complete readable document');
 check(!app.state.dirty,'unlocking starts a clean working copy');
 await app.closeTab(app.activeTabId);await switchTo(alphaId);
 // Marks alone show an unsaved badge without rewriting document bytes.
 await app.openFiles([file('Placement fixture.pdf',alpha)]);const placementId=app.activeTabId;
 app.state.fit=false;app.state.zoom=1;await app.render();
 const beforeMark=app.state.bytes;await group('Protect & sign');document.querySelector('[data-tool="redact"]').click();await until(()=>app.state.tool==='redact','activate mark redaction');await pause();
 press('pointerdown',45,110);check(!app.state.paneOpen,'page pointerdown dismisses an unpinned pane during placement');
 check($('dragrect'),'outside dismissal preserves an active region drag');press('pointermove',165,150);press('pointerup',165,150);
 await until(()=>app.state.marks.length===1,'place redaction mark');
 equal(app.state.marks[0],{page:0,rect:[45,110,165,150]},'redaction drag retains its exact PDF coordinates');
 check(!app.state.dirty&&app.state.bytes===beforeMark,'marking alone does not rewrite or dirty PDF bytes');
 check(tabButton(placementId).querySelector('.tab-dirty'),'pending marks alone show the document unsaved badge');
 await group('Protect & sign');document.querySelector('[data-tool="clearmarks"]').click();await until(()=>!app.state.marks.length,'clear pending redactions');await pause();
 check(!tabButton(placementId).querySelector('.tab-dirty'),'clearing marks removes a marks-only unsaved badge');
 // The same first page click both dismisses the pane and starts a text comment.
 await group('Annotate');document.querySelector('[data-tool="freetext"]').click();await until(()=>app.state.tool==='freetext','activate comment placement');await pause();
 check(app.state.paneOpen,'comment tool starts with the unpinned pane open');
 press('pointerdown',70,180);check(!app.state.paneOpen&&app.state.tool==='freetext','outside pointerdown closes pane without cancelling comment tool');
 press('pointerup',70,180);await until(()=>$('annotationText'),'first click opens comment entry dialogue');
 $('annotationText').value='Comment placed by the same outside click';submitModal();
 await until(()=>app.state.bytes!==beforeMark&&!app.state.abort,'save placed comment');await pause();
 const commentPage=app.state.doc.loadPage(0),placedComments=commentPage.getAnnotations();
 try{const comment=placedComments.find(annotation=>annotation.getType()==='FreeText');check(comment?.getContents()==='Comment placed by the same outside click','outside click places a real text comment');
 const rect=comment.getBounds();check(rect.every((value,index)=>Math.abs(value-[70,180,230,205.2][index])<.01),'outside dismissal preserves default click-placement coordinates')}
 finally{placedComments.forEach(annotation=>annotation.destroy());commentPage.destroy()}
 await closeAccept(placementId);await switchTo(alphaId);
 equal(app.state.name,firstName,'switch selects the correct PDF');
 equal(app.state.doc.countPages(),2,'correct page tree opens when switching');
 await app.editPDF('Alpha edit',d=>d.getPage(0).drawText('ALPHA EDIT ONLY',{x:40,y:710,size:12}));
 const alphaEdited=app.state.bytes;
 app.state.page=1;app.state.zoom=.83;app.state.fit=false;app.state.searchQuery='ALPHA';
 app.state.marks=[{page:1,rect:[30,40,100,80]}];app.state.hits=[{page:1,rect:[40,50,120,90]}];
 app.state.selectedImage={bytes:new Uint8Array([11,22,33]),type:'image/png'};app.state.tool='search';
 $('main').scrollTop=417;$('main').scrollLeft=23;
 await switchTo(betaId);
 equal(app.state.name,secondName,'other tab restores its own name');
 equal(app.state.bytes,beta,'other tab retains its original uploaded bytes');
 equal(app.state.undo.length,0,'undo history does not carry into another PDF');
 equal(app.state.marks,[],'redaction marks do not carry into another PDF');
 equal(app.state.searchQuery||'','','search query starts independently');
 check(!app.state.dirty,'another freshly opened PDF stays clean');
 await app.editPDF('Beta edit',d=>d.getPage(0).drawText('BETA EDIT ONLY',{x:40,y:710,size:12}));
 check(app.state.bytes!==alphaEdited,'edits in the other tab use separate bytes');
 const betaEdited=app.state.bytes;app.state.page=2;app.state.zoom=1.2;app.state.fit=false;
 $('main').scrollTop=725;$('main').scrollLeft=58;
 await saveActive();
 check(downloads.at(-1).name.startsWith('Beta'),'save downloads the active tab name');
 check(!app.state.dirty,'save clears only the active document dirty flag');
 await switchTo(alphaId);
 check(app.state.bytes===alphaEdited,'switching restores the edited PDF byte snapshot');
 equal(app.state.original,alpha,'uploaded original bytes remain per document');
 equal(app.state.page,1,'page position is restored');
 equal(app.state.zoom,.83,'zoom is restored');check(app.state.fit===false,'fit preference is restored');
 equal($('main').scrollTop,417,'first tab vertical document scroll is restored');equal($('main').scrollLeft,23,'first tab horizontal document scroll is restored');
 equal(app.state.undo.length,1,'independent undo history is restored');check(app.state.dirty,'saving another tab does not clear this dirty flag');
 equal(app.state.marks,[{page:1,rect:[30,40,100,80]}],'pending redactions are restored');
 equal(app.state.hits,[{page:1,rect:[40,50,120,90]}],'search highlights are restored');
 equal(app.state.searchQuery,'ALPHA','search query is restored');
 equal([...app.state.selectedImage.bytes],[11,22,33],'selected image remains attached to its tab');
 const unload=new window.Event('beforeunload',{cancelable:true});
 await switchTo(betaId);window.dispatchEvent(unload);check(unload.defaultPrevented,'unsaved inactive tab warns before browser unload');
 equal(app.state.bytes,betaEdited,'inactive changes cannot rewrite the active PDF');
 equal(app.state.page,2,'second tab page position is independent');equal(app.state.zoom,1.2,'second tab zoom is independent');
 equal($('main').scrollTop,725,'second tab vertical document scroll remains independent');equal($('main').scrollLeft,58,'second tab horizontal document scroll remains independent');
 // Undo in Beta should not alter Alpha or mark it clean.
 const beforeUndo=app.state.bytes;$('undo').click();await until(()=>app.state.bytes!==beforeUndo&&!app.state.abort,'undo in Beta');await pause();
 equal(app.state.bytes,beta,'undo restores only the active PDF');
 await switchTo(alphaId);check(app.state.bytes===alphaEdited&&app.state.undo.length===1,'other tab undo leaves first edit and history intact');
 app.state.marks=[];app.state.hits=[];app.state.tool='select';
 // Signature inspection precedes job(): switching must also be locked during this gap.
 let releaseInspection;originalInspect=window.PdfProSigning;
 window.PdfProSigning={...originalInspect,inspectSignatures:()=>new Promise(resolve=>{releaseInspection=()=>resolve([])})};
 await group('Organize');const beforeRotate=app.state.bytes;
 document.querySelector('[data-tool="rotate"]').click();await until(()=>!!releaseInspection,'deferred signature inspection');
 tabButton(betaId).click();await pause();equal(app.activeTabId,alphaId,'tab switching is blocked before a job starts');
 releaseInspection();await until(()=>app.state.bytes!==beforeRotate&&!app.state.abort,'rotate original tab');await pause();
 window.PdfProSigning=originalInspect;originalInspect=null;
 const rotated=await app.PDFLib.PDFDocument.load(app.state.bytes,{updateMetadata:false});equal(rotated.getPage(1).getRotation().angle,90,'deferred edit rotates the selected page of its original PDF');
 equal(rotated.getPage(0).getRotation().angle,0,'deferred edit leaves other pages unchanged');
 check(app.state.bytes!==beforeRotate,'deferred edit modifies its original tab');
 await switchTo(betaId);equal(app.state.bytes,beta,'blocked switching prevents mutation of the requested target tab');
 // Popup dismissal and dock controls never mutate PDF bytes.
 const beforePane=app.state.bytes;
 await group('Annotate');
 $('panel').dispatchEvent(new window.MouseEvent('pointerdown',{bubbles:true}));$('panel').dispatchEvent(new window.MouseEvent('click',{bubbles:true}));
 await pause();check(app.state.paneOpen,'clicking inside the tool pane keeps it open');
 outside();await until(()=>!app.state.paneOpen,'outside dismissal');check(!app.state.paneDocked,'ordinary tools remain unpinned');
 await group('Annotate');$('dockTools').click();await until(()=>app.state.paneDocked,'dock tools');
 check($('workspace').classList.contains('pane-docked'),'docked tools have a dedicated layout state');
 check([...document.querySelectorAll('#panel [data-tool]')].every(button=>button.getAttribute('aria-label')&&button.title),'icon tool buttons retain accessible labels and tooltips');
 check([...document.querySelectorAll('#panel [data-tool]')].every(button=>button.querySelector('.tool-icon svg')),'docked tool buttons have inline vector icons');
 outside();await pause();check(app.state.paneDocked,'outside click preserves the pinned tool bar');
 check($('toolSettings'),'docked bar offers tool settings');
 $('toolSettings').click();await pause();check($('toolSettings').getAttribute('aria-expanded')==='true','tool settings popup opens accessibly');
 $('toolColor').dispatchEvent(new window.MouseEvent('click',{bubbles:true}));await pause();
 check($('toolSettings').getAttribute('aria-expanded')==='true','clicking inside the settings popup keeps it open');
 outside();await pause();check($('toolSettings').getAttribute('aria-expanded')==='false','outside click dismisses settings');
 check(app.state.paneDocked,'dismissing settings keeps the docked bar');
 equal(app.state.bytes,beforePane,'pane/dock interactions do not mutate PDF bytes');
 $('dockTools').click();await until(()=>!app.state.paneDocked,'undock tools');
 narrow=true;await group('Annotate');outside();await until(()=>!app.state.paneOpen,'narrow outside dismissal');narrow=false;
 // New, sample and saved workspaces all add tabs instead of replacing existing documents.
 const existingCount=app.tabs.length;
 await app.newDocument();equal(app.tabs.length,existingCount+1,'blank PDF opens a new tab');equal(app.state.name,'Untitled.pdf','blank tab has its own document name');
 equal(app.state.undo.length,0,'blank document starts with fresh undo history');equal(app.state.marks,[],'blank document starts without pending marks');
 const blankId=app.activeTabId;await app.createDemo();equal(app.tabs.length,existingCount+2,'sample PDF opens another tab');
 const demoId=app.activeTabId;check(demoId!==blankId,'blank and sample IDs differ');
 const workspaceBytes=await fixture('RESTORED WORKSPACE');
 fileSelections.push([{name:'fixture.pdfpro',type:'application/json',text:async()=>JSON.stringify({format:'pdfpro-workspace',version:1,name:'Recovered.pdf',page:1,marks:[{page:0,rect:[1,2,30,40]}],pdf:Buffer.from(workspaceBytes).toString('base64')})}]);
 await app.activate('restore');equal(app.tabs.length,existingCount+3,'restoring a workspace creates a new tab');
 equal(app.state.name,'Recovered.pdf','workspace restores its document name');equal(app.state.page,1,'workspace restores page position');
 equal(app.state.marks,[{page:0,rect:[1,2,30,40]}],'workspace restores only its own pending marks');
 equal(app.state.original,workspaceBytes,'workspace original is not inherited from another tab');
 check(app.tabs.some(t=>t.id===alphaId)&&app.tabs.some(t=>t.id===betaId),'opening additional documents retains prior tabs');
 // Cancel and accept closing a dirty inactive PDF.
 const countBeforeClose=app.tabs.length,activeBeforeClose=app.activeTabId;
 const cancelClose=app.closeTab(alphaId);await until(()=>$('modalform'),'dirty tab close confirmation');
 tabButton(betaId).click();await pause();equal(app.activeTabId,activeBeforeClose,'another tab cannot activate while a close confirmation is pending');
 $('modalcancel').click();await cancelClose;
 equal(app.tabs.length,countBeforeClose,'cancel preserves dirty tab');equal(app.activeTabId,activeBeforeClose,'cancel does not switch away from the active document');
 const acceptClose=app.closeTab(alphaId);await until(()=>$('modalform'),'dirty tab close confirmation again');submitModal();await acceptClose;
 equal(app.tabs.length,countBeforeClose-1,'accepted close removes only the chosen tab');check(!app.tabs.some(t=>t.id===alphaId),'closed document is removed from session list');
 equal(app.state.name,'Recovered.pdf','closing an inactive tab keeps the current PDF selected');
 for(const id of [...app.tabs].map(t=>t.id))await closeAccept(id);
 equal(app.tabs.length,0,'all documents can be closed');check(!app.state.bytes&&!app.state.doc,'closing final tab releases its current PDF');
 check(!$('welcome').classList.contains('hidden')&&$('viewer').classList.contains('hidden'),'closing final tab restores the upload welcome');
 check(!document.querySelector('#documenttabs .document-tab'),'no stale document tab remains');
 console.log(`pdfpro tab interactions: ${assertions} assertions passed in test DOM (not browser layout).`);
}finally{
 if(originalInspect)window.PdfProSigning=originalInspect;
 app.state.doc?.destroy();dom.window.close();globalThis.setTimeout=nativeSetTimeout;
}
