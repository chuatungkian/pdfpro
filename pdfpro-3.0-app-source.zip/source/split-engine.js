/* Copy PDF page groups without changing the source documents. AGPL-3.0-or-later. */
import {PDFDocument,PDFName} from 'pdf-lib';
import {splitOutputName} from './split-planner.js';
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
function cancelled(signal){if(signal?.aborted)throw new DOMException('Cancelled','AbortError')}
function hasFields(doc){return doc.getPages().some(page=>page.node.Annots()?.asArray().some(ref=>doc.context.lookup(ref)?.get?.(PDFName.of('Subtype'))?.toString()==='/Widget'))}
export async function buildSplitPdfs({sources,pages,ranges,prefix,signal,progress=()=>{}}){
  if(!pages.length||!ranges.length)throw Error('No pages to export.');
  let next=1;for(const range of ranges){if(!Number.isSafeInteger(range.start)||!Number.isSafeInteger(range.end)||range.start!==next||range.end<range.start||range.end>pages.length)throw Error('Split groups must cover every page exactly once.');next=range.end+1}if(next!==pages.length+1)throw Error('Split groups must cover every page.');
  const docs=new Map(),entries=[];let completed=0;
  for(let group=0;group<ranges.length;group++){
    cancelled(signal);const range=ranges[group],out=await PDFDocument.create();
    for(let position=range.start-1;position<range.end;){
      cancelled(signal);const sourceId=pages[position].id,source=sources.get(sourceId);if(!source?.bytes)throw Error('A source PDF is unavailable.');
      if(!docs.has(sourceId)){
        const doc=await PDFDocument.load(source.bytes,{updateMetadata:false});
        if(hasFields(doc))throw Error(source.name+' contains form fields. Open it and use Flatten form before merging or splitting.');
        docs.set(sourceId,doc);while(docs.size>2)docs.delete(docs.keys().next().value);
      }
      const indices=[];while(position<range.end&&pages[position].id===sourceId&&indices.length<32){indices.push(pages[position].page);position++}
      const copied=await out.copyPages(docs.get(sourceId),indices);for(const page of copied)out.addPage(page);
      completed+=indices.length;progress(completed/pages.length,'Preparing output '+(group+1)+' of '+ranges.length);await tick();
    }
    cancelled(signal);out.setTitle(prefix+' · pages '+range.start+'-'+range.end);out.setCreator('pdfpro');
    const bytes=new Uint8Array(await out.save({useObjectStreams:false}));cancelled(signal);
    entries.push({name:splitOutputName(prefix,group,range,ranges.length),bytes});
  }
  return entries;
}
